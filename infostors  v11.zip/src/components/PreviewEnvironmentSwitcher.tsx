import React from 'react';
import { useShop } from '../context/ShopContext';
import { 
  ShoppingBag, 
  ShieldCheck, 
  Sparkles
} from 'lucide-react';

interface PreviewEnvironmentSwitcherProps {
  currentView: 'customer' | 'admin';
  onViewChange: (view: 'customer' | 'admin') => void;
}

export const PreviewEnvironmentSwitcher: React.FC<PreviewEnvironmentSwitcherProps> = ({
  currentView,
  onViewChange,
}) => {
  const { isFeatureEnabled } = useShop();

  const handleSwitch = (view: 'customer' | 'admin') => {
    onViewChange(view);
    const targetPath = view === 'admin' ? '/admin' : '/';
    if (window.location.pathname !== targetPath) {
      window.history.pushState(null, '', targetPath);
    }
  };

  const activeFeaturesCount = [
    'coupons', 'flashSale', 'reviews', 'returns', 'refunds',
    'deliveryApi', 'whatsappApi', 'emailNotifications',
    'loyalty', 'wallet', 'offers', 'multiVendor', 'advancedReports'
  ].filter(f => isFeatureEnabled(f as any)).length;

  return (
    <aside 
      aria-label="Google AI Studio Live Preview Navigation Switcher"
      className="sticky top-0 z-[9999] w-full bg-slate-900/95 dark:bg-slate-950/95 backdrop-blur-md border-b border-slate-700/80 text-white px-3 py-2 sm:px-5 flex flex-wrap items-center justify-between gap-2.5 shadow-md"
    >
      {/* Brand & Preview Info */}
      <div className="flex items-center gap-2.5">
        <div className="flex items-center gap-1.5 px-2 py-0.5 rounded-md bg-blue-600/30 border border-blue-500/40 text-blue-300 text-[11px] font-bold tracking-wide uppercase">
          <Sparkles className="w-3 h-3 text-blue-400 animate-pulse" />
          <span>Google AI Studio Preview</span>
        </div>
        <div className="hidden md:flex items-center gap-1.5 text-xs text-slate-400 font-medium">
          <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block animate-ping" />
          <span className="text-emerald-400 font-semibold">Live Unified Engine</span>
          <span className="text-slate-600">|</span>
          <span>{activeFeaturesCount}/13 Features Active</span>
        </div>
      </div>

      {/* Primary Switcher Tabs */}
      <nav aria-label="Preview View Selection" className="flex items-center gap-1 sm:gap-1.5 bg-slate-800/90 dark:bg-slate-900 p-0.5 sm:p-1 rounded-xl border border-slate-700/70 shadow-inner">
        <button
          type="button"
          onClick={() => handleSwitch('customer')}
          className={`flex items-center gap-1 sm:gap-1.5 px-2.5 sm:px-3 py-1 sm:py-1.5 rounded-lg text-[11px] sm:text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
            currentView === 'customer'
              ? 'bg-blue-600 text-white shadow-sm'
              : 'text-slate-300 hover:text-white hover:bg-slate-700/60'
          }`}
          title="Switch to live Customer E-commerce Storefront"
        >
          <ShoppingBag className="w-3.5 h-3.5 shrink-0" />
          <span className="hidden xs:inline">CUSTOMER STOREFRONT</span>
          <span className="xs:hidden">STOREFRONT</span>
          {currentView === 'customer' && (
            <span className="w-1.5 h-1.5 rounded-full bg-white ml-0.5 shrink-0" />
          )}
        </button>

        <button
          type="button"
          onClick={() => handleSwitch('admin')}
          className={`flex items-center gap-1 sm:gap-1.5 px-2.5 sm:px-3 py-1 sm:py-1.5 rounded-lg text-[11px] sm:text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
            currentView === 'admin'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-300 hover:text-white hover:bg-slate-700/60'
          }`}
          title="Switch to live Admin Control Panel"
        >
          <ShieldCheck className="w-3.5 h-3.5 shrink-0" />
          <span className="hidden xs:inline">ADMIN CONSOLE</span>
          <span className="xs:hidden">ADMIN</span>
          {currentView === 'admin' && (
            <span className="w-1.5 h-1.5 rounded-full bg-white ml-0.5 shrink-0" />
          )}
        </button>
      </nav>

      {/* Route Info Badge */}
      <div className="hidden sm:flex items-center gap-2">
        <div className="text-[11px] text-slate-400 bg-slate-800/60 px-2.5 py-1 rounded-lg border border-slate-700/50">
          Route: <code className="text-blue-300 font-mono">{currentView === 'admin' ? '/admin' : '/'}</code>
        </div>
      </div>
    </aside>
  );
};
