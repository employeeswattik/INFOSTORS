import React, { useMemo } from 'react';
import { 
  Flame, 
  Star, 
  Sparkles, 
  Tag, 
  ArrowUpDown, 
  RotateCcw,
  SearchX,
  SlidersHorizontal,
  LayoutGrid
} from 'lucide-react';
import { ProductCard } from './ProductCard';
import { useShop } from '../context/ShopContext';
import { CATEGORIES } from '../data/products';

export const ProductSection: React.FC = () => {
  const {
    products,
    categories,
    searchQuery,
    setSearchQuery,
    selectedCategory,
    setSelectedCategory,
    selectedSection,
    setSelectedSection,
    sortBy,
    setSortBy,
  } = useShop();

  // Active section title and icon
  const currentCategoryObj = categories.find(c => c.id === selectedCategory) || categories[0] || {
    id: 'all',
    name: 'All Categories',
    emoji: '🛍️',
    description: 'Explore our entire curated selection',
  };

  // Filtering logic
  const filteredProducts = useMemo(() => {
    let list = [...products];

    // Search query filter (name, category, description, features)
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      list = list.filter(
        p =>
          p.name.toLowerCase().includes(q) ||
          p.category.toLowerCase().includes(q) ||
          p.shortDescription.toLowerCase().includes(q) ||
          p.brand.toLowerCase().includes(q) ||
          p.features.some(f => f.toLowerCase().includes(q))
      );
    }

    // Category filter
    if (selectedCategory !== 'all') {
      list = list.filter(p => p.category === selectedCategory);
    }

    // Section filter
    if (selectedSection === 'trending') {
      list = list.filter(p => p.isTrending);
    } else if (selectedSection === 'bestseller') {
      list = list.filter(p => p.isBestseller);
    } else if (selectedSection === 'new') {
      list = list.filter(p => p.isNewArrival);
    } else if (selectedSection === 'deals') {
      list = list.filter(p => p.isDeal || p.discount >= 50);
    }

    // Sorting
    if (sortBy === 'price-low') {
      list.sort((a, b) => a.price - b.price);
    } else if (sortBy === 'price-high') {
      list.sort((a, b) => b.price - a.price);
    } else if (sortBy === 'rating') {
      list.sort((a, b) => b.rating - a.rating);
    } else if (sortBy === 'discount') {
      list.sort((a, b) => b.discount - a.discount);
    }

    return list;
  }, [products, searchQuery, selectedCategory, selectedSection, sortBy]);

  const resetFilters = () => {
    setSearchQuery('');
    setSelectedCategory('all');
    setSelectedSection('all');
    setSortBy('featured');
  };

  return (
    <section id="products-grid-section" className="py-6 sm:py-10 max-w-7xl mx-auto px-3 sm:px-4 md:px-6">
      {/* Section Header Controls */}
      <div className="flex flex-col gap-4 sm:gap-5 pb-5 sm:pb-6 border-b border-slate-200/80 dark:border-slate-800">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xl sm:text-2xl">{currentCategoryObj.emoji}</span>
              <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-slate-100 tracking-tight">
                {searchQuery
                  ? `Search Results for "${searchQuery}"`
                  : currentCategoryObj.name}
              </h2>
            </div>
            <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
              Showing {filteredProducts.length} premium products ready for fast dispatch
            </p>
          </div>

          {/* Sort By Dropdown */}
          <div className="flex items-center gap-2 self-start md:self-auto">
            <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 flex items-center gap-1">
              <ArrowUpDown className="w-3.5 h-3.5" />
              <span>Sort by:</span>
            </span>
            <select
              value={sortBy}
              onChange={e => setSortBy(e.target.value as any)}
              className="bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200 text-xs font-semibold py-1.5 px-2.5 rounded-xl outline-none focus:border-blue-500 dark:focus:border-blue-400 focus:ring-2 focus:ring-blue-500/10 cursor-pointer"
              id="sort-products-select"
            >
              <option value="featured" className="dark:bg-slate-900 dark:text-slate-100">Featured / Popular</option>
              <option value="price-low" className="dark:bg-slate-900 dark:text-slate-100">Price: Low to High</option>
              <option value="price-high" className="dark:bg-slate-900 dark:text-slate-100">Price: High to Low</option>
              <option value="rating" className="dark:bg-slate-900 dark:text-slate-100">Customer Rating</option>
              <option value="discount" className="dark:bg-slate-900 dark:text-slate-100">Biggest Discount</option>
            </select>
          </div>
        </div>

        {/* Section Tabs (Trending, Best Sellers, New Arrivals, Deals) */}
        <div className="flex items-center gap-1.5 sm:gap-2 overflow-x-auto no-scrollbar pb-1 touch-pan-x overscroll-x-contain">
          <button
            onClick={() => setSelectedSection('all')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer flex items-center gap-1.5 ${
              selectedSection === 'all'
                ? 'bg-slate-900 text-white dark:bg-blue-600 dark:text-white shadow-xs'
                : 'bg-white dark:bg-slate-800/90 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700'
            }`}
          >
            <LayoutGrid className="w-3.5 h-3.5" />
            <span>All Products</span>
          </button>

          <button
            onClick={() => setSelectedSection('trending')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer flex items-center gap-1.5 ${
              selectedSection === 'trending'
                ? 'bg-orange-600 text-white shadow-sm shadow-orange-500/20'
                : 'bg-white dark:bg-slate-800/90 text-slate-600 dark:text-slate-300 hover:bg-orange-50 dark:hover:bg-orange-950/40 hover:text-orange-700 dark:hover:text-orange-400 border border-slate-200 dark:border-slate-700'
            }`}
          >
            <Flame className="w-3.5 h-3.5 text-orange-500" />
            <span>🔥 Trending Products</span>
          </button>

          <button
            onClick={() => setSelectedSection('bestseller')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer flex items-center gap-1.5 ${
              selectedSection === 'bestseller'
                ? 'bg-amber-600 text-white shadow-sm shadow-amber-500/20'
                : 'bg-white dark:bg-slate-800/90 text-slate-600 dark:text-slate-300 hover:bg-amber-50 dark:hover:bg-amber-950/40 hover:text-amber-700 dark:hover:text-amber-400 border border-slate-200 dark:border-slate-700'
            }`}
          >
            <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
            <span>⭐ Best Sellers</span>
          </button>

          <button
            onClick={() => setSelectedSection('new')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer flex items-center gap-1.5 ${
              selectedSection === 'new'
                ? 'bg-blue-600 text-white shadow-sm shadow-blue-500/20'
                : 'bg-white dark:bg-slate-800/90 text-slate-600 dark:text-slate-300 hover:bg-blue-50 dark:hover:bg-blue-950/40 hover:text-blue-700 dark:hover:text-blue-400 border border-slate-200 dark:border-slate-700'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-blue-500" />
            <span>🆕 New Arrivals</span>
          </button>

          <button
            onClick={() => setSelectedSection('deals')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer flex items-center gap-1.5 ${
              selectedSection === 'deals'
                ? 'bg-rose-600 text-white shadow-sm shadow-rose-500/20'
                : 'bg-white dark:bg-slate-800/90 text-slate-600 dark:text-slate-300 hover:bg-rose-50 dark:hover:bg-rose-950/40 hover:text-rose-700 dark:hover:text-rose-400 border border-slate-200 dark:border-slate-700'
            }`}
          >
            <Tag className="w-3.5 h-3.5 text-rose-500" />
            <span>💥 Deals & Offers</span>
          </button>

          {(selectedCategory !== 'all' || selectedSection !== 'all' || searchQuery) && (
            <button
              onClick={resetFilters}
              className="ml-auto text-xs text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300 font-semibold flex items-center gap-1 cursor-pointer whitespace-nowrap"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Reset Filters</span>
            </button>
          )}
        </div>
      </div>

      {/* Products Grid or Empty State */}
      {filteredProducts.length > 0 ? (
        <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-6 pt-6">
          {filteredProducts.map(product => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      ) : (
        <div className="py-16 text-center space-y-4 max-w-md mx-auto">
          <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto text-slate-400">
            <SearchX className="w-8 h-8" />
          </div>
          <h3 className="text-lg font-bold text-slate-900">No products found</h3>
          <p className="text-xs text-slate-500">
            We couldn't find any products matching your current filters or search term. Try resetting your search or exploring other categories.
          </p>
          <button
            onClick={resetFilters}
            className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl transition-colors cursor-pointer shadow-xs"
          >
            View All Products
          </button>
        </div>
      )}
    </section>
  );
};
