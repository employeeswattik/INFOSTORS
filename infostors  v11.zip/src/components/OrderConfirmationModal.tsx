import React from 'react';
import { CheckCircle2, Package, Truck, ArrowRight, X, Phone, Download } from 'lucide-react';
import { useShop } from '../context/ShopContext';

export const OrderConfirmationModal: React.FC = () => {
  const { isOrderSuccessOpen, setIsOrderSuccessOpen, activeOrder, storeSettings } = useShop();

  if (!isOrderSuccessOpen || !activeOrder) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div className="bg-white dark:bg-slate-900 w-full max-w-lg rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-6 py-6 bg-gradient-to-r from-emerald-600 to-teal-600 text-white text-center relative shrink-0">
          <button
            onClick={() => setIsOrderSuccessOpen(false)}
            className="absolute top-4 right-4 p-1.5 rounded-full bg-white/20 hover:bg-white/30 text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="w-16 h-16 rounded-full bg-white/20 backdrop-blur-xs flex items-center justify-center mx-auto mb-3">
            <CheckCircle2 className="w-10 h-10 text-white" />
          </div>

          <h2 className="text-2xl font-black tracking-tight">Order Confirmed!</h2>
          <p className="text-emerald-100 text-xs mt-1">
            Thank you for ordering with {storeSettings.storeName || 'INFOSTORS'}
          </p>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-5 text-slate-800 dark:text-slate-100 text-xs">
          <div className="bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 rounded-2xl p-4 flex items-center justify-between">
            <div>
              <p className="text-[11px] font-semibold text-emerald-800 dark:text-emerald-300">Order Reference</p>
              <p className="text-base font-extrabold text-emerald-950 dark:text-emerald-100 font-mono">
                {activeOrder.orderId}
              </p>
            </div>
            <div className="text-right">
              <p className="text-[11px] font-semibold text-emerald-800 dark:text-emerald-300">Total Paid</p>
              <p className="text-base font-extrabold text-emerald-950 dark:text-emerald-100">
                ₹{activeOrder.totalAmount?.toLocaleString('en-IN')}
              </p>
            </div>
          </div>

          {/* Customer & Shipping Summary */}
          <div className="space-y-2 border-b border-slate-100 dark:border-slate-800 pb-4">
            <h4 className="font-bold text-slate-900 dark:text-white uppercase tracking-wider text-[11px]">
              Delivery Details
            </h4>
            <p className="font-medium text-slate-700 dark:text-slate-300">
              {activeOrder.customer?.fullName} • {activeOrder.customer?.phone}
            </p>
            <p className="text-slate-500 dark:text-slate-400">
              {activeOrder.customer?.address}, {activeOrder.customer?.city}, {activeOrder.customer?.state} - {activeOrder.customer?.pincode}
            </p>
          </div>

          {/* Items */}
          <div className="space-y-2">
            <h4 className="font-bold text-slate-900 dark:text-white uppercase tracking-wider text-[11px]">
              Items ({activeOrder.items?.length || 0})
            </h4>
            <div className="divide-y divide-slate-100 dark:divide-slate-800 max-h-40 overflow-y-auto">
              {activeOrder.items?.map((item, idx) => (
                <div key={idx} className="py-2 flex items-center justify-between">
                  <div className="flex items-center gap-2 min-w-0">
                    {item.product?.image && (
                      <img
                        src={item.product.image}
                        alt={item.product.name}
                        className="w-10 h-10 object-cover rounded-lg shrink-0 border border-slate-200 dark:border-slate-800"
                      />
                    )}
                    <div className="min-w-0">
                      <p className="font-bold text-slate-800 dark:text-slate-200 truncate">{item.product?.name}</p>
                      <span className="text-[11px] text-slate-400">Qty: {item.quantity}</span>
                    </div>
                  </div>
                  <span className="font-bold text-slate-900 dark:text-white shrink-0 ml-2">
                    ₹{((item.product?.price || 0) * item.quantity).toLocaleString('en-IN')}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer actions */}
        <div className="p-4 bg-slate-50 dark:bg-slate-950 border-t border-slate-200 dark:border-slate-800 flex gap-3 shrink-0">
          <button
            onClick={() => {
              setIsOrderSuccessOpen(false);
            }}
            className="flex-1 py-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-md transition-all cursor-pointer"
          >
            <span>Continue Shopping</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
