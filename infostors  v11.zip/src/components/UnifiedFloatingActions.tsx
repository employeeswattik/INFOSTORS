import React, { useState } from 'react';
import { Smartphone, Check, Download, ExternalLink, X, Loader2 } from 'lucide-react';
import { useShop } from '../context/ShopContext';
import { WhatsAppIcon } from './WhatsAppIcon';
import { usePwaInstall } from '../utils/usePwaInstall';

export const UnifiedFloatingActions: React.FC = () => {
  const {
    storeSettings,
    isCartOpen,
    isCheckoutOpen,
    isAdminOpen,
    isOrderSuccessOpen,
    searchQuery,
  } = useShop();

  const { isInstalled, isStandalone, canInstall, promptInstall, isAndroid, isIOS, isDesktop } =
    usePwaInstall();

  const [installGuideOpen, setInstallGuideOpen] = useState(false);
  const [downloadingState, setDownloadingState] = useState(false);
  const [downloadNotice, setDownloadNotice] = useState<string | null>(null);

  const pwa = storeSettings.pwaSettings;

  // Master toggles from admin settings
  const pwaEnabled = pwa?.pwaInstallEnabled !== false;
  const showInstallBtn = pwa?.showInstallButton !== false;
  const isWhatsappEnabled = pwa?.whatsappFloatingEnabled !== false;
  const whatsappAnimation = Boolean(pwa?.whatsappAnimationEnabled);
  const buttonSize = pwa?.whatsappButtonSize || 'compact';
  const position = pwa?.whatsappPosition || 'bottom-right';
  const animationEnabled = pwa?.installAnimationEnabled !== false;
  const installText = pwa?.installButtonText?.trim() || 'Install App';

  // APK availability
  const isApkEnabled = pwa?.enableApkDownload !== false;
  const hasUploadedApk = Boolean(pwa?.apkDetails?.fileName && pwa?.apkDetails?.status === 'available');
  const apkAvailableForAndroid = isAndroid && isApkEnabled && hasUploadedApk;

  // Google Play Store availability
  const isPlayStoreEnabled = pwa?.playStoreEnabled !== false;
  const playStoreUrl = pwa?.playStoreUrl?.trim();
  const showPlayStore = isPlayStoreEnabled && Boolean(playStoreUrl) && !isIOS; // iOS devices don't use Google Play Store

  // Desktop visibility switch
  const desktopInstallAllowed = pwa?.desktopInstallEnabled !== false;

  // Never show Install App if already running as installed standalone app or flagged installed
  let showInstallApp = showInstallBtn && !isInstalled && !isStandalone;

  // On desktop, obey desktopInstallEnabled switch
  if (isDesktop && !desktopInstallAllowed) {
    showInstallApp = false;
  }

  // On non-Android and non-iOS (generic desktop/laptop), only show if PWA or install action is possible
  if (isDesktop && !canInstall && !pwaEnabled) {
    showInstallApp = false;
  }

  // If both WhatsApp and Install App are disabled or not applicable, render nothing
  if (!isWhatsappEnabled && !showInstallApp && !showPlayStore) {
    return null;
  }

  // Section 7, 16, 17: NEVER disturb customer shopping!
  // Temporarily hide floating controls during Search, Cart drawer, Checkout modal, or Admin screens
  if (isCartOpen || isCheckoutOpen || isAdminOpen || isOrderSuccessOpen || searchQuery.trim().length > 0) {
    return null;
  }

  const handleWhatsAppClick = () => {
    const rawNumber = (
      storeSettings.whatsappNotificationSettings?.businessNumber ||
      storeSettings.helpline ||
      '9477839200'
    ).replace(/[^0-9]/g, '');

    const fullNumber = rawNumber.startsWith('91') ? rawNumber : `91${rawNumber}`;
    const text = encodeURIComponent(
      `Hi ${storeSettings.storeName || 'INFOSTORS'}! I have an inquiry regarding your products and orders.`
    );
    window.open(`https://wa.me/${fullNumber}?text=${text}`, '_blank', 'noopener,noreferrer');
  };

  const handlePlayStoreClick = () => {
    if (playStoreUrl) {
      // Track analytics if enabled
      fetch('/api/app/track-download', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type: 'playstore' }),
      }).catch(() => {});
      window.open(playStoreUrl, '_blank', 'noopener,noreferrer');
    }
  };

  const handleInstallClick = async () => {
    // 1. Android + APK Available: Download official APK
    if (apkAvailableForAndroid) {
      setDownloadingState(true);

      // Trigger download tracking
      fetch('/api/app/track-download', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type: 'apk', version: pwa?.apkDetails?.version }),
      }).catch(() => {});

      // Trigger native APK download
      const apkLink = document.createElement('a');
      apkLink.href = '/api/app/download-apk';
      apkLink.download = pwa?.apkDetails?.fileName || 'infostors.apk';
      document.body.appendChild(apkLink);
      apkLink.click();
      document.body.removeChild(apkLink);

      setTimeout(() => {
        setDownloadingState(false);
        setDownloadNotice('APK Downloaded. Tap your notification bar to install.');
        setTimeout(() => setDownloadNotice(null), 5000);
      }, 1500);
      return;
    }

    // 2. Real Native PWA Prompt available
    if (canInstall) {
      const res = await promptInstall();
      if (res.outcome === 'accepted') {
        fetch('/api/app/track-download', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ type: 'pwa' }),
        }).catch(() => {});
        setDownloadNotice('App installed successfully!');
        setTimeout(() => setDownloadNotice(null), 4000);
      }
      return;
    }

    // 3. Fallback for iOS or browser without direct beforeinstallprompt
    setInstallGuideOpen(prev => !prev);
  };

  const isPositionLeft = position === 'bottom-left';

  return (
    <aside
      aria-label="Quick Actions and App Installation"
      className={`fixed z-30 flex flex-col gap-2 transition-all duration-300 pointer-events-auto ${
        isPositionLeft
          ? 'left-3 sm:left-6 items-start bottom-[calc(4.75rem+env(safe-area-inset-bottom))] sm:bottom-6'
          : 'right-3 sm:right-6 items-end bottom-[calc(4.75rem+env(safe-area-inset-bottom))] sm:bottom-6'
      }`}
    >
      {/* iOS / Browser Native Instruction Popover (Only opens if native prompt is not available) */}
      {installGuideOpen && (
        <div
          role="dialog"
          aria-label="PWA Installation Guide"
          className={`mb-1 w-72 sm:w-80 p-3 bg-slate-900/95 dark:bg-slate-950/95 text-white text-xs rounded-2xl shadow-2xl border border-slate-700/80 backdrop-blur-md animate-in fade-in slide-in-from-bottom-2 z-50`}
        >
          <div className="flex items-start justify-between gap-2 pb-2 border-b border-slate-800">
            <div className="flex items-center gap-1.5">
              <span className="p-1 rounded-lg bg-blue-600/30 text-blue-400">
                <Smartphone className="w-3.5 h-3.5" />
              </span>
              <span className="font-bold text-slate-100 text-[11px]">Install INFOSTORS App</span>
            </div>
            <button
              type="button"
              onClick={() => setInstallGuideOpen(false)}
              className="text-slate-400 hover:text-white p-0.5 rounded cursor-pointer"
              aria-label="Close installation guide"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="mt-2 space-y-1.5 text-[11px] text-slate-300 leading-relaxed">
            {isIOS ? (
              <div className="bg-slate-800/80 p-2 rounded-xl border border-slate-700/50 space-y-1">
                <p className="font-semibold text-blue-300">🍎 iPhone / iPad (Safari):</p>
                <p>
                  Tap the <strong>Share</strong> button (⎋) at the bottom, then scroll and select <strong>"Add to Home Screen"</strong>.
                </p>
              </div>
            ) : (
              <div className="bg-slate-800/80 p-2 rounded-xl border border-slate-700/50 space-y-1">
                <p className="font-semibold text-emerald-300">Browser Menu:</p>
                <p>
                  Open browser menu (<strong>⋮</strong>) and tap <strong>"Install app"</strong> or <strong>"Add to Home screen"</strong>.
                </p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Subtle notification toast for download progress */}
      {downloadNotice && (
        <div className="px-3 py-1.5 bg-slate-900/95 dark:bg-slate-950/95 text-white text-[11px] font-bold rounded-xl shadow-xl border border-slate-700/80 flex items-center gap-1.5 animate-in fade-in">
          <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
          <span>{downloadNotice}</span>
        </div>
      )}

      {/* 1. Install App Button (Positioned ABOVE WhatsApp as per Section 4 & 14) */}
      {showInstallApp && (
        <button
          type="button"
          onClick={handleInstallClick}
          disabled={downloadingState}
          id="floating-install-app-btn"
          aria-label={installText}
          className={`group relative inline-flex items-center gap-1.5 px-3 py-1.5 sm:px-3.5 sm:py-2 rounded-full bg-slate-900/90 hover:bg-slate-950 dark:bg-slate-800/90 dark:hover:bg-slate-750 text-white text-xs font-bold shadow-lg shadow-slate-950/20 border border-slate-700/80 hover:border-blue-500/50 backdrop-blur-md transition-all duration-200 hover:scale-[1.02] active:scale-95 cursor-pointer whitespace-nowrap ${
            animationEnabled && !downloadingState
              ? 'animate-[pulse_3s_ease-in-out_infinite] motion-reduce:animate-none'
              : ''
          }`}
          title={apkAvailableForAndroid ? 'Download Android APK' : 'Install INFOSTORS App'}
        >
          {downloadingState ? (
            <>
              <Loader2 className="w-3.5 h-3.5 text-blue-400 animate-spin shrink-0" />
              <span className="font-extrabold tracking-tight text-[11px]">Downloading APK...</span>
            </>
          ) : (
            <>
              {apkAvailableForAndroid ? (
                <Download className="w-3.5 h-3.5 text-blue-400 group-hover:text-blue-300 transition-colors shrink-0" />
              ) : (
                <Smartphone className="w-3.5 h-3.5 text-blue-400 group-hover:text-blue-300 transition-colors shrink-0" />
              )}
              <span className="font-extrabold tracking-tight text-[11px]">
                {installText}
              </span>
            </>
          )}
        </button>
      )}

      {/* 2. Optional Google Play Store Button (Tiny pill if configured and enabled) */}
      {showPlayStore && (
        <button
          type="button"
          onClick={handlePlayStoreClick}
          id="floating-play-store-btn"
          aria-label="Google Play Store"
          className="group inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-slate-900/85 hover:bg-slate-950 dark:bg-slate-800/85 text-white text-[10px] font-bold shadow-md border border-slate-700/70 hover:border-emerald-500/50 backdrop-blur-md transition-all duration-200 hover:scale-[1.02] active:scale-95 cursor-pointer"
          title="Open in Google Play Store"
        >
          <ExternalLink className="w-3 h-3 text-emerald-400" />
          <span className="text-slate-200 group-hover:text-white">Google Play</span>
        </button>
      )}

      {/* 3. Compact Circular WhatsApp Button (Positioned BELOW Install App) */}
      {isWhatsappEnabled && (
        <button
          type="button"
          onClick={handleWhatsAppClick}
          aria-label="Chat with INFOSTORS on WhatsApp"
          id="floating-whatsapp-btn"
          className={`group relative rounded-full bg-[#25D366] hover:bg-[#20ba5a] text-white flex items-center justify-center transition-all duration-200 hover:scale-105 active:scale-95 cursor-pointer shadow-lg shadow-emerald-600/30 shrink-0 ${
            buttonSize === 'standard' ? 'w-10 h-10 sm:w-11 sm:h-11' : 'w-9 h-9 sm:w-9.5 sm:h-9.5'
          } ${whatsappAnimation ? 'animate-pulse motion-reduce:animate-none' : ''}`}
          title="Chat on WhatsApp"
        >
          <WhatsAppIcon className={buttonSize === 'standard' ? 'w-5 h-5 fill-white' : 'w-4.5 h-4.5 fill-white'} />
        </button>
      )}
    </aside>
  );
};
