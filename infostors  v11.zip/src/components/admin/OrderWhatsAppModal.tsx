import React, { useState, useEffect, useMemo } from 'react';
import { X, Send, RotateCcw, Eye, Check, AlertCircle, ChevronLeft, ChevronRight } from 'lucide-react';
import { Order, StoreSettings } from '../../types';
import { WhatsAppIcon } from '../WhatsAppIcon';
import {
  OFFICIAL_DEFAULT_TEMPLATES,
  interpolateWhatsAppMessage,
} from '../../services/whatsappNotificationService';

interface OrderWhatsAppModalProps {
  isOpen: boolean;
  onClose: () => void;
  order: Order | null;
  orders?: Order[];
  storeSettings: StoreSettings;
}

export type WhatsAppActionType = 'received' | 'dispatched' | 'delivered';

export const OrderWhatsAppModal: React.FC<OrderWhatsAppModalProps> = ({
  isOpen,
  onClose,
  order,
  orders = [],
  storeSettings,
}) => {
  const activeOrders = useMemo(() => {
    if (orders && orders.length > 0) return orders;
    if (order) return [order];
    return [];
  }, [orders, order]);

  const [currentIndex, setCurrentIndex] = useState(0);
  const safeCurrentIndex = Math.min(Math.max(0, currentIndex), Math.max(0, activeOrders.length - 1));
  const currentOrder = activeOrders[safeCurrentIndex] || null;

  const [selectedType, setSelectedType] = useState<WhatsAppActionType>('received');
  const [customMessages, setCustomMessages] = useState<Record<WhatsAppActionType, string>>({
    received: '',
    dispatched: '',
    delivered: '',
  });

  // Pull saved templates or official defaults
  useEffect(() => {
    const saved = storeSettings.whatsappNotificationSettings?.templates as any;
    setCustomMessages({
      received: saved?.order_confirmed?.body || OFFICIAL_DEFAULT_TEMPLATES.received,
      dispatched: saved?.order_dispatched?.body || OFFICIAL_DEFAULT_TEMPLATES.dispatched,
      delivered: saved?.order_delivered?.body || OFFICIAL_DEFAULT_TEMPLATES.delivered,
    });
  }, [storeSettings.whatsappNotificationSettings]);

  if (!isOpen || !currentOrder) return null;

  const currentTemplate = customMessages[selectedType] || OFFICIAL_DEFAULT_TEMPLATES[selectedType];
  const resolvedMessage = interpolateWhatsAppMessage(currentTemplate, currentOrder, storeSettings);

  const handleMessageChange = (val: string) => {
    setCustomMessages(prev => ({ ...prev, [selectedType]: val }));
  };

  const handleRestoreDefault = () => {
    setCustomMessages(prev => ({ ...prev, [selectedType]: OFFICIAL_DEFAULT_TEMPLATES[selectedType] }));
  };

  const sendForOrder = (ord: Order) => {
    const msg = interpolateWhatsAppMessage(currentTemplate, ord, storeSettings);
    const rawPhone = ord.customer?.phone?.replace(/[^0-9]/g, '') || '';
    const fullPhone = rawPhone.startsWith('91') ? rawPhone : `91${rawPhone}`;
    window.open(
      `https://wa.me/${fullPhone}?text=${encodeURIComponent(msg)}`,
      '_blank',
      'noopener,noreferrer'
    );
  };

  const handleSend = () => {
    sendForOrder(currentOrder);
    if (safeCurrentIndex < activeOrders.length - 1) {
      setCurrentIndex(prev => prev + 1);
    } else {
      onClose();
    }
  };

  const isApiConfigured = Boolean(
    storeSettings.whatsAppApiSettings?.status === 'CONNECTED' &&
    storeSettings.whatsAppApiSettings?.phoneNumberId
  );

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-150">
      <div className="bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-100 w-full max-w-xl rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col max-h-[94vh]">
        {/* Modal Header */}
        <div className="px-5 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-emerald-500/10 text-emerald-500 flex items-center justify-center">
              <WhatsAppIcon className="w-4 h-4 fill-[#25D366]" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                <span>Customer WhatsApp Notification</span>
                {activeOrders.length > 1 && (
                  <span className="px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 text-[10px] font-mono font-bold">
                    {safeCurrentIndex + 1} of {activeOrders.length} Selected
                  </span>
                )}
              </h3>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">Order #{currentOrder.orderId} • {currentOrder.customer?.fullName}</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {activeOrders.length > 1 && (
              <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 px-2 py-1 rounded-xl">
                <button
                  type="button"
                  onClick={() => setCurrentIndex(prev => Math.max(0, prev - 1))}
                  disabled={safeCurrentIndex === 0}
                  className="p-1 rounded text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-white disabled:opacity-30 cursor-pointer"
                  title="Previous order"
                >
                  <ChevronLeft className="w-3.5 h-3.5" />
                </button>
                <span className="text-[11px] font-mono font-bold px-1 text-slate-700 dark:text-slate-300">
                  {safeCurrentIndex + 1}/{activeOrders.length}
                </span>
                <button
                  type="button"
                  onClick={() => setCurrentIndex(prev => Math.min(activeOrders.length - 1, prev + 1))}
                  disabled={safeCurrentIndex === activeOrders.length - 1}
                  className="p-1 rounded text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-white disabled:opacity-30 cursor-pointer"
                  title="Next order"
                >
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>
            )}
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg cursor-pointer transition-colors"
              title="Close"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-5 space-y-4 text-xs overflow-y-auto">
          {/* Action Tabs: Received / Dispatched / Delivered */}
          <div>
            <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1.5">
              Notification Status Trigger
            </label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setSelectedType('received')}
                className={`py-2 px-3 rounded-xl font-bold text-xs transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                  selectedType === 'received'
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
                }`}
              >
                <span>🟢 Received</span>
              </button>
              <button
                type="button"
                onClick={() => setSelectedType('dispatched')}
                className={`py-2 px-3 rounded-xl font-bold text-xs transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                  selectedType === 'dispatched'
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
                }`}
              >
                <span>🔵 Dispatched</span>
              </button>
              <button
                type="button"
                onClick={() => setSelectedType('delivered')}
                className={`py-2 px-3 rounded-xl font-bold text-xs transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                  selectedType === 'delivered'
                    ? 'bg-purple-600 text-white shadow-xs'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
                }`}
              >
                <span>🟢 Delivered</span>
              </button>
            </div>
          </div>

          {/* Editable Template Area */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="font-bold text-slate-700 dark:text-slate-300">
                Message Template (Editable for this dispatch)
              </label>
              <button
                type="button"
                onClick={handleRestoreDefault}
                className="text-[11px] text-slate-500 hover:text-emerald-600 dark:hover:text-emerald-400 flex items-center gap-1 cursor-pointer"
                title="Restore default message template"
              >
                <RotateCcw className="w-3 h-3" />
                <span>Restore Default</span>
              </button>
            </div>
            <textarea
              rows={5}
              value={currentTemplate}
              onChange={e => handleMessageChange(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-xl outline-none font-mono text-[11px] text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500"
            />
          </div>

          {/* Live Preview Section styled like WhatsApp chat bubble */}
          <div className="bg-[#EFEAE2] dark:bg-slate-950 p-4 rounded-xl border border-slate-300 dark:border-slate-800 space-y-1.5">
            <div className="flex items-center justify-between text-[11px] font-bold text-slate-700 dark:text-slate-300">
              <span className="flex items-center gap-1.5 text-emerald-800 dark:text-emerald-400">
                <WhatsAppIcon className="w-3.5 h-3.5 fill-[#25D366]" />
                <span>Live Formatted Preview (Sent to +91 {currentOrder.customer?.phone})</span>
              </span>
            </div>
            <div className="bg-white dark:bg-slate-850 p-3.5 rounded-2xl shadow-md border border-slate-200 dark:border-slate-800 text-[11.5px] leading-relaxed whitespace-pre-wrap font-sans text-slate-900 dark:text-slate-100">
              {resolvedMessage}
            </div>
          </div>

          {/* Multi-Order Queue List if multiple orders selected */}
          {activeOrders.length > 1 && (
            <div className="p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-200 dark:border-slate-800 space-y-2">
              <span className="text-[10px] uppercase font-bold text-slate-500 block">
                Selected Orders Queue ({activeOrders.length})
              </span>
              <div className="space-y-1.5 max-h-36 overflow-y-auto pr-1">
                {activeOrders.map((ord, idx) => (
                  <div
                    key={ord.orderId}
                    className={`flex items-center justify-between p-2 rounded-lg text-[11px] border transition-all ${
                      idx === safeCurrentIndex
                        ? 'bg-emerald-50 dark:bg-emerald-950/30 border-emerald-300 dark:border-emerald-700'
                        : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800'
                    }`}
                  >
                    <div>
                      <span className="font-bold text-slate-900 dark:text-white">#{ord.orderId}</span>
                      <span className="text-slate-400 ml-1.5">• {ord.customer?.fullName} (+91 {ord.customer?.phone})</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => setCurrentIndex(idx)}
                        className="text-[10px] text-blue-600 hover:underline font-semibold cursor-pointer"
                      >
                        Preview
                      </button>
                      <button
                        type="button"
                        onClick={() => sendForOrder(ord)}
                        className="px-2 py-0.5 bg-[#25D366] hover:bg-[#20ba5a] text-white rounded font-bold text-[10px] flex items-center gap-1 cursor-pointer shadow-xs"
                        title={`Open WhatsApp for ${ord.customer?.fullName}`}
                      >
                        <WhatsAppIcon className="w-2.5 h-2.5 fill-white" />
                        <span>Send</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Dispatch Channel status info */}
          <div className="flex items-center justify-between px-3 py-2 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200 dark:border-slate-800 text-[10px] text-slate-500">
            <span>Dispatch Channel:</span>
            <span className="font-bold text-slate-700 dark:text-slate-300">
              {isApiConfigured ? 'WhatsApp Business Cloud API' : 'Direct WhatsApp Web / App (+91 ' + (currentOrder.customer?.phone || '') + ')'}
            </span>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-5 py-3.5 bg-slate-50 dark:bg-slate-850 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between shrink-0">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-800 font-bold text-xs cursor-pointer transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={handleSend}
            className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl flex items-center gap-2 shadow-md cursor-pointer transition-colors"
            id="btn-send-whatsapp-order"
          >
            <WhatsAppIcon className="w-4 h-4 fill-white" />
            <span>{activeOrders.length > 1 ? `Send & Next (${safeCurrentIndex + 1}/${activeOrders.length})` : 'Open WhatsApp & Send'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
