import React, { useState } from 'react';
import { Store, Plus, Trash2, Check, X, Building, Phone, Mail, Percent, AlertCircle } from 'lucide-react';
import { useShop } from '../../context/ShopContext';
import { Vendor } from '../../types';
import { safeConfirm } from '../../utils/safeBrowser';

export const AdminVendorsTab: React.FC = () => {
  const { vendors, saveVendor, deleteVendor } = useShop();

  const [isCreating, setIsCreating] = useState(false);
  const [editingVendor, setEditingVendor] = useState<Vendor | null>(null);

  const [formData, setFormData] = useState<Partial<Vendor>>({
    storeName: '',
    ownerName: '',
    email: '',
    phone: '',
    commissionRate: 10,
    status: 'active',
    city: 'Kolkata',
    state: 'West Bengal',
  });

  const [statusMessage, setStatusMessage] = useState<string | null>(null);

  const handleOpenCreate = () => {
    setEditingVendor(null);
    setFormData({
      storeName: '',
      ownerName: '',
      email: '',
      phone: '',
      commissionRate: 10,
      status: 'active',
      city: 'Kolkata',
      state: 'West Bengal',
    });
    setIsCreating(true);
  };

  const handleOpenEdit = (v: Vendor) => {
    setEditingVendor(v);
    setFormData({ ...v });
    setIsCreating(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.storeName?.trim()) return;

    const payload: Partial<Vendor> = {
      ...formData,
      commissionRate: Number(formData.commissionRate || 10),
    };
    if (editingVendor) payload.id = editingVendor.id;

    const res = await saveVendor(payload);
    if (res.success) {
      setStatusMessage(editingVendor ? 'Vendor updated successfully.' : 'Vendor onboarded successfully.');
      setIsCreating(false);
      setEditingVendor(null);
      setTimeout(() => setStatusMessage(null), 3000);
    }
  };

  const handleDelete = async (id: string, name: string) => {
    if (!safeConfirm(`Delete vendor "${name}"?`)) return;
    const res = await deleteVendor(id);
    if (res.success) {
      setStatusMessage('Vendor deleted.');
      setTimeout(() => setStatusMessage(null), 3000);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-900 border border-slate-800 rounded-2xl p-5 text-white">
        <div>
          <div className="flex items-center gap-2">
            <Store className="w-5 h-5 text-blue-400" />
            <h2 className="text-lg font-black tracking-tight">Multi-Vendor Marketplace & Commission Hub</h2>
            <span className="text-[10px] bg-blue-500/20 text-blue-300 border border-blue-400/30 px-2 py-0.5 rounded-full font-bold">
              {vendors.length} Vendors
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Manage partner vendor stores, commission percentages, compliance details, and vendor listings.
          </p>
        </div>

        <button
          type="button"
          onClick={handleOpenCreate}
          className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 cursor-pointer shadow-md transition self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Onboard Vendor</span>
        </button>
      </div>

      {statusMessage && (
        <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs rounded-xl flex items-center gap-2">
          <Check className="w-4 h-4" />
          <span>{statusMessage}</span>
        </div>
      )}

      {/* Editor Modal */}
      {isCreating && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 text-white space-y-4 shadow-xl">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <h3 className="font-bold text-sm text-white">
              {editingVendor ? 'Edit Vendor Details' : 'Onboard New Vendor Partner'}
            </h3>
            <button
              type="button"
              onClick={() => setIsCreating(false)}
              className="text-slate-400 hover:text-white p-1"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Store / Business Name *</label>
                <input
                  type="text"
                  required
                  value={formData.storeName}
                  onChange={e => setFormData({ ...formData, storeName: e.target.value })}
                  placeholder="e.g. Apex Tech Hub"
                  className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-xs font-bold text-white focus:border-blue-500 outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Owner / Contact Name</label>
                <input
                  type="text"
                  value={formData.ownerName}
                  onChange={e => setFormData({ ...formData, ownerName: e.target.value })}
                  placeholder="e.g. Rajesh Ghosh"
                  className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-xs text-white focus:border-blue-500 outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Commission Rate (%) *</label>
                <input
                  type="number"
                  min={0}
                  max={50}
                  required
                  value={formData.commissionRate}
                  onChange={e => setFormData({ ...formData, commissionRate: Number(e.target.value) })}
                  className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-xs font-bold text-white focus:border-blue-500 outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Email Address</label>
                <input
                  type="email"
                  value={formData.email}
                  onChange={e => setFormData({ ...formData, email: e.target.value })}
                  placeholder="vendor@example.com"
                  className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-xs text-white focus:border-blue-500 outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Phone / Mobile</label>
                <input
                  type="tel"
                  value={formData.phone}
                  onChange={e => setFormData({ ...formData, phone: e.target.value })}
                  placeholder="10-digit mobile"
                  className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-xs text-white focus:border-blue-500 outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Status</label>
                <select
                  value={formData.status}
                  onChange={e => setFormData({ ...formData, status: e.target.value as any })}
                  className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-xs font-semibold text-white focus:border-blue-500 outline-none"
                >
                  <option value="active">Active & Authorized</option>
                  <option value="pending">Pending Approval</option>
                  <option value="suspended">Suspended</option>
                </select>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-3 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setIsCreating(false)}
                className="px-4 py-2 bg-slate-800 text-slate-300 text-xs font-bold rounded-xl"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold rounded-xl shadow-md"
              >
                {editingVendor ? 'Save Changes' : 'Onboard Vendor'}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Vendors Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-950/80 text-[11px] uppercase font-bold text-slate-400 border-b border-slate-800">
              <tr>
                <th className="py-3 px-4">Vendor Store</th>
                <th className="py-3 px-4">Owner / Contact</th>
                <th className="py-3 px-4">Commission</th>
                <th className="py-3 px-4">Products / Sales</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80">
              {vendors.length > 0 ? (
                vendors.map(v => (
                  <tr key={v.id} className="hover:bg-slate-800/40 transition">
                    <td className="py-3 px-4">
                      <div className="font-bold text-white text-sm">{v.storeName}</div>
                      <div className="text-[10px] text-slate-500 font-mono">ID: {v.id}</div>
                    </td>

                    <td className="py-3 px-4">
                      <div className="font-semibold text-slate-200">{v.ownerName || '—'}</div>
                      <div className="text-[10px] text-slate-400">{v.phone} • {v.email}</div>
                    </td>

                    <td className="py-3 px-4">
                      <span className="font-bold text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20">
                        {v.commissionRate}%
                      </span>
                    </td>

                    <td className="py-3 px-4">
                      <div>{v.totalProducts || 0} Listed</div>
                      <div className="text-[10px] text-emerald-400 font-bold">
                        ₹{(v.totalSales || 0).toLocaleString('en-IN')} Sales
                      </div>
                    </td>

                    <td className="py-3 px-4">
                      <span
                        className={`text-[10px] font-extrabold px-2.5 py-0.5 rounded-full uppercase ${
                          v.status === 'active'
                            ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                            : v.status === 'pending'
                            ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                            : 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                        }`}
                      >
                        {v.status}
                      </span>
                    </td>

                    <td className="py-3 px-4 text-right space-x-2">
                      <button
                        type="button"
                        onClick={() => handleOpenEdit(v)}
                        className="text-slate-400 hover:text-white font-semibold transition"
                      >
                        Edit
                      </button>
                      <button
                        type="button"
                        onClick={() => handleDelete(v.id, v.storeName)}
                        className="text-rose-400 hover:text-rose-300 font-semibold transition"
                      >
                        Delete
                      </button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-slate-500">
                    No vendor partners onboarded yet. Single-store mode active.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
