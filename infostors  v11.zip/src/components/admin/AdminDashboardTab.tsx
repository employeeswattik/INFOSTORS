import React from 'react';
import { 
  Package, 
  ShoppingCart, 
  Users, 
  IndianRupee, 
  TrendingUp, 
  Truck, 
  AlertTriangle, 
  ArrowRight, 
  Printer, 
  FileText, 
  MessageCircle,
  Clock
} from 'lucide-react';
import { Order, Product, Category, StoreSettings, PaymentSettingsInfo } from '../../types';

interface AdminDashboardTabProps {
  orders: Order[];
  products: Product[];
  categories: Category[];
  customers: any[];
  storeSettings: StoreSettings;
  paymentSettings?: PaymentSettingsInfo;
  onNavigateTab: (tab: string) => void;
  onSelectShippingLabel: (order: Order) => void;
  onSelectInvoice: (order: Order) => void;
  onOpenDispatchModal: (order: Order) => void;
  onOpenWhatsAppModal: (order: Order) => void;
}

export const AdminDashboardTab: React.FC<AdminDashboardTabProps> = ({
  orders,
  products,
  categories,
  customers,
  storeSettings,
  onNavigateTab,
  onSelectShippingLabel,
  onSelectInvoice,
  onOpenDispatchModal,
  onOpenWhatsAppModal,
}) => {
  const totalRevenue = orders.reduce((sum, o) => sum + (o.totalAmount || 0), 0);
  const pendingOrders = orders.filter(o => o.status === 'confirmed' || o.status === 'processing');
  const lowStockProducts = products.filter(p => (p.stock || 0) <= 5);

  return (
    <div className="space-y-6 text-slate-800 dark:text-slate-100">
      {/* Top Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-slate-850 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs flex items-center justify-between">
          <div>
            <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Gross Sales</p>
            <p className="text-xl font-extrabold text-slate-900 dark:text-white mt-1">
              ₹{totalRevenue.toLocaleString('en-IN')}
            </p>
            <p className="text-[10px] text-emerald-600 font-semibold flex items-center gap-1 mt-0.5">
              <TrendingUp className="w-3 h-3" />
              <span>{orders.length} total orders</span>
            </p>
          </div>
          <div className="w-12 h-12 rounded-xl bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 flex items-center justify-center">
            <IndianRupee className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-white dark:bg-slate-850 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs flex items-center justify-between">
          <div>
            <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Pending Fulfillment</p>
            <p className="text-xl font-extrabold text-amber-600 mt-1">
              {pendingOrders.length}
            </p>
            <p className="text-[10px] text-slate-400 font-medium mt-0.5">Requires packing & dispatch</p>
          </div>
          <div className="w-12 h-12 rounded-xl bg-amber-50 dark:bg-amber-950/60 text-amber-600 flex items-center justify-center">
            <Clock className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-white dark:bg-slate-850 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs flex items-center justify-between">
          <div>
            <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Total Products</p>
            <p className="text-xl font-extrabold text-slate-900 dark:text-white mt-1">
              {products.length}
            </p>
            <p className="text-[10px] text-slate-400 font-medium mt-0.5">{categories.length} categories active</p>
          </div>
          <div className="w-12 h-12 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
            <Package className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-white dark:bg-slate-850 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs flex items-center justify-between">
          <div>
            <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Registered Users</p>
            <p className="text-xl font-extrabold text-slate-900 dark:text-white mt-1">
              {customers.length}
            </p>
            <p className="text-[10px] text-slate-400 font-medium mt-0.5">Customer profiles</p>
          </div>
          <div className="w-12 h-12 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
            <Users className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* Low Stock Warning if any */}
      {lowStockProducts.length > 0 && (
        <div className="bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 rounded-2xl p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0" />
            <div>
              <p className="font-bold text-xs text-amber-900 dark:text-amber-200">
                Low Stock Alert: {lowStockProducts.length} items have 5 or fewer units left
              </p>
              <p className="text-[11px] text-amber-700 dark:text-amber-300">
                {lowStockProducts.map(p => p.name).slice(0, 3).join(', ')}...
              </p>
            </div>
          </div>
          <button
            onClick={() => onNavigateTab('inventory')}
            className="px-3 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs shrink-0 cursor-pointer"
          >
            Manage Inventory
          </button>
        </div>
      )}

      {/* Recent Orders Overview */}
      <div className="bg-white dark:bg-slate-850 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-xs">
        <div className="px-5 py-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
            <ShoppingCart className="w-4 h-4 text-blue-600" />
            <span>Recent Orders</span>
          </h3>
          <button
            onClick={() => onNavigateTab('orders')}
            className="text-xs font-bold text-blue-600 hover:text-blue-700 flex items-center gap-1 cursor-pointer"
          >
            <span>View All Orders</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
          {orders.slice(0, 5).map(order => (
            <div key={order.orderId} className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center font-mono font-bold text-slate-600 dark:text-slate-300">
                  #{order.orderId.slice(-4)}
                </div>
                <div>
                  <p className="font-bold text-slate-900 dark:text-white">{order.customer?.fullName}</p>
                  <p className="text-[11px] text-slate-400">{order.customer?.phone} • {order.items?.length || 0} items</p>
                </div>
              </div>

              <div className="flex items-center gap-4">
                <div className="text-right">
                  <p className="font-bold text-slate-900 dark:text-white">₹{order.totalAmount?.toLocaleString('en-IN')}</p>
                  <span className="text-[10px] font-semibold uppercase px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                    {order.status}
                  </span>
                </div>

                <div className="flex items-center gap-1">
                  <button
                    onClick={() => onSelectInvoice(order)}
                    title="Print Tax Invoice"
                    className="p-1.5 text-slate-400 hover:text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-950/60 rounded-lg cursor-pointer"
                  >
                    <FileText className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => onSelectShippingLabel(order)}
                    title="Print 4x6 Thermal Label"
                    className="p-1.5 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-950/60 rounded-lg cursor-pointer"
                  >
                    <Printer className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => onOpenWhatsAppModal(order)}
                    title="Send WhatsApp Notification"
                    className="p-1.5 text-slate-400 hover:text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-950/60 rounded-lg cursor-pointer"
                  >
                    <MessageCircle className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => onOpenDispatchModal(order)}
                    title="Update Tracking"
                    className="p-1.5 text-slate-400 hover:text-amber-600 hover:bg-amber-50 dark:hover:bg-amber-950/60 rounded-lg cursor-pointer"
                  >
                    <Truck className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
