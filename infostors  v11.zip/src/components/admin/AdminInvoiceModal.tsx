import React from 'react';
import { X, Printer, Download, FileText, CheckCircle2 } from 'lucide-react';
import { Order, StoreSettings } from '../../types';

interface AdminInvoiceModalProps {
  isOpen: boolean;
  onClose: () => void;
  order: Order | null;
  storeSettings: StoreSettings;
}

export const AdminInvoiceModal: React.FC<AdminInvoiceModalProps> = ({
  isOpen,
  onClose,
  order,
  storeSettings,
}) => {
  if (!isOpen || !order) return null;

  const handlePrint = () => {
    try {
      document.body.classList.add('printing-invoice');
      if (typeof window !== 'undefined' && typeof window.print === 'function') {
        window.print();
      }
    } catch (err) {
      console.warn('Invoice print notice:', err);
    }
  };

  const gstPercentage = storeSettings.gstPercentage || 18;
  const taxableAmount = Math.round((order.totalAmount || 0) / (1 + gstPercentage / 100));
  const gstAmount = (order.totalAmount || 0) - taxableAmount;

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-150">
      <div className="bg-white text-slate-900 w-full max-w-2xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Controls */}
        <div className="px-5 py-3 bg-slate-900 text-white flex items-center justify-between print:hidden">
          <div className="flex items-center gap-2">
            <FileText className="w-4 h-4 text-blue-400" />
            <h3 className="font-bold text-xs">Official Tax Invoice / Bill of Supply</h3>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="px-3 py-1 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded-lg flex items-center gap-1 cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print Invoice</span>
            </button>
            <button onClick={onClose} className="p-1 text-slate-400 hover:text-white cursor-pointer">
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Printable invoice */}
        <div id="invoice-printable" className="p-8 overflow-y-auto space-y-6 text-xs font-sans">
          {/* Header */}
          <div className="flex justify-between items-start border-b border-slate-200 pb-5">
            <div>
              <h1 className="text-2xl font-black tracking-tight text-slate-900">
                {storeSettings.businessLegalName || storeSettings.storeName || 'INFOSTORS'}
              </h1>
              <p className="text-[11px] text-slate-500 mt-1">{storeSettings.officeAddress || 'Kolkata 700084, India'}</p>
              {storeSettings.gstin && (
                <p className="text-[11px] font-mono font-bold text-slate-700">GSTIN: {storeSettings.gstin}</p>
              )}
              <p className="text-[11px] text-slate-500">Helpline: {storeSettings.helpline || '+91 94778 39200'}</p>
            </div>

            <div className="text-right">
              <span className="px-2.5 py-1 rounded-full bg-slate-100 text-slate-700 font-bold uppercase text-[10px]">
                Tax Invoice
              </span>
              <p className="text-sm font-mono font-extrabold text-slate-900 mt-2">{order.orderId}</p>
              <p className="text-[11px] text-slate-500">
                Date: {new Date(order.date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}
              </p>
            </div>
          </div>

          {/* Customer info */}
          <div className="grid grid-cols-2 gap-4 border border-slate-200 rounded-xl p-4 bg-slate-50/50">
            <div>
              <p className="text-[10px] uppercase font-bold text-slate-400">Billed To (Customer)</p>
              <p className="font-bold text-slate-900 text-sm mt-0.5">{order.customer?.fullName}</p>
              <p className="text-slate-600 mt-0.5">{order.customer?.address}</p>
              <p className="text-slate-600">{order.customer?.city}, {order.customer?.state} - {order.customer?.pincode}</p>
              <p className="text-slate-700 font-semibold mt-1">Mobile: +91 {order.customer?.phone}</p>
            </div>

            <div className="text-right">
              <p className="text-[10px] uppercase font-bold text-slate-400">Payment Summary</p>
              <p className="font-bold text-slate-900 uppercase mt-0.5">
                Mode: {order.paymentMethod === 'cod' ? 'Cash on Delivery' : 'Prepaid Online'}
              </p>
              <p className="text-slate-600 mt-0.5">Status: <span className="font-bold text-emerald-600 uppercase">{order.status}</span></p>
              {order.trackingId && (
                <p className="text-slate-600 text-[11px] font-mono mt-1">AWB: {order.trackingId}</p>
              )}
            </div>
          </div>

          {/* Items Table */}
          <div className="border border-slate-200 rounded-xl overflow-hidden">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-100 text-slate-600 font-bold border-b border-slate-200 uppercase text-[10px]">
                <tr>
                  <th className="p-3">#</th>
                  <th className="p-3">Item Description</th>
                  <th className="p-3 text-center">Qty</th>
                  <th className="p-3 text-right">Unit Price</th>
                  <th className="p-3 text-right">Total</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {order.items?.map((item, idx) => (
                  <tr key={idx}>
                    <td className="p-3 text-slate-400 font-mono">{idx + 1}</td>
                    <td className="p-3 font-semibold text-slate-900">{item.product?.name}</td>
                    <td className="p-3 text-center font-bold text-slate-700">{item.quantity}</td>
                    <td className="p-3 text-right font-mono">₹{item.product?.price?.toLocaleString('en-IN')}</td>
                    <td className="p-3 text-right font-mono font-bold text-slate-900">
                      ₹{((item.product?.price || 0) * item.quantity).toLocaleString('en-IN')}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Totals */}
          <div className="flex justify-end">
            <div className="w-64 space-y-1.5 text-right">
              <div className="flex justify-between text-slate-600">
                <span>Subtotal:</span>
                <span className="font-mono">₹{order.subtotal?.toLocaleString('en-IN')}</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>Standard Delivery:</span>
                <span className="font-mono">{order.deliveryCharge === 0 ? 'FREE' : `₹${order.deliveryCharge}`}</span>
              </div>
              {storeSettings.gstEnabled && (
                <div className="flex justify-between text-slate-500 text-[11px]">
                  <span>Estimated GST ({gstPercentage}% incl):</span>
                  <span className="font-mono">₹{gstAmount.toLocaleString('en-IN')}</span>
                </div>
              )}
              <div className="flex justify-between text-sm font-extrabold text-slate-900 pt-2 border-t border-slate-200">
                <span>Total Amount:</span>
                <span className="font-mono text-base text-blue-600">₹{order.totalAmount?.toLocaleString('en-IN')}</span>
              </div>
            </div>
          </div>

          {/* Footer declaration */}
          <div className="border-t border-slate-200 pt-4 text-[10px] text-slate-400 text-center">
            <p>This is a computer generated invoice and does not require a physical signature.</p>
            <p className="mt-0.5">Thank you for your business with {storeSettings.storeName || 'INFOSTORS'}!</p>
          </div>
        </div>
      </div>
    </div>
  );
};
