import React, { useState } from 'react';
import { Sliders, Eye, Check, RotateCcw, Package, Save } from 'lucide-react';
import { StoreSettings, ShippingLabelSettings, Order } from '../../types';
import { ShippingLabelModal } from '../ShippingLabelModal';

interface AdminShippingLabelSettingsSectionProps {
  storeSettings: StoreSettings;
  updateStoreSettings: (settings: StoreSettings) => void;
}

export const AdminShippingLabelSettingsSection: React.FC<AdminShippingLabelSettingsSectionProps> = ({
  storeSettings,
  updateStoreSettings,
}) => {
  const [config, setConfig] = useState<ShippingLabelSettings>(
    storeSettings.shippingLabelSettings || {
      preset: 'standard',
      showLogo: true,
      showStoreName: true,
      showDate: true,
      showCustomerPhone: true,
      showCustomerEmail: false,
      showPickupLocation: true,
      showPickupContact: true,
      showSellerInfo: true,
      showPaymentMethod: true,
      showCodAmount: true,
      showOrderTotal: true,
      showProductSummary: true,
      showQuantity: true,
      showWeight: true,
      showCustomerNote: true,
      showSpecialInstructions: true,
      showCourier: true,
      showTrackingNumber: true,
      showDeliveryNumber: true,
      showOrderId: true,
      showHeader: true,
      showCustomerDetails: true,
      showDeliveryDetails: true,
      showPickupDetails: true,
      showOrderDetails: true,
      showPaymentDetails: true,
      showCourierDetails: true,
      showCodeArea: true,
      showFooter: true,
      showBarcode: true,
      showQrCode: true,
      pickupLocation: {
        companyName: 'INFOSTORS Fulfillment Hub',
        address: 'Garia Station Road, Near Metro Gate 2',
        city: 'Kolkata',
        state: 'West Bengal',
        pincode: '700084',
        contactNumber: '+91 94778 39200',
        instructions: 'Handle with care. Store dry.',
      },
    }
  );

  const [saved, setSaved] = useState(false);
  const [previewOpen, setPreviewOpen] = useState(false);

  // Sample order for real-time previewing
  const sampleOrder: Order = {
    orderId: 'INF-20260926-1001',
    date: new Date().toISOString(),
    status: 'processing',
    subtotal: 1899,
    deliveryCharge: 0,
    discountSavings: 0,
    totalAmount: 1899,
    paymentMethod: 'cod',
    courierPartner: 'Delhivery Express',
    trackingId: 'INF8934120',
    estimatedDeliveryDate: new Date(Date.now() + 3 * 86400000).toISOString(),
    customer: {
      fullName: 'Rahul Sharma',
      email: 'rahul.sharma@example.com',
      phone: '9876543210',
      address: 'Plot 42, Southern Avenue, Lake Gardens',
      city: 'Kolkata',
      state: 'West Bengal',
      pincode: '700029',
    },
    items: [
      {
        productId: 'inf-101',
        name: 'AeroBeat Pro ANC Wireless Earbuds',
        price: 1899,
        quantity: 1,
      } as any,
    ],
  };

  const handleSave = () => {
    updateStoreSettings({
      ...storeSettings,
      shippingLabelSettings: config,
    });
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  };

  const applyPreset = (presetKey: 'standard' | 'minimal' | 'full' | 'courier' | 'pickup' | 'cod') => {
    let nextConfig = { ...config, preset: presetKey };
    if (presetKey === 'minimal') {
      nextConfig = {
        ...nextConfig,
        showCustomerEmail: false,
        showProductSummary: false,
        showPickupDetails: false,
        showCustomerNote: false,
        showFooter: false,
      };
    } else if (presetKey === 'full') {
      nextConfig = {
        ...nextConfig,
        showCustomerEmail: true,
        showProductSummary: true,
        showPickupDetails: true,
        showCustomerNote: true,
        showFooter: true,
        showBarcode: true,
        showQrCode: true,
      };
    } else if (presetKey === 'courier') {
      nextConfig = {
        ...nextConfig,
        showCourierDetails: true,
        showBarcode: true,
        showQrCode: true,
        showProductSummary: false,
      };
    } else if (presetKey === 'pickup') {
      nextConfig = {
        ...nextConfig,
        showPickupDetails: true,
        showPickupLocation: true,
        showPickupContact: true,
      };
    } else if (presetKey === 'cod') {
      nextConfig = {
        ...nextConfig,
        showPaymentDetails: true,
        showCodAmount: true,
        showOrderTotal: true,
      };
    } else {
      nextConfig = {
        ...nextConfig,
        showHeader: true,
        showCustomerDetails: true,
        showDeliveryDetails: true,
        showPickupDetails: true,
        showOrderDetails: true,
        showPaymentDetails: true,
        showCourierDetails: true,
        showCodeArea: true,
        showFooter: true,
        showBarcode: true,
        showQrCode: true,
      };
    }
    setConfig(nextConfig);
    updateStoreSettings({ ...storeSettings, shippingLabelSettings: nextConfig });
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const handleResetDefaults = () => {
    const defaults: ShippingLabelSettings = {
      preset: 'standard',
      showLogo: true,
      showStoreName: true,
      showDate: true,
      showCustomerPhone: true,
      showCustomerMobile: true,
      showCustomerEmail: false,
      showPickupLocation: true,
      showPickupContact: true,
      showSellerInfo: true,
      showPaymentMethod: true,
      showCodAmount: true,
      showOrderTotal: true,
      showProductSummary: true,
      showQuantity: true,
      showWeight: true,
      showCustomerNote: true,
      showSpecialInstructions: true,
      showCourier: true,
      showTrackingNumber: true,
      showDeliveryNumber: true,
      showOrderId: true,
      showHeader: true,
      showCustomerDetails: true,
      showDeliveryDetails: true,
      showPickupDetails: true,
      showOrderDetails: true,
      showPaymentDetails: true,
      showCourierDetails: true,
      showCodeArea: true,
      showFooter: true,
      showBarcode: true,
      showQrCode: true,
      pickupLocation: {
        companyName: 'INFOSTORS Fulfillment Hub',
        address: 'Garia Station Road, Near Metro Gate 2',
        city: 'Kolkata',
        state: 'West Bengal',
        pincode: '700084',
        contactNumber: '+91 94778 39200',
        instructions: 'Handle with care. Store dry.',
      },
    };
    setConfig(defaults);
    updateStoreSettings({ ...storeSettings, shippingLabelSettings: defaults });
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <div className="space-y-6 text-xs text-slate-800 dark:text-slate-100 max-w-4xl">
      {/* Header with Save, Preview, Reset */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-200 dark:border-slate-800">
        <div>
          <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Package className="w-4 h-4 text-blue-600" />
            <span>Shipping Label Settings (100mm × 150mm Courier Label)</span>
          </h3>
          <p className="text-[11px] text-slate-400">
            Configure presets, field visibility, return hub details, and dual scannable codes (1 Barcode + 1 QR Code).
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setPreviewOpen(true)}
            className="px-3 py-1.5 bg-blue-50 dark:bg-blue-950/60 hover:bg-blue-100 text-blue-600 dark:text-blue-400 border border-blue-200 dark:border-blue-800 font-bold rounded-xl flex items-center gap-1.5 cursor-pointer transition-colors"
          >
            <Eye className="w-3.5 h-3.5" />
            <span>Preview Label (100×150mm)</span>
          </button>

          <button
            type="button"
            onClick={handleResetDefaults}
            className="px-3 py-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-400 font-bold rounded-xl flex items-center gap-1.5 cursor-pointer transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Restore Default</span>
          </button>

          <button
            type="button"
            onClick={handleSave}
            className="px-4 py-1.5 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl flex items-center gap-1.5 shadow-xs cursor-pointer transition-colors"
          >
            {saved ? <Check className="w-4 h-4 text-white" /> : <Save className="w-4 h-4" />}
            <span>{saved ? 'Saved!' : 'Save Settings'}</span>
          </button>
        </div>
      </div>

      {/* 1. Layout Presets (Requirement 30) */}
      <div className="bg-white dark:bg-slate-850 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-3">
        <div className="flex items-center justify-between">
          <span className="font-bold text-xs uppercase tracking-wider text-slate-700 dark:text-slate-300">
            Layout Presets
          </span>
          <span className="text-[10px] text-slate-400">Click a preset to instantly reconfigure visibility</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-6 gap-2">
          {(['standard', 'minimal', 'full', 'courier', 'pickup', 'cod'] as const).map(pKey => (
            <button
              key={pKey}
              type="button"
              onClick={() => applyPreset(pKey)}
              className={`p-2 rounded-xl text-xs font-bold capitalize transition-all cursor-pointer border text-center ${
                config.preset === pKey
                  ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                  : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100'
              }`}
            >
              {pKey}
            </button>
          ))}
        </div>
      </div>

      {/* 2. Dual Code Elements: EXACTLY 1D Barcode + 2D QR Code (Requirement 24, 25, 26, 55) */}
      <div className="bg-white dark:bg-slate-850 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-3">
        <span className="font-bold text-xs uppercase tracking-wider text-slate-700 dark:text-slate-300 block">
          Machine-Readable Code Controls (1 Barcode + 1 QR Code)
        </span>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <label className="flex items-center gap-2.5 p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 cursor-pointer">
            <input
              type="checkbox"
              checked={config.showBarcode !== false}
              onChange={e => setConfig({ ...config, showBarcode: e.target.checked })}
              className="w-4 h-4 rounded text-blue-600 focus:ring-blue-500 cursor-pointer"
            />
            <div>
              <span className="font-bold text-slate-800 dark:text-slate-200 block">
                1D BARCODE (Code128) [ ON / OFF ]
              </span>
              <span className="text-[10px] text-slate-500 dark:text-slate-400">
                Encodes tracking / order ID with human-readable text
              </span>
            </div>
          </label>

          <label className="flex items-center gap-2.5 p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 cursor-pointer">
            <input
              type="checkbox"
              checked={config.showQrCode !== false}
              onChange={e => setConfig({ ...config, showQrCode: e.target.checked })}
              className="w-4 h-4 rounded text-blue-600 focus:ring-blue-500 cursor-pointer"
            />
            <div>
              <span className="font-bold text-slate-800 dark:text-slate-200 block">
                2D QR CODE [ ON / OFF ]
              </span>
              <span className="text-[10px] text-slate-500 dark:text-slate-400">
                Encodes instant order verification & online tracking link
              </span>
            </div>
          </label>
        </div>
      </div>

      {/* 3. Field Visibility Grid (Requirement 28) */}
      <div className="bg-white dark:bg-slate-850 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-3">
        <span className="font-bold text-xs uppercase tracking-wider text-slate-700 dark:text-slate-300 block">
          Field Visibility Controls
        </span>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
          {[
            { key: 'showCustomerPhone', label: 'Customer Mobile' },
            { key: 'showCustomerEmail', label: 'Customer Email' },
            { key: 'showProductSummary', label: 'Product Summary' },
            { key: 'showPaymentMethod', label: 'Payment Method' },
            { key: 'showCodAmount', label: 'COD Collectable Amount' },
            { key: 'showOrderTotal', label: 'Order Total' },
            { key: 'showCourier', label: 'Courier Partner' },
            { key: 'showTrackingNumber', label: 'Tracking / AWB Number' },
            { key: 'showOrderId', label: 'Order ID' },
            { key: 'showPickupLocation', label: 'Return Hub Address' },
            { key: 'showPickupContact', label: 'Return Hub Phone' },
            { key: 'showSpecialInstructions', label: 'Special Instructions' },
          ].map(field => (
            <label
              key={field.key}
              className="flex items-center justify-between p-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 cursor-pointer"
            >
              <span className="font-medium text-slate-700 dark:text-slate-300 text-[11px]">{field.label}</span>
              <input
                type="checkbox"
                checked={(config as any)[field.key] !== false}
                onChange={e => setConfig({ ...config, [field.key]: e.target.checked })}
                className="w-4 h-4 rounded text-blue-600 focus:ring-blue-500 cursor-pointer"
              />
            </label>
          ))}
        </div>
      </div>

      {/* 4. Dedicated Pickup & Return Hub Location (Requirement 28, 49) */}
      <div className="bg-white dark:bg-slate-850 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-3">
        <span className="font-bold text-xs uppercase tracking-wider text-slate-700 dark:text-slate-300 block">
          Return / Fulfillment Hub Location
        </span>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">
              Hub / Company Name
            </label>
            <input
              type="text"
              value={config.pickupLocation?.companyName || ''}
              onChange={e =>
                setConfig({
                  ...config,
                  pickupLocation: {
                    ...config.pickupLocation!,
                    companyName: e.target.value,
                  },
                })
              }
              className="w-full px-3 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl outline-none"
            />
          </div>

          <div>
            <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">
              Contact Helpline Phone
            </label>
            <input
              type="text"
              value={config.pickupLocation?.contactNumber || ''}
              onChange={e =>
                setConfig({
                  ...config,
                  pickupLocation: {
                    ...config.pickupLocation!,
                    contactNumber: e.target.value,
                  },
                })
              }
              className="w-full px-3 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl outline-none"
            />
          </div>

          <div className="sm:col-span-2">
            <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">
              Full Street Address
            </label>
            <input
              type="text"
              value={config.pickupLocation?.address || ''}
              onChange={e =>
                setConfig({
                  ...config,
                  pickupLocation: {
                    ...config.pickupLocation!,
                    address: e.target.value,
                  },
                })
              }
              className="w-full px-3 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl outline-none"
            />
          </div>
        </div>
      </div>

      {/* Live Preview Modal */}
      {previewOpen && (
        <ShippingLabelModal
          isOpen={previewOpen}
          onClose={() => setPreviewOpen(false)}
          order={sampleOrder}
          storeSettings={{
            ...storeSettings,
            shippingLabelSettings: config,
          }}
        />
      )}
    </div>
  );
};
