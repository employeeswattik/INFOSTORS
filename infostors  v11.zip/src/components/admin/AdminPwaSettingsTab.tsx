import React, { useState, useRef } from 'react';
import {
  Smartphone,
  Save,
  Check,
  RotateCcw,
  ExternalLink,
  Play,
  Globe,
  Eye,
  MessageCircle,
  AlertCircle,
  Upload,
  Trash2,
  Download,
  BarChart3,
  Loader2,
  FileCode2,
  RefreshCw,
} from 'lucide-react';
import { useShop } from '../../context/ShopContext';
import { DEFAULT_PWA_SETTINGS, PwaSettings } from '../../types';
import { WhatsAppIcon } from '../WhatsAppIcon';
import { safeConfirm } from '../../utils/safeBrowser';

export const AdminPwaSettingsTab: React.FC = () => {
  const { storeSettings, updateStoreSettings } = useShop();
  const currentPwa = storeSettings.pwaSettings || DEFAULT_PWA_SETTINGS;

  const [pwa, setPwa] = useState<PwaSettings>(currentPwa);
  const [saved, setSaved] = useState(false);
  const [showPreview, setShowPreview] = useState(false);
  const [toastNotice, setToastNotice] = useState<string | null>(null);

  // APK Upload States
  const [isUploadingApk, setIsUploadingApk] = useState(false);
  const [isRemovingApk, setIsRemovingApk] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const showToast = (msg: string) => {
    setToastNotice(msg);
    setTimeout(() => setToastNotice(null), 3500);
  };

  const getAdminToken = () => {
    return localStorage.getItem('infostors_admin_token') || '';
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateStoreSettings({ ...storeSettings, pwaSettings: pwa });
    setSaved(true);
    showToast('Mobile application, PWA and WhatsApp settings saved successfully!');
    setTimeout(() => setSaved(false), 2500);
  };

  const handleRestoreDefault = () => {
    setPwa(DEFAULT_PWA_SETTINGS);
    updateStoreSettings({ ...storeSettings, pwaSettings: DEFAULT_PWA_SETTINGS });
    setSaved(true);
    showToast('Reset to official application & WhatsApp defaults!');
    setTimeout(() => setSaved(false), 2500);
  };

  const handleOpenPlayStore = () => {
    if (pwa.playStoreUrl?.trim()) {
      window.open(pwa.playStoreUrl.trim(), '_blank', 'noopener,noreferrer');
    } else {
      showToast('Google Play Store URL is not configured yet. Please enter a valid URL below.');
    }
  };

  // Handle Real APK File Upload
  const handleApkFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.name.toLowerCase().endsWith('.apk')) {
      showToast('Invalid file format. Please select a valid Android APK file (.apk).');
      if (fileInputRef.current) fileInputRef.current.value = '';
      return;
    }

    if (file.size > 150 * 1024 * 1024) {
      showToast('APK file size exceeds maximum limit of 150MB.');
      if (fileInputRef.current) fileInputRef.current.value = '';
      return;
    }

    setIsUploadingApk(true);
    try {
      const reader = new FileReader();
      reader.onload = async () => {
        try {
          const base64Data = reader.result as string;
          const token = getAdminToken();

          const res = await fetch('/api/admin/app/upload-apk', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              Authorization: `Bearer ${token}`,
            },
            body: JSON.stringify({
              fileName: file.name,
              fileBase64: base64Data,
              version: pwa.apkDetails?.version || '1.0.0',
              appName: pwa.appName || 'INFOSTORS',
            }),
          });

          const data = await res.json();
          if (data.success && data.apkDetails) {
            const nextPwa: PwaSettings = {
              ...pwa,
              enableApkDownload: true,
              apkDetails: data.apkDetails,
              apkDownloadUrl: data.apkDetails.downloadUrl,
              appDownloadUrl: data.apkDetails.downloadUrl,
            };
            setPwa(nextPwa);
            updateStoreSettings({ ...storeSettings, pwaSettings: nextPwa });
            showToast('APK file uploaded and published to customers successfully!');
          } else {
            showToast(data.error || 'Failed to upload APK file.');
          }
        } catch (err: any) {
          showToast(err?.message || 'Error processing APK upload.');
        } finally {
          setIsUploadingApk(false);
          if (fileInputRef.current) fileInputRef.current.value = '';
        }
      };
      reader.onerror = () => {
        showToast('Error reading the selected APK file.');
        setIsUploadingApk(false);
      };
      reader.readAsDataURL(file);
    } catch (err: any) {
      showToast(err?.message || 'Failed to initiate APK upload.');
      setIsUploadingApk(false);
    }
  };

  // Handle APK File Removal
  const handleRemoveApk = async () => {
    if (!safeConfirm('Are you sure you want to remove the currently active APK file? Customers will no longer be able to download it.')) {
      return;
    }

    setIsRemovingApk(true);
    try {
      const token = getAdminToken();
      const res = await fetch('/api/admin/app/remove-apk', {
        method: 'DELETE',
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      const data = await res.json();
      if (data.success) {
        const nextPwa: PwaSettings = {
          ...pwa,
          enableApkDownload: false,
          apkDownloadUrl: '',
          appDownloadUrl: '',
          apkDetails: {
            enabled: false,
            appName: pwa.appName || 'INFOSTORS',
            version: '',
            fileName: '',
            fileSize: 0,
            fileSizeFormatted: '',
            storagePath: '',
            downloadUrl: '',
            uploadDate: '',
            status: 'not_uploaded',
          },
        };
        setPwa(nextPwa);
        updateStoreSettings({ ...storeSettings, pwaSettings: nextPwa });
        showToast('APK file removed successfully.');
      } else {
        showToast(data.error || 'Failed to remove APK.');
      }
    } catch (err: any) {
      showToast(err?.message || 'Error removing APK.');
    } finally {
      setIsRemovingApk(false);
    }
  };

  const isPlayStoreConfigured = Boolean(pwa.playStoreUrl?.trim());
  const hasUploadedApk = Boolean(pwa.apkDetails?.fileName && pwa.apkDetails?.status === 'available');

  return (
    <form onSubmit={handleSubmit} className="space-y-6 text-xs text-slate-800 dark:text-slate-100 max-w-4xl">
      {/* Toast Notification */}
      {toastNotice && (
        <div className="fixed top-4 right-4 z-50 px-4 py-2.5 rounded-xl bg-slate-900 text-white font-bold text-xs shadow-2xl border border-slate-700 flex items-center gap-2 animate-in fade-in slide-in-from-top-2">
          <AlertCircle className="w-4 h-4 text-blue-400 shrink-0" />
          <span>{toastNotice}</span>
        </div>
      )}

      {/* Header with Save, Preview, and Restore Default buttons */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-200 dark:border-slate-800">
        <div>
          <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Smartphone className="w-4 h-4 text-blue-600" />
            <span>Mobile Application, APK Download & PWA Control</span>
          </h3>
          <p className="text-[11px] text-slate-400">
            Manage official Android APK file upload, Google Play Store integration, PWA settings, and micro floating actions.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setShowPreview(!showPreview)}
            className="px-3 py-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-bold rounded-xl flex items-center gap-1.5 cursor-pointer transition-colors"
            title="Preview Mobile App buttons"
          >
            <Eye className="w-3.5 h-3.5" />
            <span>{showPreview ? 'Hide Preview' : 'Preview'}</span>
          </button>

          <button
            type="button"
            onClick={handleRestoreDefault}
            className="px-3 py-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-400 font-bold rounded-xl flex items-center gap-1.5 cursor-pointer transition-colors"
            title="Restore defaults"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Restore Default</span>
          </button>

          <button
            type="submit"
            className="px-4 py-1.5 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl flex items-center gap-1.5 shadow-xs cursor-pointer transition-colors"
            id="btn-save-pwa-settings"
          >
            {saved ? <Check className="w-4 h-4 text-white" /> : <Save className="w-4 h-4" />}
            <span>{saved ? 'Saved!' : 'Save Settings'}</span>
          </button>
        </div>
      </div>

      {/* Application Status Overview Dashboard (Section 19) */}
      <div className="bg-slate-900 text-white p-4 rounded-2xl border border-slate-800 space-y-3">
        <div className="flex items-center justify-between pb-2 border-b border-slate-800">
          <span className="font-bold text-xs uppercase tracking-wider text-slate-300 flex items-center gap-2">
            <Smartphone className="w-4 h-4 text-blue-400" />
            <span>Mobile Application Live Status</span>
          </span>
          <div className="flex items-center gap-3 text-[11px]">
            <span className="flex items-center gap-1.5">
              <span className={`w-2 h-2 rounded-full ${hasUploadedApk && pwa.enableApkDownload !== false ? 'bg-emerald-400 animate-pulse' : 'bg-slate-500'}`} />
              <span className="text-slate-300">APK {hasUploadedApk ? (pwa.enableApkDownload !== false ? 'Available' : 'Disabled') : 'Not Uploaded'}</span>
            </span>
            <span className="flex items-center gap-1.5">
              <span className={`w-2 h-2 rounded-full ${pwa.pwaInstallEnabled !== false ? 'bg-blue-400' : 'bg-slate-500'}`} />
              <span className="text-slate-300">PWA {pwa.pwaInstallEnabled !== false ? 'Active' : 'Disabled'}</span>
            </span>
            <span className="flex items-center gap-1.5">
              <span className={`w-2 h-2 rounded-full ${isPlayStoreConfigured && pwa.playStoreEnabled !== false ? 'bg-emerald-400' : 'bg-slate-500'}`} />
              <span className="text-slate-300">Play Store {isPlayStoreConfigured ? 'Configured' : 'Not Configured'}</span>
            </span>
          </div>
        </div>

        {/* Live Preview Box when active */}
        {showPreview && (
          <div className="p-4 bg-slate-850 rounded-xl border border-slate-700/80 flex items-center justify-center">
            {/* Action Pill Group Preview */}
            <div className="flex flex-col items-end gap-1.5">
              {pwa.showInstallButton !== false && (
                <div
                  className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-gradient-to-r from-blue-600 to-indigo-600 text-white text-[11px] font-bold shadow-md ${
                    pwa.installAnimationEnabled !== false ? 'animate-pulse' : ''
                  }`}
                >
                  <Smartphone className="w-3.5 h-3.5 text-blue-200" />
                  <span>{pwa.installButtonText || 'Install App'}</span>
                </div>
              )}

              {pwa.whatsappFloatingEnabled !== false && (
                <div
                  className={`rounded-full bg-[#25D366] text-white flex items-center justify-center shadow-md ${
                    pwa.whatsappButtonSize === 'standard' ? 'w-10 h-10' : 'w-9 h-9'
                  }`}
                >
                  <WhatsAppIcon className={pwa.whatsappButtonSize === 'standard' ? 'w-5 h-5 fill-white' : 'w-4 h-4 fill-white'} />
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* 1. Dedicated Android APK Upload & Storage Section (Sections 2 & 3) */}
      <div className="bg-white dark:bg-slate-850 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
          <div>
            <h4 className="font-bold text-slate-900 dark:text-white text-xs uppercase tracking-wider flex items-center gap-2">
              <FileCode2 className="w-3.5 h-3.5 text-emerald-500" />
              <span>Android APK File Management & Storage</span>
            </h4>
            <p className="text-[11px] text-slate-400 mt-0.5">
              Upload real Android package files (.apk). Automatically stored and served with genuine Android package headers.
            </p>
          </div>
          <span className={`text-[10px] font-extrabold px-2.5 py-0.5 rounded-full ${pwa.enableApkDownload !== false ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400' : 'bg-slate-100 text-slate-500'}`}>
            {pwa.enableApkDownload !== false ? 'APK DOWNLOAD ON' : 'APK DOWNLOAD OFF'}
          </span>
        </div>

        {/* Master APK Toggle */}
        <label className="flex items-center gap-2.5 p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 cursor-pointer">
          <input
            type="checkbox"
            checked={pwa.enableApkDownload !== false}
            onChange={e => setPwa({ ...pwa, enableApkDownload: e.target.checked })}
            className="w-4 h-4 rounded text-blue-600 focus:ring-blue-500 cursor-pointer"
          />
          <div>
            <span className="font-bold text-slate-800 dark:text-slate-200 block">
              Enable App Download [ ON / OFF ]
            </span>
            <span className="text-[10px] text-slate-500 dark:text-slate-400">
              When ON, Android customers tapping "Install App" will download the official APK file directly.
            </span>
          </div>
        </label>

        {/* App Name & Version Metadata */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">Application Name</label>
            <input
              type="text"
              value={pwa.appName || 'INFOSTORS'}
              onChange={e => setPwa({ ...pwa, appName: e.target.value })}
              placeholder="INFOSTORS"
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl outline-none font-semibold text-slate-900 dark:text-white"
            />
          </div>

          <div>
            <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">Application Version</label>
            <input
              type="text"
              value={pwa.apkDetails?.version || '1.0.0'}
              onChange={e =>
                setPwa({
                  ...pwa,
                  apkDetails: {
                    ...(pwa.apkDetails || {
                      enabled: true,
                      appName: pwa.appName || 'INFOSTORS',
                      fileName: '',
                      fileSize: 0,
                      fileSizeFormatted: '',
                      storagePath: '',
                      downloadUrl: '',
                      uploadDate: new Date().toISOString(),
                      status: 'not_uploaded',
                    }),
                    version: e.target.value,
                  },
                })
              }
              placeholder="1.0.0"
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl outline-none font-mono text-slate-900 dark:text-white"
            />
          </div>
        </div>

        {/* Current APK File Card */}
        <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-3">
          <div className="flex items-center justify-between">
            <span className="font-bold text-slate-700 dark:text-slate-200 text-xs flex items-center gap-1.5">
              <Download className="w-3.5 h-3.5 text-blue-500" />
              <span>Current Configured APK:</span>
            </span>
            <span
              className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                hasUploadedApk ? 'bg-emerald-500/20 text-emerald-600 dark:text-emerald-400' : 'bg-slate-200 text-slate-600'
              }`}
            >
              {hasUploadedApk ? 'Active & Ready' : 'No APK Uploaded'}
            </span>
          </div>

          {hasUploadedApk ? (
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-[11px] bg-white dark:bg-slate-800 p-3 rounded-xl border border-slate-200 dark:border-slate-700">
              <div>
                <span className="text-slate-400 block text-[10px]">File Name:</span>
                <span className="font-mono font-bold text-slate-800 dark:text-slate-100 truncate block">
                  {pwa.apkDetails?.fileName}
                </span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px]">Version:</span>
                <span className="font-bold text-slate-800 dark:text-slate-100">{pwa.apkDetails?.version || '1.0.0'}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px]">File Size:</span>
                <span className="font-bold text-slate-800 dark:text-slate-100">{pwa.apkDetails?.fileSizeFormatted || '14.8 MB'}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px]">Upload Date:</span>
                <span className="font-medium text-slate-600 dark:text-slate-300">
                  {pwa.apkDetails?.uploadDate ? new Date(pwa.apkDetails.uploadDate).toLocaleDateString() : 'Active'}
                </span>
              </div>
            </div>
          ) : (
            <div className="text-slate-400 text-center py-3 text-[11px]">
              No APK file currently uploaded. Upload an APK below to enable direct customer downloads on Android.
            </div>
          )}

          {/* Action Buttons: Upload / Replace / Remove / Test Download */}
          <div className="flex flex-wrap items-center gap-2 pt-1">
            <input
              type="file"
              ref={fileInputRef}
              accept=".apk,application/vnd.android.package-archive"
              onChange={handleApkFileSelect}
              className="hidden"
            />

            <button
              type="button"
              disabled={isUploadingApk}
              onClick={() => fileInputRef.current?.click()}
              className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl flex items-center gap-1.5 cursor-pointer disabled:opacity-50 transition-colors"
            >
              {isUploadingApk ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  <span>Uploading APK...</span>
                </>
              ) : hasUploadedApk ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Replace APK</span>
                </>
              ) : (
                <>
                  <Upload className="w-3.5 h-3.5" />
                  <span>Upload APK</span>
                </>
              )}
            </button>

            {hasUploadedApk && (
              <>
                <button
                  type="button"
                  disabled={isRemovingApk}
                  onClick={handleRemoveApk}
                  className="px-3.5 py-1.5 bg-rose-600/10 hover:bg-rose-600 text-rose-600 hover:text-white font-bold rounded-xl flex items-center gap-1.5 cursor-pointer transition-colors"
                >
                  {isRemovingApk ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Trash2 className="w-3.5 h-3.5" />}
                  <span>Remove APK</span>
                </button>

                <a
                  href="/api/app/download-apk"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-3.5 py-1.5 bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 text-slate-800 dark:text-slate-100 font-bold rounded-xl flex items-center gap-1.5 cursor-pointer transition-colors"
                >
                  <Download className="w-3.5 h-3.5 text-blue-500" />
                  <span>Test APK Download</span>
                </a>
              </>
            )}
          </div>
        </div>
      </div>

      {/* 2. Admin Feature Switches (Section 18) */}
      <div className="bg-white dark:bg-slate-850 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-4">
        <div className="pb-3 border-b border-slate-100 dark:border-slate-800">
          <h4 className="font-bold text-slate-900 dark:text-white text-xs uppercase tracking-wider flex items-center gap-2">
            <Globe className="w-3.5 h-3.5 text-blue-500" />
            <span>Mobile Application Feature Switches</span>
          </h4>
          <p className="text-[11px] text-slate-400 mt-0.5">
            Configure master switches for application downloads, PWA triggers, floating actions, animations, and platforms.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
          <label className="flex items-center gap-2.5 p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 cursor-pointer">
            <input
              type="checkbox"
              checked={pwa.enableApkDownload !== false}
              onChange={e => setPwa({ ...pwa, enableApkDownload: e.target.checked })}
              className="w-4 h-4 rounded text-blue-600 focus:ring-blue-500 cursor-pointer"
            />
            <div>
              <span className="font-bold text-slate-800 dark:text-slate-200 block text-[11px]">APK Download</span>
              <span className="text-[10px] text-slate-500">Android direct APK download</span>
            </div>
          </label>

          <label className="flex items-center gap-2.5 p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 cursor-pointer">
            <input
              type="checkbox"
              checked={pwa.pwaInstallEnabled !== false}
              onChange={e => setPwa({ ...pwa, pwaInstallEnabled: e.target.checked })}
              className="w-4 h-4 rounded text-blue-600 focus:ring-blue-500 cursor-pointer"
            />
            <div>
              <span className="font-bold text-slate-800 dark:text-slate-200 block text-[11px]">PWA Installation</span>
              <span className="text-[10px] text-slate-500">Native browser web app install</span>
            </div>
          </label>

          <label className="flex items-center gap-2.5 p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 cursor-pointer">
            <input
              type="checkbox"
              checked={pwa.showInstallButton !== false}
              onChange={e => setPwa({ ...pwa, showInstallButton: e.target.checked })}
              className="w-4 h-4 rounded text-blue-600 focus:ring-blue-500 cursor-pointer"
            />
            <div>
              <span className="font-bold text-slate-800 dark:text-slate-200 block text-[11px]">Install App Button</span>
              <span className="text-[10px] text-slate-500">Floating install CTA visibility</span>
            </div>
          </label>

          <label className="flex items-center gap-2.5 p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 cursor-pointer">
            <input
              type="checkbox"
              checked={pwa.installAnimationEnabled !== false}
              onChange={e => setPwa({ ...pwa, installAnimationEnabled: e.target.checked })}
              className="w-4 h-4 rounded text-blue-600 focus:ring-blue-500 cursor-pointer"
            />
            <div>
              <span className="font-bold text-slate-800 dark:text-slate-200 block text-[11px]">Install App Animation</span>
              <span className="text-[10px] text-slate-500">Subtle breathing pulse</span>
            </div>
          </label>

          <label className="flex items-center gap-2.5 p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 cursor-pointer">
            <input
              type="checkbox"
              checked={pwa.whatsappFloatingEnabled !== false}
              onChange={e => setPwa({ ...pwa, whatsappFloatingEnabled: e.target.checked })}
              className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500 cursor-pointer"
            />
            <div>
              <span className="font-bold text-slate-800 dark:text-slate-200 block text-[11px]">WhatsApp Button</span>
              <span className="text-[10px] text-slate-500">Compact floating circular trigger</span>
            </div>
          </label>

          <label className="flex items-center gap-2.5 p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 cursor-pointer">
            <input
              type="checkbox"
              checked={pwa.playStoreEnabled !== false}
              onChange={e => setPwa({ ...pwa, playStoreEnabled: e.target.checked })}
              className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500 cursor-pointer"
            />
            <div>
              <span className="font-bold text-slate-800 dark:text-slate-200 block text-[11px]">Google Play Store</span>
              <span className="text-[10px] text-slate-500">Play Store badge & link</span>
            </div>
          </label>

          <label className="flex items-center gap-2.5 p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 cursor-pointer">
            <input
              type="checkbox"
              checked={pwa.desktopInstallEnabled !== false}
              onChange={e => setPwa({ ...pwa, desktopInstallEnabled: e.target.checked })}
              className="w-4 h-4 rounded text-blue-600 focus:ring-blue-500 cursor-pointer"
            />
            <div>
              <span className="font-bold text-slate-800 dark:text-slate-200 block text-[11px]">Desktop Install Button</span>
              <span className="text-[10px] text-slate-500">Show on desktop/laptop</span>
            </div>
          </label>

          <label className="flex items-center gap-2.5 p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 cursor-pointer">
            <input
              type="checkbox"
              checked={pwa.mobileInstallEnabled !== false}
              onChange={e => setPwa({ ...pwa, mobileInstallEnabled: e.target.checked })}
              className="w-4 h-4 rounded text-blue-600 focus:ring-blue-500 cursor-pointer"
            />
            <div>
              <span className="font-bold text-slate-800 dark:text-slate-200 block text-[11px]">Mobile Install Button</span>
              <span className="text-[10px] text-slate-500">Show on smartphone devices</span>
            </div>
          </label>

          <label className="flex items-center gap-2.5 p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 cursor-pointer">
            <input
              type="checkbox"
              checked={pwa.downloadAnalyticsEnabled !== false}
              onChange={e => setPwa({ ...pwa, downloadAnalyticsEnabled: e.target.checked })}
              className="w-4 h-4 rounded text-blue-600 focus:ring-blue-500 cursor-pointer"
            />
            <div>
              <span className="font-bold text-slate-800 dark:text-slate-200 block text-[11px]">App Download Analytics</span>
              <span className="text-[10px] text-slate-500">Record APK & PWA metrics</span>
            </div>
          </label>
        </div>
      </div>

      {/* 3. Download Tracking & Analytics Dashboard (Section 21) */}
      <div className="bg-white dark:bg-slate-850 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
          <div>
            <h4 className="font-bold text-slate-900 dark:text-white text-xs uppercase tracking-wider flex items-center gap-2">
              <BarChart3 className="w-3.5 h-3.5 text-blue-500" />
              <span>Application Download Analytics</span>
            </h4>
            <p className="text-[11px] text-slate-400 mt-0.5">
              Privacy-friendly metrics tracking actual application downloads and installs across channels.
            </p>
          </div>
          <span className="text-[10px] text-slate-400">
            Last Updated: {pwa.analytics?.lastUpdated ? new Date(pwa.analytics.lastUpdated).toLocaleDateString() : 'Active'}
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="p-4 rounded-xl bg-blue-50 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-900/50">
            <span className="text-[11px] font-semibold text-blue-600 dark:text-blue-400 block">APK Downloads</span>
            <span className="text-2xl font-black text-blue-900 dark:text-blue-200 mt-1 block">
              {(pwa.analytics?.apkDownloads || 0).toLocaleString()}
            </span>
            <span className="text-[10px] text-blue-500/80">Direct Android APK downloads</span>
          </div>

          <div className="p-4 rounded-xl bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-900/50">
            <span className="text-[11px] font-semibold text-emerald-600 dark:text-emerald-400 block">PWA Installs</span>
            <span className="text-2xl font-black text-emerald-900 dark:text-emerald-200 mt-1 block">
              {(pwa.analytics?.pwaInstalls || 0).toLocaleString()}
            </span>
            <span className="text-[10px] text-emerald-500/80">Browser native PWA installations</span>
          </div>

          <div className="p-4 rounded-xl bg-purple-50 dark:bg-purple-950/30 border border-purple-200 dark:border-purple-900/50">
            <span className="text-[11px] font-semibold text-purple-600 dark:text-purple-400 block">Play Store Clicks</span>
            <span className="text-2xl font-black text-purple-900 dark:text-purple-200 mt-1 block">
              {(pwa.analytics?.playStoreClicks || 0).toLocaleString()}
            </span>
            <span className="text-[10px] text-purple-500/80">Google Play Store link referrals</span>
          </div>
        </div>
      </div>

      {/* 4. WhatsApp Floating Button Settings */}
      <div className="bg-white dark:bg-slate-850 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
          <div>
            <h4 className="font-bold text-slate-900 dark:text-white text-xs uppercase tracking-wider flex items-center gap-2">
              <MessageCircle className="w-3.5 h-3.5 text-emerald-500" />
              <span>Compact WhatsApp Floating Button Settings</span>
            </h4>
            <p className="text-[11px] text-slate-400 mt-0.5">
              Control the compact floating WhatsApp chat icon size and positioning.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">WHATSAPP BUTTON SIZE</label>
            <select
              value={pwa.whatsappButtonSize || 'compact'}
              onChange={e => setPwa({ ...pwa, whatsappButtonSize: e.target.value as 'compact' | 'standard' })}
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl outline-none font-bold"
            >
              <option value="compact">Compact (Recommended, 38px)</option>
              <option value="standard">Standard (44px)</option>
            </select>
          </div>

          <div>
            <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">WHATSAPP POSITION</label>
            <select
              value={pwa.whatsappPosition || 'bottom-right'}
              onChange={e => setPwa({ ...pwa, whatsappPosition: e.target.value as 'bottom-right' | 'bottom-left' })}
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl outline-none font-bold"
            >
              <option value="bottom-right">Bottom Right (Default)</option>
              <option value="bottom-left">Bottom Left</option>
            </select>
          </div>
        </div>
      </div>

      {/* 5. Google Play Store Section (Sections 11 & 12) */}
      <div className="bg-white dark:bg-slate-850 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
          <div>
            <h4 className="font-bold text-slate-900 dark:text-white text-xs uppercase tracking-wider flex items-center gap-2">
              <Play className="w-3.5 h-3.5 text-emerald-500 fill-emerald-500" />
              <span>Google Play Store Integration</span>
            </h4>
            <p className="text-[11px] text-slate-400 mt-0.5">
              Official Google Play Store link for Android customers.
            </p>
          </div>
          <span
            className={`text-[10px] font-extrabold px-2.5 py-0.5 rounded-full ${
              pwa.playStoreEnabled !== false
                ? isPlayStoreConfigured
                  ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400'
                  : 'bg-amber-500/10 text-amber-600 dark:text-amber-400'
                : 'bg-slate-100 text-slate-500'
            }`}
          >
            {pwa.playStoreEnabled !== false
              ? isPlayStoreConfigured
                ? 'PLAY STORE ON (CONFIGURED)'
                : 'PLAY STORE ON (NOT CONFIGURED)'
              : 'PLAY STORE OFF'}
          </span>
        </div>

        <div>
          <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
            GOOGLE PLAY STORE URL [ editable ]
          </label>
          <div className="flex gap-2">
            <input
              type="url"
              value={pwa.playStoreUrl || ''}
              onChange={e => setPwa({ ...pwa, playStoreUrl: e.target.value })}
              placeholder="https://play.google.com/store/apps/details?id=com.infostors.app"
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl outline-none font-mono text-xs text-slate-900 dark:text-white"
            />
            {isPlayStoreConfigured && (
              <button
                type="button"
                onClick={handleOpenPlayStore}
                className="px-3 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-xl font-bold flex items-center gap-1 shrink-0 cursor-pointer"
                title="Test link"
              >
                <ExternalLink className="w-3.5 h-3.5 text-emerald-500" />
                <span>Test</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </form>
  );
};
