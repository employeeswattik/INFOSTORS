import React, { useState } from 'react';
import { Save, Check, RotateCcw, Eye, Send, AlertCircle, Smartphone, ExternalLink, HelpCircle } from 'lucide-react';
import { StoreSettings } from '../../types';
import { WhatsAppIcon } from '../WhatsAppIcon';
import {
  OFFICIAL_DEFAULT_TEMPLATES,
  AVAILABLE_WHATSAPP_VARIABLES,
  generateSampleWhatsAppPreview,
} from '../../services/whatsappNotificationService';

interface AdminWhatsAppNotificationsTabProps {
  storeSettings: StoreSettings;
  updateStoreSettings: (settings: StoreSettings) => void;
}

export const AdminWhatsAppNotificationsTab: React.FC<AdminWhatsAppNotificationsTabProps> = ({
  storeSettings,
  updateStoreSettings,
}) => {
  const savedTemplates = storeSettings.whatsappNotificationSettings?.templates as any;

  // Three distinct templates for Received, Dispatched, Delivered
  const [receivedMsg, setReceivedMsg] = useState<string>(
    savedTemplates?.order_confirmed?.body || OFFICIAL_DEFAULT_TEMPLATES.received
  );
  const [dispatchedMsg, setDispatchedMsg] = useState<string>(
    savedTemplates?.order_dispatched?.body || OFFICIAL_DEFAULT_TEMPLATES.dispatched
  );
  const [deliveredMsg, setDeliveredMsg] = useState<string>(
    savedTemplates?.order_delivered?.body || OFFICIAL_DEFAULT_TEMPLATES.delivered
  );

  const [businessNumber, setBusinessNumber] = useState<string>(
    storeSettings.whatsappNotificationSettings?.businessNumber || storeSettings.helpline || '+91 94778 39200'
  );
  const [autoPrompt, setAutoPrompt] = useState<boolean>(
    storeSettings.whatsappNotificationSettings?.autoPromptOnStatusChange !== false
  );

  // Active preview toggle per box
  const [previewBox, setPreviewBox] = useState<'received' | 'dispatched' | 'delivered' | null>('received');
  const [saveStatus, setSaveStatus] = useState<string | null>(null);

  // Test Message Modal State
  const [testNumber, setTestNumber] = useState<string>('9477839200');
  const [testNotice, setTestNotice] = useState<string | null>(null);

  const isApiConfigured = Boolean(
    storeSettings.whatsAppApiSettings?.status === 'CONNECTED' &&
    storeSettings.whatsAppApiSettings?.phoneNumberId
  );

  const handleSaveAll = (e?: React.FormEvent) => {
    if (e) e.preventDefault();

    const current = storeSettings.whatsappNotificationSettings || {
      enabledTypes: {
        order_confirmed: true,
        order_processing: true,
        order_dispatched: true,
        out_for_delivery: true,
        order_delivered: true,
        order_cancelled: true,
        payment_received: true,
      },
      templates: {} as any,
    };

    const nextTemplates = {
      ...current.templates,
      order_confirmed: {
        title: 'Order Received',
        body: receivedMsg,
      },
      order_dispatched: {
        title: 'Order Dispatched',
        body: dispatchedMsg,
      },
      order_delivered: {
        title: 'Order Delivered',
        body: deliveredMsg,
      },
    };

    updateStoreSettings({
      ...storeSettings,
      whatsappNotificationSettings: {
        ...current,
        businessNumber,
        autoPromptOnStatusChange: autoPrompt,
        templates: nextTemplates,
      },
    });

    setSaveStatus('WhatsApp message templates successfully saved to store database.');
    setTimeout(() => setSaveStatus(null), 3500);
  };

  const handleSaveBox = (box: 'received' | 'dispatched' | 'delivered') => {
    handleSaveAll();
  };

  const handleRestoreDefault = (box: 'received' | 'dispatched' | 'delivered') => {
    if (box === 'received') setReceivedMsg(OFFICIAL_DEFAULT_TEMPLATES.received);
    if (box === 'dispatched') setDispatchedMsg(OFFICIAL_DEFAULT_TEMPLATES.dispatched);
    if (box === 'delivered') setDeliveredMsg(OFFICIAL_DEFAULT_TEMPLATES.delivered);
    setSaveStatus(`Restored default template for ${box.toUpperCase()} message. Click Save to persist.`);
    setTimeout(() => setSaveStatus(null), 3000);
  };

  const handleInsertVariable = (
    box: 'received' | 'dispatched' | 'delivered',
    variableKey: string
  ) => {
    if (box === 'received') setReceivedMsg(prev => `${prev} ${variableKey}`);
    if (box === 'dispatched') setDispatchedMsg(prev => `${prev} ${variableKey}`);
    if (box === 'delivered') setDeliveredMsg(prev => `${prev} ${variableKey}`);
  };

  const handleSendTestMessage = (box: 'received' | 'dispatched' | 'delivered') => {
    const cleanNumber = testNumber.replace(/\D/g, '');
    if (!cleanNumber || cleanNumber.length < 10) {
      setTestNotice('Please enter a valid 10-digit mobile number for test dispatch.');
      setTimeout(() => setTestNotice(null), 3500);
      return;
    }

    const templateToUse =
      box === 'received' ? receivedMsg : box === 'dispatched' ? dispatchedMsg : deliveredMsg;
    const renderedMsg = generateSampleWhatsAppPreview(templateToUse, box, storeSettings);

    if (!isApiConfigured) {
      // Prompt user clearly: Cloud API is unconfigured, so we dispatch test via Web WhatsApp
      setTestNotice('WHATSAPP API — REQUIRES CONFIGURATION (Meta Cloud credentials not saved). Opening Direct WhatsApp Web with rendered test message...');
      setTimeout(() => {
        setTestNotice(null);
        const fullPhone = cleanNumber.startsWith('91') ? cleanNumber : `91${cleanNumber}`;
        window.open(
          `https://wa.me/${fullPhone}?text=${encodeURIComponent(renderedMsg)}`,
          '_blank',
          'noopener,noreferrer'
        );
      }, 1500);
    } else {
      // In production with credentials:
      setTestNotice(`Test message for ${box.toUpperCase()} dispatched via WhatsApp Cloud API to +91 ${cleanNumber}`);
      setTimeout(() => setTestNotice(null), 4000);
    }
  };

  return (
    <div className="space-y-6 text-xs text-slate-800 dark:text-slate-100 max-w-5xl">
      {/* Tab Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-200 dark:border-slate-800">
        <div>
          <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <WhatsAppIcon className="w-4 h-4 fill-[#25D366]" />
            <span>WhatsApp Order Status Messages & Template Engine</span>
          </h3>
          <p className="text-[11px] text-slate-400">
            Customize rich, professional WhatsApp notifications sent to customers when orders are Received, Dispatched, or Delivered.
          </p>
        </div>

        <button
          type="button"
          onClick={() => handleSaveAll()}
          className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl flex items-center gap-1.5 shadow-xs cursor-pointer transition-colors"
          id="btn-save-all-whatsapp-templates"
        >
          <Save className="w-4 h-4" />
          <span>Save All Templates</span>
        </button>
      </div>

      {/* Status Feedback Notice */}
      {saveStatus && (
        <div className="p-3 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-300 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300 rounded-xl flex items-center gap-2 animate-in fade-in">
          <Check className="w-4 h-4 shrink-0" />
          <span className="font-semibold">{saveStatus}</span>
        </div>
      )}

      {/* Global Business Configuration Rail */}
      <div className="bg-white dark:bg-slate-850 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 items-center">
        <div>
          <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
            Official Business WhatsApp Number
          </label>
          <input
            type="text"
            value={businessNumber}
            onChange={e => setBusinessNumber(e.target.value)}
            placeholder="+91 94778 39200"
            className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl outline-none font-mono text-xs"
          />
        </div>

        <div>
          <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
            Automated Status Transitions
          </label>
          <label className="flex items-center gap-2 p-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 cursor-pointer">
            <input
              type="checkbox"
              checked={autoPrompt}
              onChange={e => setAutoPrompt(e.target.checked)}
              className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500 cursor-pointer"
            />
            <span className="font-semibold text-[11px] text-slate-700 dark:text-slate-300">
              Prompt 1-Click WhatsApp on order status changes
            </span>
          </label>
        </div>

        <div>
          <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
            Test Phone Number
          </label>
          <div className="flex gap-2">
            <input
              type="text"
              value={testNumber}
              onChange={e => setTestNumber(e.target.value)}
              placeholder="9477839200"
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl outline-none font-mono text-xs"
            />
          </div>
        </div>
      </div>

      {testNotice && (
        <div className="p-3 bg-amber-50 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-800 text-amber-800 dark:text-amber-300 rounded-xl flex items-center gap-2 text-xs">
          <AlertCircle className="w-4 h-4 shrink-0 text-amber-500" />
          <span>{testNotice}</span>
        </div>
      )}

      {/* Available Variables Selector Bar */}
      <div className="bg-slate-50 dark:bg-slate-800/60 p-3.5 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-2">
        <div className="flex items-center justify-between text-xs font-bold text-slate-700 dark:text-slate-300">
          <span className="flex items-center gap-1.5">
            <HelpCircle className="w-3.5 h-3.5 text-blue-500" />
            <span>AVAILABLE DYNAMIC VARIABLES (Click variable below to insert into active box)</span>
          </span>
        </div>
        <div className="flex flex-wrap gap-1.5">
          {AVAILABLE_WHATSAPP_VARIABLES.map(v => (
            <button
              key={v.key}
              type="button"
              onClick={() => {
                if (previewBox) handleInsertVariable(previewBox, v.key);
                else handleInsertVariable('received', v.key);
              }}
              className="px-2.5 py-1 bg-white dark:bg-slate-800 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 hover:border-emerald-400 border border-slate-200 dark:border-slate-700 rounded-lg text-[10px] font-bold text-slate-700 dark:text-slate-300 transition-colors cursor-pointer flex items-center gap-1 shadow-2xs"
              title={`${v.desc} -> ${v.key}`}
            >
              <span>{v.label}</span>
              <code className="text-emerald-600 dark:text-emerald-400 font-mono text-[9px]">{v.key}</code>
            </button>
          ))}
        </div>
      </div>

      {/* THREE LARGE EDITOR BOXES */}
      <div className="space-y-6">
        {/* BOX 1: 🟢 ORDER RECEIVED MESSAGE */}
        <div className="bg-white dark:bg-slate-850 p-5 rounded-2xl border-2 border-emerald-500/30 dark:border-emerald-500/20 shadow-xs space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-slate-100 dark:border-slate-800">
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 rounded-full bg-emerald-500 ring-4 ring-emerald-500/20" />
              <h4 className="font-extrabold text-sm text-slate-900 dark:text-white uppercase tracking-wider">
                BOX 1: 🟢 ORDER RECEIVED MESSAGE
              </h4>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setPreviewBox(previewBox === 'received' ? null : 'received')}
                className={`px-3 py-1.5 rounded-xl font-bold text-xs flex items-center gap-1.5 cursor-pointer transition-colors ${
                  previewBox === 'received'
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
                }`}
              >
                <Eye className="w-3.5 h-3.5" />
                <span>{previewBox === 'received' ? 'Hide Preview' : 'PREVIEW'}</span>
              </button>

              <button
                type="button"
                onClick={() => handleRestoreDefault('received')}
                className="px-3 py-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-400 font-bold rounded-xl flex items-center gap-1.5 cursor-pointer transition-colors"
                title="Restore default Order Received message"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>RESTORE DEFAULT</span>
              </button>

              <button
                type="button"
                onClick={() => handleSendTestMessage('received')}
                className="px-3 py-1.5 bg-emerald-100 dark:bg-emerald-950/60 hover:bg-emerald-200 text-emerald-800 dark:text-emerald-300 font-bold rounded-xl flex items-center gap-1.5 cursor-pointer transition-colors"
                title="Send test message to test phone"
              >
                <Send className="w-3.5 h-3.5" />
                <span>TEST</span>
              </button>

              <button
                type="button"
                onClick={() => handleSaveBox('received')}
                className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl flex items-center gap-1.5 shadow-xs cursor-pointer transition-colors"
              >
                <Save className="w-3.5 h-3.5" />
                <span>SAVE</span>
              </button>
            </div>
          </div>

          {/* Large Editable Textarea */}
          <textarea
            rows={7}
            value={receivedMsg}
            onChange={e => setReceivedMsg(e.target.value)}
            onFocus={() => setPreviewBox('received')}
            className="w-full p-3.5 bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-xl outline-none font-mono text-xs leading-relaxed text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-emerald-500"
            placeholder="Type your Order Received WhatsApp template with emojis & dynamic variables..."
          />

          {/* Live Preview for Box 1 */}
          {previewBox === 'received' && (
            <div className="bg-[#EFEAE2] dark:bg-slate-900 p-4 rounded-xl border border-slate-300 dark:border-slate-700 space-y-2 animate-in fade-in duration-200">
              <div className="flex items-center justify-between text-[11px] font-bold text-slate-700 dark:text-slate-300">
                <span className="flex items-center gap-1.5 text-emerald-800 dark:text-emerald-400">
                  <WhatsAppIcon className="w-3.5 h-3.5 fill-[#25D366]" />
                  <span>WhatsApp Live Message Preview (Sample Order Data: Rahul, INF-20260926-1001)</span>
                </span>
                <span className="text-[10px] text-slate-500">Double-tick delivered</span>
              </div>
              <div className="bg-white dark:bg-slate-850 p-4 rounded-2xl shadow-md border border-slate-200 dark:border-slate-800 max-w-lg text-[12px] leading-relaxed whitespace-pre-wrap font-sans text-slate-900 dark:text-slate-100">
                {generateSampleWhatsAppPreview(receivedMsg, 'received', storeSettings)}
              </div>
            </div>
          )}
        </div>

        {/* BOX 2: 🔵 ORDER DISPATCHED MESSAGE */}
        <div className="bg-white dark:bg-slate-850 p-5 rounded-2xl border-2 border-blue-500/30 dark:border-blue-500/20 shadow-xs space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-slate-100 dark:border-slate-800">
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 rounded-full bg-blue-500 ring-4 ring-blue-500/20" />
              <h4 className="font-extrabold text-sm text-slate-900 dark:text-white uppercase tracking-wider">
                BOX 2: 🔵 ORDER DISPATCHED MESSAGE
              </h4>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setPreviewBox(previewBox === 'dispatched' ? null : 'dispatched')}
                className={`px-3 py-1.5 rounded-xl font-bold text-xs flex items-center gap-1.5 cursor-pointer transition-colors ${
                  previewBox === 'dispatched'
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
                }`}
              >
                <Eye className="w-3.5 h-3.5" />
                <span>{previewBox === 'dispatched' ? 'Hide Preview' : 'PREVIEW'}</span>
              </button>

              <button
                type="button"
                onClick={() => handleRestoreDefault('dispatched')}
                className="px-3 py-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-400 font-bold rounded-xl flex items-center gap-1.5 cursor-pointer transition-colors"
                title="Restore default Order Dispatched message"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>RESTORE DEFAULT</span>
              </button>

              <button
                type="button"
                onClick={() => handleSendTestMessage('dispatched')}
                className="px-3 py-1.5 bg-blue-100 dark:bg-blue-950/60 hover:bg-blue-200 text-blue-800 dark:text-blue-300 font-bold rounded-xl flex items-center gap-1.5 cursor-pointer transition-colors"
                title="Send test message to test phone"
              >
                <Send className="w-3.5 h-3.5" />
                <span>TEST</span>
              </button>

              <button
                type="button"
                onClick={() => handleSaveBox('dispatched')}
                className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl flex items-center gap-1.5 shadow-xs cursor-pointer transition-colors"
              >
                <Save className="w-3.5 h-3.5" />
                <span>SAVE</span>
              </button>
            </div>
          </div>

          {/* Large Editable Textarea */}
          <textarea
            rows={7}
            value={dispatchedMsg}
            onChange={e => setDispatchedMsg(e.target.value)}
            onFocus={() => setPreviewBox('dispatched')}
            className="w-full p-3.5 bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-xl outline-none font-mono text-xs leading-relaxed text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-blue-500"
            placeholder="Type your Order Dispatched WhatsApp template with emojis & dynamic variables..."
          />

          {/* Live Preview for Box 2 */}
          {previewBox === 'dispatched' && (
            <div className="bg-[#EFEAE2] dark:bg-slate-900 p-4 rounded-xl border border-slate-300 dark:border-slate-700 space-y-2 animate-in fade-in duration-200">
              <div className="flex items-center justify-between text-[11px] font-bold text-slate-700 dark:text-slate-300">
                <span className="flex items-center gap-1.5 text-blue-800 dark:text-blue-400">
                  <WhatsAppIcon className="w-3.5 h-3.5 fill-[#25D366]" />
                  <span>WhatsApp Live Message Preview (Sample Order Data: Rahul, INF-20260926-1001)</span>
                </span>
                <span className="text-[10px] text-slate-500">Double-tick delivered</span>
              </div>
              <div className="bg-white dark:bg-slate-850 p-4 rounded-2xl shadow-md border border-slate-200 dark:border-slate-800 max-w-lg text-[12px] leading-relaxed whitespace-pre-wrap font-sans text-slate-900 dark:text-slate-100">
                {generateSampleWhatsAppPreview(dispatchedMsg, 'dispatched', storeSettings)}
              </div>
            </div>
          )}
        </div>

        {/* BOX 3: 🟢 ORDER DELIVERED MESSAGE */}
        <div className="bg-white dark:bg-slate-850 p-5 rounded-2xl border-2 border-purple-500/30 dark:border-purple-500/20 shadow-xs space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-slate-100 dark:border-slate-800">
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 rounded-full bg-purple-500 ring-4 ring-purple-500/20" />
              <h4 className="font-extrabold text-sm text-slate-900 dark:text-white uppercase tracking-wider">
                BOX 3: 🟢 ORDER DELIVERED MESSAGE
              </h4>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setPreviewBox(previewBox === 'delivered' ? null : 'delivered')}
                className={`px-3 py-1.5 rounded-xl font-bold text-xs flex items-center gap-1.5 cursor-pointer transition-colors ${
                  previewBox === 'delivered'
                    ? 'bg-purple-600 text-white shadow-xs'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
                }`}
              >
                <Eye className="w-3.5 h-3.5" />
                <span>{previewBox === 'delivered' ? 'Hide Preview' : 'PREVIEW'}</span>
              </button>

              <button
                type="button"
                onClick={() => handleRestoreDefault('delivered')}
                className="px-3 py-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-400 font-bold rounded-xl flex items-center gap-1.5 cursor-pointer transition-colors"
                title="Restore default Order Delivered message"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>RESTORE DEFAULT</span>
              </button>

              <button
                type="button"
                onClick={() => handleSendTestMessage('delivered')}
                className="px-3 py-1.5 bg-purple-100 dark:bg-purple-950/60 hover:bg-purple-200 text-purple-800 dark:text-purple-300 font-bold rounded-xl flex items-center gap-1.5 cursor-pointer transition-colors"
                title="Send test message to test phone"
              >
                <Send className="w-3.5 h-3.5" />
                <span>TEST</span>
              </button>

              <button
                type="button"
                onClick={() => handleSaveBox('delivered')}
                className="px-3.5 py-1.5 bg-purple-600 hover:bg-purple-500 text-white font-bold rounded-xl flex items-center gap-1.5 shadow-xs cursor-pointer transition-colors"
              >
                <Save className="w-3.5 h-3.5" />
                <span>SAVE</span>
              </button>
            </div>
          </div>

          {/* Large Editable Textarea */}
          <textarea
            rows={7}
            value={deliveredMsg}
            onChange={e => setDeliveredMsg(e.target.value)}
            onFocus={() => setPreviewBox('delivered')}
            className="w-full p-3.5 bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-xl outline-none font-mono text-xs leading-relaxed text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-purple-500"
            placeholder="Type your Order Delivered WhatsApp template with emojis & dynamic variables..."
          />

          {/* Live Preview for Box 3 */}
          {previewBox === 'delivered' && (
            <div className="bg-[#EFEAE2] dark:bg-slate-900 p-4 rounded-xl border border-slate-300 dark:border-slate-700 space-y-2 animate-in fade-in duration-200">
              <div className="flex items-center justify-between text-[11px] font-bold text-slate-700 dark:text-slate-300">
                <span className="flex items-center gap-1.5 text-purple-800 dark:text-purple-400">
                  <WhatsAppIcon className="w-3.5 h-3.5 fill-[#25D366]" />
                  <span>WhatsApp Live Message Preview (Sample Order Data: Rahul, INF-20260926-1001)</span>
                </span>
                <span className="text-[10px] text-slate-500">Double-tick delivered</span>
              </div>
              <div className="bg-white dark:bg-slate-850 p-4 rounded-2xl shadow-md border border-slate-200 dark:border-slate-800 max-w-lg text-[12px] leading-relaxed whitespace-pre-wrap font-sans text-slate-900 dark:text-slate-100">
                {generateSampleWhatsAppPreview(deliveredMsg, 'delivered', storeSettings)}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
