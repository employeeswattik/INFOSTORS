import React, { useState } from 'react';
import { Star, Check, X, Trash2, MessageSquare, AlertCircle, ShieldCheck } from 'lucide-react';
import { useShop } from '../../context/ShopContext';
import { Review } from '../../types';
import { safeConfirm } from '../../utils/safeBrowser';

export const AdminReviewsTab: React.FC = () => {
  const { reviews, moderateReview, deleteReview } = useShop();

  const [filter, setFilter] = useState<'all' | 'pending' | 'approved' | 'rejected'>('all');
  const [statusMessage, setStatusMessage] = useState<string | null>(null);

  const filteredReviews = reviews.filter(r => {
    if (filter === 'all') return true;
    return r.status === filter;
  });

  const handleModerate = async (id: string, status: 'approved' | 'rejected') => {
    const res = await moderateReview(id, status);
    if (res.success) {
      setStatusMessage(`Review ${status}.`);
      setTimeout(() => setStatusMessage(null), 3000);
    }
  };

  const handleDelete = async (id: string) => {
    if (!safeConfirm('Delete this review permanently?')) return;
    const res = await deleteReview(id);
    if (res.success) {
      setStatusMessage('Review deleted.');
      setTimeout(() => setStatusMessage(null), 3000);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-900 border border-slate-800 rounded-2xl p-5 text-white">
        <div>
          <div className="flex items-center gap-2">
            <Star className="w-5 h-5 text-amber-400 fill-amber-400" />
            <h2 className="text-lg font-black tracking-tight">Customer Reviews & Ratings Moderation</h2>
            <span className="text-[10px] bg-amber-500/20 text-amber-300 border border-amber-400/30 px-2 py-0.5 rounded-full font-bold">
              {reviews.length} Total
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Moderate genuine buyer reviews and rating submissions before or after they appear on product pages.
          </p>
        </div>

        {/* Filter Tabs */}
        <div className="flex items-center gap-1.5 bg-slate-950 p-1 rounded-xl border border-slate-800">
          {(['all', 'pending', 'approved', 'rejected'] as const).map(tab => (
            <button
              key={tab}
              type="button"
              onClick={() => setFilter(tab)}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold capitalize transition cursor-pointer ${
                filter === tab
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>
      </div>

      {statusMessage && (
        <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs rounded-xl flex items-center gap-2">
          <Check className="w-4 h-4" />
          <span>{statusMessage}</span>
        </div>
      )}

      {/* Reviews Table / List */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-950/80 text-[11px] uppercase font-bold text-slate-400 border-b border-slate-800">
              <tr>
                <th className="py-3 px-4">Product / Rating</th>
                <th className="py-3 px-4">Customer</th>
                <th className="py-3 px-4">Comment</th>
                <th className="py-3 px-4">Date</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Moderation</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80">
              {filteredReviews.length > 0 ? (
                filteredReviews.map(r => (
                  <tr key={r.id} className="hover:bg-slate-800/40 transition">
                    <td className="py-3 px-4">
                      <div className="space-y-1">
                        <div className="flex items-center gap-1">
                          {[1, 2, 3, 4, 5].map(star => (
                            <Star
                              key={star}
                              className={`w-3.5 h-3.5 ${
                                star <= r.rating
                                  ? 'text-amber-400 fill-amber-400'
                                  : 'text-slate-600'
                              }`}
                            />
                          ))}
                          <span className="font-bold text-white ml-1">({r.rating}/5)</span>
                        </div>
                        <span className="text-[10px] text-slate-400 font-mono">
                          ID: {r.productId}
                        </span>
                      </div>
                    </td>

                    <td className="py-3 px-4">
                      <div className="font-bold text-white flex items-center gap-1">
                        <span>{r.customerName}</span>
                        {r.verifiedPurchase && (
                          <span title="Verified Buyer">
                            <ShieldCheck className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                          </span>
                        )}
                      </div>
                    </td>

                    <td className="py-3 px-4 max-w-xs">
                      <p className="line-clamp-2 text-slate-300 italic">"{r.comment}"</p>
                    </td>

                    <td className="py-3 px-4 text-[11px] text-slate-400">
                      {new Date(r.createdAt).toLocaleDateString('en-IN', {
                        month: 'short',
                        day: 'numeric',
                        year: 'numeric',
                      })}
                    </td>

                    <td className="py-3 px-4">
                      <span
                        className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full uppercase ${
                          r.status === 'approved'
                            ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                            : r.status === 'rejected'
                            ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                            : 'bg-amber-500/20 text-amber-300 border border-amber-500/30 animate-pulse'
                        }`}
                      >
                        {r.status}
                      </span>
                    </td>

                    <td className="py-3 px-4 text-right space-x-2">
                      {r.status !== 'approved' && (
                        <button
                          type="button"
                          onClick={() => handleModerate(r.id, 'approved')}
                          className="px-2.5 py-1 bg-emerald-600/30 hover:bg-emerald-600/50 text-emerald-300 font-bold rounded-lg transition cursor-pointer text-[11px]"
                        >
                          Approve
                        </button>
                      )}
                      {r.status !== 'rejected' && (
                        <button
                          type="button"
                          onClick={() => handleModerate(r.id, 'rejected')}
                          className="px-2.5 py-1 bg-amber-600/30 hover:bg-amber-600/50 text-amber-300 font-bold rounded-lg transition cursor-pointer text-[11px]"
                        >
                          Reject
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={() => handleDelete(r.id)}
                        className="text-rose-400 hover:text-rose-300 font-semibold transition cursor-pointer ml-1"
                      >
                        Delete
                      </button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-slate-500">
                    No reviews found for filter "{filter}".
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
