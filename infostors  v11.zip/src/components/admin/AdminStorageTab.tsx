import React, { useState } from 'react';
import { HardDrive, Save, Check, RotateCcw, AlertTriangle, Upload, Image as ImageIcon, CheckCircle, ShieldCheck } from 'lucide-react';
import { StoreSettings, StorageSettings, DEFAULT_STORAGE_SETTINGS } from '../../types';

interface AdminStorageTabProps {
  storeSettings: StoreSettings;
  updateStoreSettings: (settings: StoreSettings) => void;
}

export const AdminStorageTab: React.FC<AdminStorageTabProps> = ({
  storeSettings,
  updateStoreSettings,
}) => {
  const [storage, setStorage] = useState<StorageSettings>(
    storeSettings.storageSettings || DEFAULT_STORAGE_SETTINGS
  );
  const [saved, setSaved] = useState(false);
  const [testUploadPreview, setTestUploadPreview] = useState<string | null>(null);
  const [testUploadNotice, setTestUploadNotice] = useState<string | null>(null);

  const handleSave = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    updateStoreSettings({
      ...storeSettings,
      storageSettings: storage,
    });
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  };

  const handleRestoreDefault = () => {
    setStorage(DEFAULT_STORAGE_SETTINGS);
    updateStoreSettings({
      ...storeSettings,
      storageSettings: DEFAULT_STORAGE_SETTINGS,
    });
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const handleFileTest = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > (storage.maxFileSizeMb || 5) * 1024 * 1024) {
      setTestUploadNotice(`File exceeds maximum size limit of ${storage.maxFileSizeMb}MB.`);
      setTimeout(() => setTestUploadNotice(null), 3500);
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      setTestUploadPreview(reader.result as string);
      setTestUploadNotice('Test image loaded and validated successfully!');
      setTimeout(() => setTestUploadNotice(null), 3500);
    };
    reader.readAsDataURL(file);
  };

  return (
    <form onSubmit={handleSave} className="space-y-6 text-xs text-slate-800 dark:text-slate-100 max-w-4xl">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-200 dark:border-slate-800">
        <div>
          <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <HardDrive className="w-4 h-4 text-blue-600" />
            <span>Storage & Asset Management</span>
          </h3>
          <p className="text-[11px] text-slate-400">
            Configure image storage providers (Supabase Storage, External URLs, Google Drive), upload limits, and asset rules.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleRestoreDefault}
            className="px-3 py-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-400 font-bold rounded-xl flex items-center gap-1.5 cursor-pointer transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Restore Default</span>
          </button>

          <button
            type="submit"
            className="px-4 py-1.5 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl flex items-center gap-1.5 shadow-xs cursor-pointer transition-colors"
          >
            {saved ? <Check className="w-4 h-4 text-white" /> : <Save className="w-4 h-4" />}
            <span>{saved ? 'Saved!' : 'Save Settings'}</span>
          </button>
        </div>
      </div>

      {/* 1. Storage Provider Configuration */}
      <div className="bg-white dark:bg-slate-850 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
          <div>
            <h4 className="font-bold text-xs uppercase tracking-wider text-slate-900 dark:text-white">
              Primary Asset Storage Provider
            </h4>
            <p className="text-[11px] text-slate-400 mt-0.5">
              Select where catalog product images and store media are hosted.
            </p>
          </div>
          <span className={`text-[10px] font-extrabold px-2.5 py-0.5 rounded-full ${
            storage.provider === 'google_drive' 
              ? 'bg-amber-500/10 text-amber-600 dark:text-amber-400' 
              : 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400'
          }`}>
            {storage.provider === 'google_drive' ? 'REQUIRES CONFIGURATION' : 'CONNECTED'}
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {[
            { id: 'supabase', label: 'Supabase Storage', desc: 'Secure cloud object storage buckets', status: 'CONNECTED' },
            { id: 'external_url', label: 'External Image URLs', desc: 'Direct CDN / Unsplash / image links', status: 'CONNECTED' },
            { id: 'google_drive', label: 'Google Drive Storage', desc: 'GCP Service Account / OAuth integration', status: 'REQUIRES CONFIGURATION' },
          ].map(prov => (
            <div
              key={prov.id}
              onClick={() => setStorage({ ...storage, provider: prov.id as any })}
              className={`p-3.5 rounded-xl border-2 transition-all cursor-pointer space-y-1.5 ${
                storage.provider === prov.id
                  ? 'border-blue-600 bg-blue-50/50 dark:bg-blue-950/40'
                  : 'border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 hover:border-slate-300'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="font-bold text-xs text-slate-900 dark:text-white">{prov.label}</span>
                <span className={`w-2 h-2 rounded-full ${storage.provider === prov.id ? 'bg-blue-600' : 'bg-slate-300 dark:bg-slate-600'}`} />
              </div>
              <p className="text-[10.5px] text-slate-500 dark:text-slate-400">{prov.desc}</p>
              <span className={`inline-block text-[9px] font-bold px-1.5 py-0.5 rounded-md ${
                prov.status === 'CONNECTED' ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300' : 'bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300'
              }`}>
                {prov.status}
              </span>
            </div>
          ))}
        </div>

        {/* Notice if Google Drive selected */}
        {storage.provider === 'google_drive' && (
          <div className="p-3 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 rounded-xl text-amber-800 dark:text-amber-300 text-xs space-y-1">
            <div className="flex items-center gap-1.5 font-bold">
              <AlertTriangle className="w-4 h-4 text-amber-600" />
              <span>Google Drive Integration — REQUIRES CONFIGURATION</span>
            </div>
            <p className="text-[11px]">
              To enable automatic Google Drive image sync, configure your Google Cloud OAuth Client ID or Service Account credentials in the Google Cloud Console. While unconfigured, INFOSTORS automatically uses Supabase Storage and External URLs.
            </p>
          </div>
        )}
      </div>

      {/* 2. Upload Rules and Size Limits */}
      <div className="bg-white dark:bg-slate-850 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-4">
        <h4 className="font-bold text-xs uppercase tracking-wider text-slate-900 dark:text-white pb-2 border-b border-slate-100 dark:border-slate-800">
          Upload Limits & Allowed File Types
        </h4>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
              Maximum File Size Limit (MB)
            </label>
            <input
              type="number"
              min={1}
              max={25}
              value={storage.maxFileSizeMb || 5}
              onChange={e => setStorage({ ...storage, maxFileSizeMb: Number(e.target.value) || 5 })}
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl outline-none font-bold"
            />
            <p className="text-[10px] text-slate-400 mt-1">Recommended: 5MB for fast loading across 4G/5G networks</p>
          </div>

          <div>
            <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
              Supabase Storage Bucket Name
            </label>
            <input
              type="text"
              value={storage.publicBucket || 'product-images'}
              onChange={e => setStorage({ ...storage, publicBucket: e.target.value })}
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl outline-none font-mono text-xs"
            />
            <p className="text-[10px] text-slate-400 mt-1">Bucket must be publicly readable for catalog display</p>
          </div>
        </div>

        {/* Test Image Upload Validator */}
        <div className="pt-2 border-t border-slate-100 dark:border-slate-800 space-y-2">
          <label className="block font-semibold text-slate-700 dark:text-slate-300">
            Image Upload Validator & Test File
          </label>
          <div className="flex items-center gap-3">
            <label className="px-3.5 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-xl font-bold flex items-center gap-2 cursor-pointer border border-slate-300 dark:border-slate-700">
              <Upload className="w-4 h-4 text-blue-600" />
              <span>Select Test Image</span>
              <input
                type="file"
                accept="image/png,image/jpeg,image/webp,image/svg+xml"
                onChange={handleFileTest}
                className="hidden"
              />
            </label>

            {testUploadPreview && (
              <div className="flex items-center gap-2">
                <img
                  src={testUploadPreview}
                  alt="Test preview"
                  className="w-10 h-10 rounded-lg object-contain border border-slate-200 dark:border-slate-700 bg-white"
                />
                <span className="text-[11px] text-emerald-600 dark:text-emerald-400 font-bold flex items-center gap-1">
                  <CheckCircle className="w-3.5 h-3.5" />
                  Image Valid
                </span>
              </div>
            )}
          </div>

          {testUploadNotice && (
            <p className="text-[11px] text-blue-600 dark:text-blue-400 font-medium">
              {testUploadNotice}
            </p>
          )}
        </div>
      </div>

      {/* 3. Product Image Source Rules (Free Plan Safety & Sourcing Controls) */}
      <div className="bg-white dark:bg-slate-850 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-4">
        <div className="pb-2 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <div>
            <h4 className="font-bold text-xs uppercase tracking-wider text-slate-900 dark:text-white">
              Product Image Source Rules
            </h4>
            <p className="text-[11px] text-slate-400 mt-0.5">
              Control which image sourcing methods are allowed in the Product Add / Edit editor.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <label className="flex items-center gap-2.5 p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 cursor-pointer">
            <input
              type="checkbox"
              checked={storage.allowUploadImage !== false}
              onChange={e => setStorage({ ...storage, allowUploadImage: e.target.checked })}
              className="w-4 h-4 rounded text-blue-600 focus:ring-blue-500 cursor-pointer"
            />
            <div>
              <span className="font-bold text-slate-800 dark:text-slate-200 block text-[11px]">
                Allow Upload Image [ ON / OFF ]
              </span>
              <span className="text-[10px] text-slate-500">
                Upload to Supabase Storage (product-images bucket)
              </span>
            </div>
          </label>

          <label className="flex items-center gap-2.5 p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 cursor-pointer">
            <input
              type="checkbox"
              checked={storage.allowExternalUrl !== false}
              onChange={e => setStorage({ ...storage, allowExternalUrl: e.target.checked })}
              className="w-4 h-4 rounded text-blue-600 focus:ring-blue-500 cursor-pointer"
            />
            <div>
              <span className="font-bold text-slate-800 dark:text-slate-200 block text-[11px]">
                Allow External Image URL [ ON / OFF ]
              </span>
              <span className="text-[10px] text-slate-500">
                Direct image URLs (0 Supabase Storage used)
              </span>
            </div>
          </label>

          <label className="flex items-center gap-2.5 p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 cursor-pointer">
            <input
              type="checkbox"
              checked={Boolean(storage.requireProductImage)}
              onChange={e => setStorage({ ...storage, requireProductImage: e.target.checked })}
              className="w-4 h-4 rounded text-blue-600 focus:ring-blue-500 cursor-pointer"
            />
            <div>
              <span className="font-bold text-slate-800 dark:text-slate-200 block text-[11px]">
                Require Product Image [ ON / OFF ]
              </span>
              <span className="text-[10px] text-slate-500">
                Enforce mandatory image before saving
              </span>
            </div>
          </label>
        </div>
      </div>
    </form>
  );
};
