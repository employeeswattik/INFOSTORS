import React, { useState, useEffect } from 'react';
import {
  Users,
  Shield,
  Plus,
  Trash2,
  CheckCircle2,
  Lock,
  UserPlus,
  Power,
  X,
  Key,
  Mail,
  Phone,
  User,
  AlertCircle,
  Loader2,
  RefreshCw,
} from 'lucide-react';
import { AdminUser, AdminRole, AdminStatus } from '../../types';
import { useShop } from '../../context/ShopContext';
import { safeConfirm } from '../../utils/safeBrowser';

export const AdminManagementTab: React.FC = () => {
  const { adminProfile, fetchAdminList, createAdmin, modifyAdmin, removeAdmin } = useShop();

  const [admins, setAdmins] = useState<AdminUser[]>([]);
  const [loading, setLoading] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [statusMessage, setStatusMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Add Admin Form State
  const [isCreating, setIsCreating] = useState(false);
  const [newName, setNewName] = useState('');
  const [newEmail, setNewEmail] = useState('');
  const [newMobile, setNewMobile] = useState('');
  const [newRole, setNewRole] = useState<AdminRole>('admin');
  const [newStatus, setNewStatus] = useState<AdminStatus>('active');
  const [newPassword, setNewPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  // Check if current user is authorized Main Admin
  const isAuthorizedMainAdmin =
    adminProfile?.role === 'main_admin' ||
    adminProfile?.email?.toLowerCase() === 'infostors24@gmail.com' ||
    localStorage.getItem('infostors_admin_email')?.toLowerCase() === 'infostors24@gmail.com' ||
    !adminProfile; // Default to allow in dev if not populated

  const loadAdmins = async () => {
    setLoading(true);
    try {
      const list = await fetchAdminList();
      if (Array.isArray(list)) {
        setAdmins(list);
      }
    } catch {
      // Graceful fallback
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadAdmins();
  }, []);

  const showToast = (type: 'success' | 'error', text: string) => {
    setStatusMessage({ type, text });
    setTimeout(() => {
      setStatusMessage(prev => (prev?.text === text ? null : prev));
    }, 4000);
  };

  const handleCreateAdmin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim()) {
      showToast('error', 'Administrator full name is required.');
      return;
    }
    if (!newEmail.trim() || !newEmail.includes('@')) {
      showToast('error', 'A valid administrator email address is required.');
      return;
    }
    const cleanMobile = newMobile.replace(/\D/g, '').slice(-10);
    if (cleanMobile.length !== 10) {
      showToast('error', 'Please enter a valid 10-digit Indian mobile number.');
      return;
    }
    if (newPassword && newPassword.length < 6) {
      showToast('error', 'Password must be at least 6 characters long.');
      return;
    }

    setIsSubmitting(true);
    try {
      const res = await createAdmin({
        fullName: newName.trim(),
        email: newEmail.trim().toLowerCase(),
        mobile: cleanMobile,
        role: newRole,
        status: newStatus,
        password: newPassword.trim() || 'Admin@12345',
      });

      if (res.success && res.admin) {
        showToast('success', res.message || `Administrator ${res.admin.email} created successfully.`);
        // Reset form
        setNewName('');
        setNewEmail('');
        setNewMobile('');
        setNewPassword('');
        setNewRole('admin');
        setNewStatus('active');
        setIsCreating(false);
        // Refresh list
        await loadAdmins();
      } else {
        showToast('error', res.error || 'Failed to create administrator.');
      }
    } catch (err: any) {
      showToast('error', err.message || 'Error occurred while creating administrator.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleToggleStatus = async (admin: AdminUser) => {
    if (admin.email.toLowerCase() === 'infostors24@gmail.com' || admin.role === 'main_admin') {
      showToast('error', 'Primary Main Administrator account is protected and cannot be deactivated.');
      return;
    }

    const nextStatus: AdminStatus = admin.status === 'active' ? 'disabled' : 'active';
    const actionLabel = nextStatus === 'active' ? 'activate' : 'deactivate';

    if (!safeConfirm(`Are you sure you want to ${actionLabel} ${admin.fullName} (${admin.email})?`)) {
      return;
    }

    try {
      const res = await modifyAdmin(admin.id, { status: nextStatus });
      if (res.success) {
        showToast('success', `Administrator ${actionLabel}d successfully.`);
        setAdmins(prev => prev.map(a => (a.id === admin.id ? { ...a, status: nextStatus } : a)));
      } else {
        showToast('error', res.error || `Failed to ${actionLabel} administrator.`);
      }
    } catch (err: any) {
      showToast('error', err.message || `Error occurred while updating administrator status.`);
    }
  };

  const handleDeleteAdmin = async (admin: AdminUser) => {
    if (admin.email.toLowerCase() === 'infostors24@gmail.com' || admin.role === 'main_admin') {
      showToast('error', 'Primary Main Administrator account is protected and cannot be removed.');
      return;
    }

    if (!safeConfirm(`Are you sure you want to permanently remove administrator "${admin.fullName}" (${admin.email})? This action cannot be undone.`)) {
      return;
    }

    try {
      const res = await removeAdmin(admin.id);
      if (res.success) {
        showToast('success', `Administrator ${admin.email} removed successfully.`);
        setAdmins(prev => prev.filter(a => a.id !== admin.id));
      } else {
        showToast('error', res.error || 'Failed to remove administrator.');
      }
    } catch (err: any) {
      showToast('error', err.message || 'Error removing administrator.');
    }
  };

  const primaryMainAdmin = admins.find(a => a.email.toLowerCase() === 'infostors24@gmail.com') || {
    id: 'adm_primary_main',
    fullName: 'INFOSTORS Main Administrator',
    email: 'infostors24@gmail.com',
    mobile: '8695222581',
    role: 'main_admin' as AdminRole,
    status: 'active' as AdminStatus,
    createdAt: new Date().toISOString(),
  };

  const additionalAdmins = admins.filter(a => a.email.toLowerCase() !== 'infostors24@gmail.com');

  return (
    <div className="space-y-6 text-xs text-slate-800 dark:text-slate-100 max-w-4xl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-200 dark:border-slate-800">
        <div>
          <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Users className="w-4 h-4 text-blue-600" />
            <span>Administrator Access & Role Management</span>
          </h3>
          <p className="text-[11px] text-slate-400">
            Manage store managers, assign roles & permissions, and protect security credentials
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={loadAdmins}
            disabled={loading}
            className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-50 transition-colors cursor-pointer"
            title="Refresh Administrators"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          </button>

          {isAuthorizedMainAdmin && (
            <button
              type="button"
              onClick={() => setIsCreating(!isCreating)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs shadow-xs transition-colors cursor-pointer"
            >
              {isCreating ? (
                <>
                  <X className="w-3.5 h-3.5" />
                  <span>Cancel</span>
                </>
              ) : (
                <>
                  <UserPlus className="w-3.5 h-3.5" />
                  <span>Add Admin</span>
                </>
              )}
            </button>
          )}
        </div>
      </div>

      {/* Feedback Toast */}
      {statusMessage && (
        <div
          className={`p-3 rounded-xl flex items-center gap-2 text-xs font-medium border ${
            statusMessage.type === 'success'
              ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800'
              : 'bg-rose-50 dark:bg-rose-950/40 text-rose-800 dark:text-rose-300 border-rose-200 dark:border-rose-800'
          }`}
        >
          {statusMessage.type === 'success' ? (
            <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600 dark:text-emerald-400" />
          ) : (
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-600 dark:text-rose-400" />
          )}
          <span>{statusMessage.text}</span>
        </div>
      )}

      {/* Add Admin Form */}
      {isCreating && (
        <div className="bg-white dark:bg-slate-850 rounded-2xl border border-blue-200 dark:border-blue-900/60 p-4 shadow-sm space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
            <h4 className="font-bold text-xs text-slate-900 dark:text-white flex items-center gap-1.5">
              <UserPlus className="w-4 h-4 text-blue-600" />
              <span>Create New Administrator</span>
            </h4>
            <span className="text-[10px] text-slate-400">Connected to Supabase admin_users</span>
          </div>

          <form onSubmit={handleCreateAdmin} className="space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {/* Full Name */}
              <div className="space-y-1">
                <label className="text-[11px] font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1">
                  <User className="w-3 h-3 text-slate-400" />
                  <span>Full Name *</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Rahul Sharma"
                  value={newName}
                  onChange={e => setNewName(e.target.value)}
                  className="w-full px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none"
                />
              </div>

              {/* Email */}
              <div className="space-y-1">
                <label className="text-[11px] font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1">
                  <Mail className="w-3 h-3 text-slate-400" />
                  <span>Email Address *</span>
                </label>
                <input
                  type="email"
                  required
                  placeholder="e.g. rahul@infostors.com"
                  value={newEmail}
                  onChange={e => setNewEmail(e.target.value)}
                  className="w-full px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none"
                />
              </div>

              {/* Mobile */}
              <div className="space-y-1">
                <label className="text-[11px] font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1">
                  <Phone className="w-3 h-3 text-slate-400" />
                  <span>10-Digit Mobile *</span>
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 text-xs font-mono">+91</span>
                  <input
                    type="tel"
                    required
                    maxLength={10}
                    placeholder="8695222581"
                    value={newMobile}
                    onChange={e => setNewMobile(e.target.value.replace(/\D/g, ''))}
                    className="w-full pl-11 pr-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white text-xs font-mono focus:ring-2 focus:ring-blue-500 focus:outline-none"
                  />
                </div>
              </div>

              {/* Password */}
              <div className="space-y-1">
                <label className="text-[11px] font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1">
                  <Key className="w-3 h-3 text-slate-400" />
                  <span>Initial Password *</span>
                </label>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    placeholder="Min 6 characters (Default: Admin@12345)"
                    value={newPassword}
                    onChange={e => setNewPassword(e.target.value)}
                    className="w-full px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-2 top-1/2 -translate-y-1/2 text-[10px] text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
                  >
                    {showPassword ? 'Hide' : 'Show'}
                  </button>
                </div>
              </div>

              {/* Role */}
              <div className="space-y-1">
                <label className="text-[11px] font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1">
                  <Shield className="w-3 h-3 text-slate-400" />
                  <span>Assigned Role *</span>
                </label>
                <select
                  value={newRole}
                  onChange={e => setNewRole(e.target.value as AdminRole)}
                  className="w-full px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none cursor-pointer"
                >
                  <option value="admin">Admin (Store Operations & Orders)</option>
                  <option value="support">Support (Customer Service & Read-Only)</option>
                  <option value="main_admin">Main Admin (Full Unrestricted Access)</option>
                </select>
              </div>

              {/* Status */}
              <div className="space-y-1">
                <label className="text-[11px] font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1">
                  <Power className="w-3 h-3 text-slate-400" />
                  <span>Initial Status *</span>
                </label>
                <select
                  value={newStatus}
                  onChange={e => setNewStatus(e.target.value as AdminStatus)}
                  className="w-full px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none cursor-pointer"
                >
                  <option value="active">ACTIVE (Immediate Access)</option>
                  <option value="disabled">INACTIVE (Access Suspended)</option>
                </select>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
              <button
                type="button"
                onClick={() => setIsCreating(false)}
                className="px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-semibold cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isSubmitting}
                className="flex items-center gap-1.5 px-4 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs shadow-xs transition-colors cursor-pointer disabled:opacity-50"
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    <span>Saving...</span>
                  </>
                ) : (
                  <>
                    <Plus className="w-3.5 h-3.5" />
                    <span>Create Administrator</span>
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Administrators List Card */}
      <div className="bg-white dark:bg-slate-850 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-xs">
        <div className="p-4 bg-slate-50 dark:bg-slate-800/80 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between font-bold text-slate-700 dark:text-slate-200">
          <span>Active Administrators ({1 + additionalAdmins.length})</span>
          {loading && <Loader2 className="w-4 h-4 animate-spin text-slate-400" />}
        </div>

        <div className="divide-y divide-slate-100 dark:divide-slate-800">
          {/* Main Administrator Row (Strictly Protected) */}
          <div className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-full bg-blue-100 text-blue-700 font-bold flex items-center justify-center text-xs shrink-0">
                M
              </div>
              <div>
                <p className="font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <span>{primaryMainAdmin.fullName}</span>
                </p>
                <p className="text-[11px] text-slate-400">
                  {primaryMainAdmin.email} • +91 {primaryMainAdmin.mobile || '8695222581'}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <span className="px-2.5 py-1 rounded-full bg-blue-100 text-blue-800 dark:bg-blue-900/60 dark:text-blue-300 font-bold text-[10px] uppercase">
                Main Admin
              </span>
              <span className="px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-800 dark:bg-emerald-900/60 dark:text-emerald-300 font-bold text-[10px] uppercase">
                Active
              </span>
              <span className="text-[10px] font-semibold text-emerald-600 flex items-center gap-1 pl-1">
                <Shield className="w-3.5 h-3.5" />
                <span>Protected</span>
              </span>
            </div>
          </div>

          {/* Additional Administrators */}
          {additionalAdmins.map(admin => {
            const isActive = admin.status === 'active';
            const isSupport = admin.role === 'support';
            const isMain = admin.role === 'main_admin';

            return (
              <div
                key={admin.id}
                className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`w-9 h-9 rounded-full font-bold flex items-center justify-center text-xs shrink-0 ${
                      isActive
                        ? 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
                        : 'bg-amber-100 dark:bg-amber-950/60 text-amber-700 dark:text-amber-400'
                    }`}
                  >
                    {admin.fullName?.charAt(0)?.toUpperCase() || 'A'}
                  </div>
                  <div>
                    <p className="font-bold text-slate-900 dark:text-white">{admin.fullName}</p>
                    <p className="text-[11px] text-slate-400">
                      {admin.email} • +91 {admin.mobile}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0 flex-wrap">
                  {/* Role Badge */}
                  <span
                    className={`px-2.5 py-1 rounded-full font-bold text-[10px] uppercase ${
                      isMain
                        ? 'bg-purple-100 text-purple-800 dark:bg-purple-900/60 dark:text-purple-300'
                        : isSupport
                        ? 'bg-amber-100 text-amber-800 dark:bg-amber-900/60 dark:text-amber-300'
                        : 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300'
                    }`}
                  >
                    {admin.role === 'main_admin' ? 'Main Admin' : admin.role}
                  </span>

                  {/* Status Badge */}
                  <span
                    className={`px-2.5 py-1 rounded-full font-bold text-[10px] uppercase ${
                      isActive
                        ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/60 dark:text-emerald-300'
                        : 'bg-rose-100 text-rose-800 dark:bg-rose-900/60 dark:text-rose-300'
                    }`}
                  >
                    {isActive ? 'Active' : 'Inactive'}
                  </span>

                  {/* Actions for Main Admin */}
                  {isAuthorizedMainAdmin && (
                    <div className="flex items-center gap-1.5 pl-2 border-l border-slate-200 dark:border-slate-700">
                      {/* Status Toggle Button */}
                      <button
                        type="button"
                        onClick={() => handleToggleStatus(admin)}
                        title={isActive ? 'Deactivate Administrator' : 'Activate Administrator'}
                        className={`px-2 py-1 rounded-lg text-[10px] font-bold transition-colors cursor-pointer border ${
                          isActive
                            ? 'border-amber-200 text-amber-700 bg-amber-50 hover:bg-amber-100 dark:border-amber-800 dark:bg-amber-950/40 dark:text-amber-300'
                            : 'border-emerald-200 text-emerald-700 bg-emerald-50 hover:bg-emerald-100 dark:border-emerald-800 dark:bg-emerald-950/40 dark:text-emerald-300'
                        }`}
                      >
                        {isActive ? 'Deactivate' : 'Activate'}
                      </button>

                      {/* Remove Button */}
                      <button
                        type="button"
                        onClick={() => handleDeleteAdmin(admin)}
                        title="Remove Administrator"
                        className="p-1.5 rounded-lg border border-rose-200 dark:border-rose-900/60 bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 hover:bg-rose-100 dark:hover:bg-rose-900/60 transition-colors cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
