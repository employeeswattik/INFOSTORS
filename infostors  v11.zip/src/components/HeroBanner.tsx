import React from 'react';
import { ArrowRight, Sparkles, ShieldCheck, Truck, Headphones, Zap } from 'lucide-react';
import { useShop } from '../context/ShopContext';

export const HeroBanner: React.FC = () => {
  const { setSelectedCategory, storeSettings } = useShop();

  return (
    <div className="relative w-full bg-gradient-to-br from-slate-900 via-slate-850 to-blue-950 text-white overflow-hidden py-10 sm:py-16 px-4 sm:px-6 lg:px-8 border-b border-slate-800">
      {/* Background glow effects */}
      <div className="absolute top-0 right-1/4 w-96 h-96 bg-blue-600/20 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-1/4 w-96 h-96 bg-indigo-600/20 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto relative z-10 flex flex-col md:flex-row items-center justify-between gap-8 sm:gap-12">
        <div className="flex-1 text-center md:text-left space-y-4 sm:space-y-6">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/10 border border-blue-400/30 text-blue-300 text-xs sm:text-sm font-semibold">
            <Sparkles className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-blue-400" />
            <span>Next-Gen Smart Living & Gadgets</span>
          </div>

          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-white leading-tight">
            Elevate Your Everyday <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-sky-300 to-indigo-300">
              With Smart Technology
            </span>
          </h1>

          <p className="text-slate-300 text-sm sm:text-base max-w-xl mx-auto md:mx-0">
            {storeSettings.tagline || 'Smart Gadgets | Better Life'} — Discover curated wireless audio, high-speed GaN chargers, ambient RGB lights, and smart home essentials with fast nationwide delivery.
          </p>

          <div className="flex flex-wrap items-center justify-center md:justify-start gap-3 sm:gap-4 pt-2">
            <button
              onClick={() => {
                setSelectedCategory('all');
                const el = document.getElementById('products-grid');
                if (el) el.scrollIntoView({ behavior: 'smooth' });
              }}
              className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-sm shadow-lg shadow-blue-600/30 transition-all hover:scale-105 cursor-pointer"
            >
              <span>Explore Products</span>
              <ArrowRight className="w-4 h-4" />
            </button>
            <button
              onClick={() => {
                setSelectedCategory('audio-sound');
                const el = document.getElementById('products-grid');
                if (el) el.scrollIntoView({ behavior: 'smooth' });
              }}
              className="inline-flex items-center gap-2 px-5 py-3 rounded-xl bg-slate-800/80 hover:bg-slate-800 text-slate-200 border border-slate-700 font-semibold text-sm transition-all cursor-pointer"
            >
              <span>Wireless Audio</span>
            </button>
          </div>
        </div>

        {/* Feature Badges Grid */}
        <div className="grid grid-cols-2 gap-3 sm:gap-4 w-full md:w-auto">
          <div className="bg-slate-800/60 backdrop-blur-xs border border-slate-700/60 rounded-2xl p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-500/20 text-blue-400 flex items-center justify-center shrink-0">
              <Truck className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs font-bold text-white">Free Delivery</p>
              <p className="text-[11px] text-slate-400">On orders above ₹499</p>
            </div>
          </div>

          <div className="bg-slate-800/60 backdrop-blur-xs border border-slate-700/60 rounded-2xl p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs font-bold text-white">{storeSettings.returnWindow || '7 Days Replacement'}</p>
              <p className="text-[11px] text-slate-400">Guaranteed quality</p>
            </div>
          </div>

          <div className="bg-slate-800/60 backdrop-blur-xs border border-slate-700/60 rounded-2xl p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0">
              <Zap className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs font-bold text-white">Verified Authentic</p>
              <p className="text-[11px] text-slate-400">100% Brand original</p>
            </div>
          </div>

          <div className="bg-slate-800/60 backdrop-blur-xs border border-slate-700/60 rounded-2xl p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center shrink-0">
              <Headphones className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs font-bold text-white">WhatsApp Helpline</p>
              <p className="text-[11px] text-slate-400">+91 94778 39200</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
