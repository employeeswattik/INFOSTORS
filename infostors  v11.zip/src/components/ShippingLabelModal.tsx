import React, { useState, useEffect, useMemo, useRef } from 'react';
import { X, Printer, Download, Sliders, Check, RotateCcw, ChevronLeft, ChevronRight, Save } from 'lucide-react';
import { Order, StoreSettings, ShippingLabelSettings } from '../types';
import { useShop } from '../context/ShopContext';
import bwipjs from 'bwip-js';
import QRCode from 'qrcode';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas-pro';

interface ShippingLabelModalProps {
  isOpen: boolean;
  onClose: () => void;
  order: Order | null;
  orders?: Order[]; // Multi-order selection for bulk label operations
  storeSettings: StoreSettings;
  onOrderUpdated?: (orderId: string, updates: { courierPartner?: string; trackingId?: string }) => void;
}

/**
 * Reusable Shipping Label Template.
 * Guarantees that Preview, PDF Download, and Direct Thermal Print use
 * the EXACT SAME rendering, field visibility, auto-reflow layout, and data source.
 */
interface LabelContentProps {
  order: Order;
  config: ShippingLabelSettings;
  storeSettings: StoreSettings;
  barcodeSvg?: string;
  qrSvg?: string;
  isPrintMode?: boolean;
}

const ShippingLabelContent: React.FC<LabelContentProps> = ({
  order,
  config,
  storeSettings,
  barcodeSvg,
  qrSvg,
}) => {
  // 1. Authoritative dynamic store branding sync
  const activeStoreLogo = storeSettings.logoUrl || storeSettings.shippingLabelSettings?.branding?.logoUrl || '';
  const activeStoreName = storeSettings.storeName || 'INFOSTORS';
  const activeStoreTagline = storeSettings.tagline || storeSettings.businessLegalName || 'Express Logistics Hub';

  // 2. Compute Tracking / AWB
  const getOrderAwb = (ord: Order) => {
    if (ord.trackingId && ord.trackingId.trim().length > 0) {
      return ord.trackingId.trim();
    }
    const cleanNum = (ord.orderId || '').replace(/\D/g, '');
    return `INF${cleanNum || '700084'}`;
  };

  const currentAwb = getOrderAwb(order);
  const isCod = order.paymentMethod === 'cod';
  const collectableAmount = isCod ? (order.totalAmount || 0) : 0;
  const customerPin = order.customer?.pincode || '700084';
  const courierName = order.courierPartner || 'Delhivery Express';

  const pickupLoc = config.pickupLocation;
  const returnCompany = pickupLoc?.companyName || storeSettings.businessLegalName || storeSettings.storeName || 'INFOSTORS';
  const returnAddress = `${pickupLoc?.address || 'INFOSTORS Return Hub'}, ${pickupLoc?.city || 'Kolkata'} ${pickupLoc?.pincode || '700084'}`;
  const returnPhone = pickupLoc?.contactNumber || storeSettings.helpline || '+91 94778 39200';

  // Dynamic field & section presence checks (Strict Zero Empty Space Rule)
  // Section 1: Header
  const hasLogo = Boolean(config.showLogo !== false && activeStoreLogo);
  const hasStoreName = Boolean(config.showStoreName !== false);
  const hasBranding = hasLogo || hasStoreName;
  const hasOrderId = Boolean(config.showOrderId !== false && order.orderId);
  const hasDate = Boolean(config.showDate !== false && order.date);
  const hasPaymentTag = Boolean(config.showPaymentMethod !== false);
  const hasHeaderRight = hasOrderId || hasDate || hasPaymentTag;
  const showHeader = Boolean(config.showHeader !== false && (hasBranding || hasHeaderRight));

  // Section 2: Courier & Destination PIN
  const hasCourier = Boolean(config.showCourier !== false && courierName);
  const hasTracking = Boolean(config.showTrackingNumber !== false && currentAwb);
  const hasPin = Boolean((config.showPincode !== false || config.showDeliveryDetails !== false) && customerPin);
  const showCourierSection = Boolean(config.showCourierDetails !== false && (hasCourier || hasTracking || hasPin));

  // Section 3: Code Area (1D Barcode & 2D QR Code)
  const hasBarcode = Boolean(config.showBarcode !== false && barcodeSvg);
  const hasQr = Boolean(config.showQrCode !== false && qrSvg);
  const showCodeArea = Boolean(config.showCodeArea !== false && (hasBarcode || hasQr));

  // Section 4: Deliver To (Recipient)
  const hasCustomerName = Boolean(config.showCustomerDetails !== false && order.customer?.fullName);
  const hasAddress = Boolean(config.showAddress !== false && order.customer?.address);
  const hasCityState = Boolean((config.showCity !== false || config.showState !== false) && (order.customer?.city || order.customer?.state));
  const hasPhone = Boolean(config.showCustomerPhone !== false && order.customer?.phone);
  const hasCustomerPin = Boolean(config.showPincode !== false && customerPin);
  const hasEmail = Boolean(config.showCustomerEmail && order.customer?.email);
  const hasInstructions = Boolean((config.showSpecialInstructions || config.showCustomerNote) && (order as any).notes);
  const showCustomerSection = Boolean(
    (config.showCustomerDetails !== false || config.showDeliveryDetails !== false) &&
    (hasCustomerName || hasAddress || hasCityState || hasPhone || hasCustomerPin || hasEmail || hasInstructions)
  );

  // Section 5: Payment Details
  const hasPaymentMode = Boolean(config.showPaymentMethod !== false);
  const hasCodAmt = Boolean(config.showCodAmount !== false);
  const showPaymentSection = Boolean(config.showPaymentDetails !== false && (hasPaymentMode || hasCodAmt));

  // Section 6: Order Details & Product Summary
  const hasItems = Boolean(order.items && order.items.length > 0);
  const showProductSection = Boolean(config.showOrderDetails !== false && config.showProductSummary !== false && hasItems);

  // Section 7: Pickup & Return Hub Details
  const hasReturnCompany = Boolean(returnCompany);
  const hasReturnAddress = Boolean(returnAddress);
  const showPickupSection = Boolean(config.showPickupDetails !== false && config.showPickupLocation !== false && (hasReturnCompany || hasReturnAddress));

  // Section 8: Footer
  const showFooterSection = Boolean(config.showFooter !== false);

  return (
    <div
      style={{
        width: '100mm',
        minHeight: 'auto',
        maxHeight: '150mm',
        boxSizing: 'border-box',
      }}
      className="bg-white text-black border-2 border-black p-3 flex flex-col gap-1.5 text-[10px] leading-tight font-sans select-text overflow-hidden shrink-0"
    >
      {/* 1. HEADER SECTION (Logo, Store Name, Order ID, Date, Mode) */}
      {showHeader && (
        <div className="border-b-2 border-black pb-1 flex justify-between items-start gap-2">
          {hasBranding ? (
            <div className="flex-1 min-w-0">
              {hasLogo ? (
                <img
                  src={activeStoreLogo}
                  alt={activeStoreName}
                  className="h-6 max-w-[130px] object-contain mb-0.5 filter grayscale contrast-200"
                />
              ) : (
                <h2 className="font-black text-sm tracking-tight leading-none uppercase">
                  {activeStoreName}
                </h2>
              )}
              <p className="text-[7.5px] uppercase font-extrabold text-black tracking-wider mt-0.5 truncate">
                {activeStoreTagline}
              </p>
            </div>
          ) : (
            <div />
          )}

          {hasHeaderRight && (
            <div className="text-right shrink-0">
              {hasOrderId && (
                <p className="font-mono font-black text-[13px] text-black tracking-tight leading-none">
                  #{order.orderId}
                </p>
              )}
              {hasDate && (
                <p className="text-[7.5px] font-bold text-black mt-0.5">
                  {new Date(order.date).toLocaleDateString('en-IN', {
                    day: '2-digit',
                    month: 'short',
                    year: 'numeric',
                  })}
                </p>
              )}
              {hasPaymentTag && (
                <span className="inline-block px-1.5 py-0.5 mt-0.5 bg-black text-white font-mono font-black text-[7.5px] uppercase rounded-xs">
                  {isCod ? 'COD' : 'PREPAID'}
                </span>
              )}
            </div>
          )}
        </div>
      )}

      {/* 2. COURIER DETAILS SECTION */}
      {showCourierSection && (
        <div className="border border-black p-1 flex justify-between items-center bg-white">
          {(hasCourier || hasTracking) ? (
            <div className="flex-1 min-w-0">
              {hasCourier && (
                <>
                  <span className="text-[6.5px] uppercase font-bold text-black tracking-wider block">Logistics Partner</span>
                  <p className="font-black text-[11px] text-black leading-tight truncate">{courierName}</p>
                </>
              )}
              {hasTracking && (
                <span className="text-[7.5px] font-mono font-bold text-black block mt-0.5">
                  AWB: {currentAwb}
                </span>
              )}
            </div>
          ) : (
            <div />
          )}
          {hasPin && (
            <div className="text-right shrink-0 ml-2">
              <span className="text-[6.5px] uppercase font-bold text-black tracking-wider block">Dest PIN</span>
              <div className="border border-black px-2 py-0.5 inline-block font-mono font-black text-xs text-black bg-white">
                {customerPin}
              </div>
            </div>
          )}
        </div>
      )}

      {/* 3. DUAL CODE AREA: EXACTLY ONE 1D BARCODE + ONE 2D QR CODE */}
      {showCodeArea && (
        <div className="border border-black p-1 bg-white space-y-1">
          {hasBarcode && (
            <div className="w-full flex flex-col items-center justify-center">
              <div
                className="w-full max-h-[38px] flex items-center justify-center [&_svg]:max-w-[200px] [&_svg]:max-h-[38px] [&_svg]:w-auto"
                dangerouslySetInnerHTML={{ __html: barcodeSvg! }}
              />
            </div>
          )}

          {hasQr && (
            <div className={`flex items-center justify-center gap-2.5 ${hasBarcode ? 'pt-1 border-t border-dashed border-black' : ''}`}>
              <div
                className="w-[48px] h-[48px] flex items-center justify-center [&_svg]:w-full [&_svg]:h-full shrink-0"
                dangerouslySetInnerHTML={{ __html: qrSvg! }}
              />
              <div className="text-[7.5px] font-mono leading-tight text-left">
                <p className="font-bold text-black uppercase">ORDER ID:</p>
                <p className="font-extrabold text-black break-all">{order.orderId}</p>
              </div>
            </div>
          )}
        </div>
      )}

      {/* 4. LARGE DELIVERY INFORMATION (DELIVERY & CUSTOMER DETAILS) */}
      {showCustomerSection && (
        <div className="border-2 border-black p-1.5 bg-white space-y-1">
          <div className="flex justify-between items-center border-b border-black pb-0.5">
            <span className="text-[7.5px] font-black uppercase tracking-wider text-black">
              DELIVER TO (RECIPIENT)
            </span>
            <span className="text-[7px] font-mono font-bold uppercase">
              EXPRESS
            </span>
          </div>

          {hasCustomerName && (
            <p className="font-black text-[13px] text-black leading-tight tracking-tight uppercase">
              {order.customer?.fullName}
            </p>
          )}

          {(hasAddress || hasCityState) && (
            <div>
              {hasAddress && (
                <p className="font-bold text-black text-[9.5px] leading-snug break-words">
                  {order.customer?.address}
                </p>
              )}
              {hasCityState && (
                <p className="font-black text-[10px] text-black pt-0.5">
                  {[order.customer?.city, order.customer?.state].filter(Boolean).join(', ')}
                </p>
              )}
            </div>
          )}

          {(hasPhone || hasCustomerPin) && (
            <div className="flex items-center justify-between pt-0.5 border-t border-dashed border-black">
              {hasPhone ? (
                <div>
                  <span className="text-[6.5px] font-bold block uppercase text-black">Mobile</span>
                  <p className="font-black text-xs text-black">
                    +91 {order.customer?.phone}
                  </p>
                </div>
              ) : (
                <div />
              )}

              {hasCustomerPin && (
                <div className="text-right">
                  <span className="text-[6.5px] font-bold block uppercase text-black">PIN CODE</span>
                  <div className="border border-black bg-white px-2 py-0.5 font-mono font-black text-xs tracking-wider inline-block">
                    {customerPin}
                  </div>
                </div>
              )}
            </div>
          )}

          {hasEmail && (
            <p className="text-[7px] text-black font-semibold truncate pt-0.5 border-t border-dashed border-black">
              Email: {order.customer?.email}
            </p>
          )}

          {hasInstructions && (
            <p className="text-[7px] text-black font-bold italic border-t border-black pt-0.5">
              Note: {(order as any).notes}
            </p>
          )}
        </div>
      )}

      {/* 5. PAYMENT DETAILS SECTION */}
      {showPaymentSection && (
        <div className={`gap-1 text-[8.5px] ${hasPaymentMode && hasCodAmt ? 'grid grid-cols-2' : 'flex flex-col'}`}>
          {hasPaymentMode && (
            <div className="border border-black p-1 flex-1">
              <span className="text-[6.5px] uppercase font-bold block">Payment Mode</span>
              <p className="font-black text-[9.5px] uppercase mt-0.5">
                {isCod ? 'Cash on Delivery (COD)' : 'Prepaid Online'}
              </p>
            </div>
          )}
          {hasCodAmt && (
            <div className="border border-black p-1 text-right bg-black text-white flex-1">
              <span className="text-[6.5px] uppercase font-bold block opacity-90">Collectable Amount</span>
              <p className="font-black text-xs mt-0.5">
                {isCod ? `₹${collectableAmount.toLocaleString('en-IN')}` : '₹0.00 (PAID)'}
              </p>
            </div>
          )}
        </div>
      )}

      {/* 6. ORDER DETAILS / PRODUCT SUMMARY SECTION */}
      {showProductSection && (
        <div className="border border-black p-1 bg-white">
          <div className="flex justify-between text-[6.5px] font-black uppercase border-b border-black pb-0.5 mb-0.5">
            <span>Item / Description</span>
            <span>Qty</span>
          </div>
          <div className="space-y-0.5 max-h-12 overflow-hidden">
            {order.items.slice(0, 3).map((item, idx) => {
              const itemName = (item as any).name || item.product?.name || (item as any).productId || 'Gadget Item';
              return (
                <div key={idx} className="flex justify-between text-[7px] font-semibold">
                  <span className="truncate max-w-[210px]">{itemName}</span>
                  <span className="font-mono font-bold">x{item.quantity}</span>
                </div>
              );
            })}
            {order.items.length > 3 && (
              <p className="text-[6.5px] italic text-black">+ {order.items.length - 3} more items</p>
            )}
          </div>
        </div>
      )}

      {/* 7. DEDICATED PICKUP & SELLER DETAILS SECTION */}
      {showPickupSection && (
        <div className="border-t border-dashed border-black pt-0.5 text-[7px] leading-tight text-black">
          <p className="font-black uppercase text-[6.5px]">If undelivered, return to:</p>
          <p className="font-bold truncate">{returnCompany}</p>
          <p className="truncate">{returnAddress}</p>
          {config.showPickupContact !== false && (
            <p className="font-semibold">Helpline: {returnPhone}</p>
          )}
        </div>
      )}

      {/* 8. FOOTER SECTION */}
      {showFooterSection && (
        <div className="border-t border-black pt-0.5 flex justify-between text-[6px] font-mono text-black">
          <span>100mm × 150mm Direct Thermal Format</span>
          <span>Std Wt: {config.showWeight !== false ? '0.50 KG' : ''}</span>
        </div>
      )}
    </div>
  );
};

export const ShippingLabelModal: React.FC<ShippingLabelModalProps> = ({
  isOpen,
  onClose,
  order,
  orders = [],
  storeSettings,
}) => {
  let updateStoreSettings: ((settings: Partial<StoreSettings>) => Promise<any>) | undefined;
  try {
    const shop = useShop();
    updateStoreSettings = shop?.updateStoreSettings;
  } catch {
    // Graceful fallback when rendered in isolated environments or test runners
  }

  // Determine list of active orders (either the array or single order)
  const activeOrdersList = useMemo(() => {
    if (orders && orders.length > 0) return orders;
    if (order) return [order];
    return [];
  }, [order, orders]);

  const [currentIndex, setCurrentIndex] = useState(0);
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);
  const [showConfigDrawer, setShowConfigDrawer] = useState(false);
  const [activePreset, setActivePreset] = useState<string>('standard');
  const [savedSettingsNotice, setSavedSettingsNotice] = useState(false);
  const labelRef = useRef<HTMLDivElement | null>(null);

  // Fallback to safe index
  const safeCurrentIndex = Math.min(Math.max(0, currentIndex), Math.max(0, activeOrdersList.length - 1));
  const currentOrder = activeOrdersList[safeCurrentIndex] || null;

  // Local editable label settings initialized directly from storeSettings.shippingLabelSettings
  const [labelConfig, setLabelConfig] = useState<ShippingLabelSettings>(() => {
    const fromStore = storeSettings.shippingLabelSettings || {};
    return {
      preset: fromStore.preset || 'standard',
      showLogo: fromStore.showLogo !== false,
      showStoreName: fromStore.showStoreName !== false,
      showDate: fromStore.showDate !== false,
      showCustomerPhone: fromStore.showCustomerPhone !== false,
      showCustomerEmail: Boolean(fromStore.showCustomerEmail),
      showAddress: fromStore.showAddress !== false,
      showCity: fromStore.showCity !== false,
      showState: fromStore.showState !== false,
      showPincode: fromStore.showPincode !== false,
      showPickupLocation: fromStore.showPickupLocation !== false,
      showPickupContact: fromStore.showPickupContact !== false,
      showSellerInfo: fromStore.showSellerInfo !== false,
      showPaymentMethod: fromStore.showPaymentMethod !== false,
      showCodAmount: fromStore.showCodAmount !== false,
      showOrderTotal: fromStore.showOrderTotal !== false,
      showProductSummary: fromStore.showProductSummary !== false,
      showSku: fromStore.showSku !== false,
      showQuantity: fromStore.showQuantity !== false,
      showWeight: fromStore.showWeight !== false,
      showCustomerNote: fromStore.showCustomerNote !== false,
      showSpecialInstructions: fromStore.showSpecialInstructions !== false,
      showCourier: fromStore.showCourier !== false,
      showCourierId: fromStore.showCourierId !== false,
      showTrackingNumber: fromStore.showTrackingNumber !== false,
      showDeliveryNumber: fromStore.showDeliveryNumber !== false,
      showOrderId: fromStore.showOrderId !== false,

      // Section visibility with smart reflow
      showHeader: fromStore.showHeader !== false,
      showCustomerDetails: fromStore.showCustomerDetails !== false,
      showDeliveryDetails: fromStore.showDeliveryDetails !== false,
      showPickupDetails: fromStore.showPickupDetails !== false,
      showOrderDetails: fromStore.showOrderDetails !== false,
      showPaymentDetails: fromStore.showPaymentDetails !== false,
      showCourierDetails: fromStore.showCourierDetails !== false,
      showProductArea: fromStore.showProductArea !== false,
      showCodeArea: fromStore.showCodeArea !== false,
      showFooter: fromStore.showFooter !== false,

      // EXACTLY 1 1D Barcode + 1 2D QR Code
      showBarcode: fromStore.showBarcode !== false,
      showQrCode: fromStore.showQrCode !== false,

      pickupLocation: {
        companyName: fromStore.pickupLocation?.companyName || storeSettings.businessLegalName || 'INFOSTORS Fulfillment Hub',
        address: fromStore.pickupLocation?.address || 'Garia Station Road, Near Metro Gate 2',
        city: fromStore.pickupLocation?.city || 'Kolkata',
        state: fromStore.pickupLocation?.state || 'West Bengal',
        pincode: fromStore.pickupLocation?.pincode || '700084',
        contactNumber: fromStore.pickupLocation?.contactNumber || storeSettings.helpline || '+91 94778 39200',
        instructions: fromStore.pickupLocation?.instructions || 'Handle with care. Store dry.',
      },
      ...fromStore,
    };
  });

  // Sync initial settings from storeSettings when opened
  useEffect(() => {
    if (storeSettings.shippingLabelSettings) {
      setLabelConfig(prev => ({
        ...prev,
        ...storeSettings.shippingLabelSettings,
        showBarcode: storeSettings.shippingLabelSettings?.showBarcode !== false,
        showQrCode: storeSettings.shippingLabelSettings?.showQrCode !== false,
        pickupLocation: {
          ...prev.pickupLocation,
          ...(storeSettings.shippingLabelSettings?.pickupLocation || {}),
        },
      }));
      if (storeSettings.shippingLabelSettings.preset) {
        setActivePreset(storeSettings.shippingLabelSettings.preset);
      }
    }
  }, [storeSettings.shippingLabelSettings, isOpen]);

  // Apply Presets
  const applyPreset = (presetKey: 'standard' | 'minimal' | 'full' | 'courier' | 'pickup' | 'cod') => {
    setActivePreset(presetKey);
    if (presetKey === 'minimal') {
      setLabelConfig(prev => ({
        ...prev,
        preset: 'minimal',
        showCustomerEmail: false,
        showProductSummary: false,
        showPickupDetails: false,
        showCustomerNote: false,
        showFooter: false,
      }));
    } else if (presetKey === 'full') {
      setLabelConfig(prev => ({
        ...prev,
        preset: 'full',
        showCustomerEmail: true,
        showProductSummary: true,
        showPickupDetails: true,
        showCustomerNote: true,
        showFooter: true,
        showBarcode: true,
        showQrCode: true,
      }));
    } else if (presetKey === 'courier') {
      setLabelConfig(prev => ({
        ...prev,
        preset: 'courier',
        showCourierDetails: true,
        showBarcode: true,
        showQrCode: true,
        showProductSummary: false,
      }));
    } else if (presetKey === 'pickup') {
      setLabelConfig(prev => ({
        ...prev,
        preset: 'pickup',
        showPickupDetails: true,
        showPickupLocation: true,
        showPickupContact: true,
      }));
    } else if (presetKey === 'cod') {
      setLabelConfig(prev => ({
        ...prev,
        preset: 'cod',
        showPaymentDetails: true,
        showCodAmount: true,
        showOrderTotal: true,
      }));
    } else {
      // standard
      setLabelConfig(prev => ({
        ...prev,
        preset: 'standard',
        showHeader: true,
        showCustomerDetails: true,
        showDeliveryDetails: true,
        showPickupDetails: true,
        showOrderDetails: true,
        showPaymentDetails: true,
        showCourierDetails: true,
        showCodeArea: true,
        showFooter: true,
        showBarcode: true,
        showQrCode: true,
      }));
    }
  };

  // Save current customized configuration to storeSettings (Requirement 16)
  const handleSaveConfigAsDefault = async () => {
    try {
      await updateStoreSettings({
        shippingLabelSettings: {
          ...labelConfig,
          preset: activePreset as any,
        },
      });
      setSavedSettingsNotice(true);
      setTimeout(() => setSavedSettingsNotice(false), 2500);
    } catch (err) {
      console.error('Failed to save shipping label settings:', err);
    }
  };

  // Helper to compute tracking/AWB number for an order
  const getOrderAwb = (ord: Order | null) => {
    if (!ord) return 'INF700084';
    if (ord.trackingId && ord.trackingId.trim().length > 0) {
      return ord.trackingId.trim();
    }
    const cleanNum = (ord.orderId || '').replace(/\D/g, '');
    return `INF${cleanNum || '700084'}`;
  };

  // Generate Barcode & QR SVG for all active orders
  const [current1DBarcodeSvg, setCurrent1DBarcodeSvg] = useState<string>('');
  const [current2DQrSvg, setCurrent2DQrSvg] = useState<string>('');
  const [svgMap, setSvgMap] = useState<Record<string, { barcode: string; qr: string }>>({});

  useEffect(() => {
    let isMounted = true;
    const generateAllSvgs = async () => {
      const result: Record<string, { barcode: string; qr: string }> = {};
      for (const ord of activeOrdersList) {
        let barcode = '';
        if (labelConfig.showBarcode !== false) {
          try {
            barcode = bwipjs.toSVG({
              bcid: 'code128',
              text: getOrderAwb(ord),
              scale: 2,
              height: 8,
              includetext: true,
              textxalign: 'center',
              textsize: 8,
            });
          } catch {
            barcode = '';
          }
        }

        let qr = '';
        if (labelConfig.showQrCode !== false) {
          try {
            // Strictly plain Order ID as requested
            qr = await QRCode.toString(ord.orderId, {
              type: 'svg',
              margin: 1,
              errorCorrectionLevel: 'M',
              color: { dark: '#000000', light: '#ffffff' },
            });
          } catch {
            qr = '';
          }
        }

        result[ord.orderId] = { barcode, qr };
      }

      if (isMounted) {
        setSvgMap(result);
        if (currentOrder && result[currentOrder.orderId]) {
          setCurrent1DBarcodeSvg(result[currentOrder.orderId].barcode);
          setCurrent2DQrSvg(result[currentOrder.orderId].qr);
        }
      }
    };

    generateAllSvgs();
    return () => {
      isMounted = false;
    };
  }, [activeOrdersList, labelConfig.showBarcode, labelConfig.showQrCode]);

  useEffect(() => {
    if (currentOrder && svgMap[currentOrder.orderId]) {
      setCurrent1DBarcodeSvg(svgMap[currentOrder.orderId].barcode);
      setCurrent2DQrSvg(svgMap[currentOrder.orderId].qr);
    }
  }, [currentOrder, svgMap]);

  if (!isOpen || activeOrdersList.length === 0 || !currentOrder) return null;

  // Direct Computer Print (Opens isolated native browser print dialog for the 100mm x 150mm Shipping Label)
  const handlePrint = async () => {
    try {
      // 1. Prepare target label element
      const labelElement = labelRef.current || document.getElementById('shipping-label-printable');
      if (!labelElement) {
        console.warn('Shipping label printable element not found.');
        return;
      }

      // 2. Wait for rendering: ensure all images inside the label are loaded
      const images = Array.from(labelElement.querySelectorAll('img'));
      await Promise.all(
        images.map(img => {
          if (img.complete && img.naturalHeight !== 0) return Promise.resolve();
          return new Promise<void>(resolve => {
            img.onload = () => resolve();
            img.onerror = () => resolve();
            setTimeout(resolve, 500);
          });
        })
      );

      // Wait for fonts if available
      if (document.fonts && document.fonts.ready) {
        try {
          await document.fonts.ready;
        } catch (_) {}
      }

      // 3. Create or clean up isolated print iframe
      const FRAME_ID = 'thermal-shipping-label-printer-frame';
      let iframe = document.getElementById(FRAME_ID) as HTMLIFrameElement | null;
      if (iframe) {
        iframe.remove();
      }

      iframe = document.createElement('iframe');
      iframe.id = FRAME_ID;
      iframe.style.position = 'fixed';
      iframe.style.right = '0';
      iframe.style.bottom = '0';
      iframe.style.width = '0';
      iframe.style.height = '0';
      iframe.style.border = '0';
      iframe.style.visibility = 'hidden';
      iframe.setAttribute('aria-hidden', 'true');
      document.body.appendChild(iframe);

      // 4. Gather stylesheets from the document to guarantee exact styling
      let styleSheetsHtml = '';
      try {
        const styleElements = document.querySelectorAll('style, link[rel="stylesheet"]');
        styleElements.forEach(el => {
          if (el.tagName.toLowerCase() === 'style') {
            styleSheetsHtml += `<style>${el.innerHTML}</style>`;
          } else if (el.tagName.toLowerCase() === 'link') {
            const href = el.getAttribute('href');
            if (href) {
              styleSheetsHtml += `<link rel="stylesheet" href="${href}" />`;
            }
          }
        });
      } catch (err) {
        console.warn('Style harvesting notice:', err);
      }

      // 5. Build isolated HTML document containing ONLY the Shipping Label
      const iframeDoc = iframe.contentWindow?.document;
      if (!iframeDoc) {
        // Fallback to window.print()
        window.print();
        return;
      }

      // Multi-order or single-order HTML
      let labelsHtml = '';
      if (activeOrdersList.length > 1) {
        labelsHtml = activeOrdersList
          .map(ord => {
            const el = document.getElementById(`shipping-label-item-${ord.orderId}`);
            const content = el ? el.outerHTML : (ord.orderId === currentOrder.orderId ? labelElement.outerHTML : '');
            return `<div class="thermal-print-page" style="width:100mm;page-break-after:always;break-after:page;">${content}</div>`;
          })
          .join('');
      } else {
        labelsHtml = `<div class="thermal-print-page" style="width:100mm;page-break-after:avoid;break-after:avoid;">${labelElement.outerHTML}</div>`;
      }

      const fullPrintDoc = `<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8" />
    <title>Shipping Label - ${currentOrder.orderId}</title>
    ${styleSheetsHtml}
    <style>
      @page {
        size: 100mm 150mm;
        margin: 0;
      }
      * {
        box-sizing: border-box !important;
        -webkit-print-color-adjust: exact !important;
        print-color-adjust: exact !important;
      }
      html, body {
        width: 100mm !important;
        margin: 0 !important;
        padding: 0 !important;
        background: #ffffff !important;
        color: #000000 !important;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif !important;
      }
      .thermal-print-page {
        width: 100mm !important;
        max-width: 100mm !important;
        margin: 0 !important;
        padding: 0 !important;
        background: #ffffff !important;
        box-sizing: border-box !important;
        page-break-inside: avoid !important;
        break-inside: avoid !important;
      }
      #shipping-label-printable {
        width: 100mm !important;
        max-width: 100mm !important;
        box-shadow: none !important;
        border: none !important;
        margin: 0 !important;
        padding: 0 !important;
      }
    </style>
  </head>
  <body>
    ${labelsHtml}
  </body>
</html>`;

      iframeDoc.open();
      iframeDoc.write(fullPrintDoc);
      iframeDoc.close();

      // 6. Wait for iframe rendering to settle, then trigger native print
      setTimeout(() => {
        try {
          if (iframe && iframe.contentWindow) {
            iframe.contentWindow.focus();
            iframe.contentWindow.print();
          }
        } catch (iframePrintErr) {
          console.warn('Iframe print notice:', iframePrintErr);
          // Fallback to top-level window print
          try {
            window.print();
          } catch (wErr) {
            console.warn('Window print notice:', wErr);
          }
        }
      }, 150);
    } catch (err) {
      console.warn('Direct computer print notice:', err);
      // Secondary fallback
      try {
        window.print();
      } catch (_) {}
    }
  };

  // Dedicated PDF Download (Supports single or multi-order batch PDF)
  const handleDownloadPdf = async () => {
    setIsGeneratingPdf(true);
    try {
      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: [100, 150], // Strictly 100mm x 150mm
        compress: true,
      });

      const html2canvasFn = typeof html2canvas === 'function' ? html2canvas : (html2canvas as any).default || html2canvas;

      if (activeOrdersList.length === 1) {
        const labelElement = labelRef.current;
        if (!labelElement) {
          throw new Error('Shipping label element not found in DOM.');
        }

        const canvas = await html2canvasFn(labelElement, {
          scale: 3, // High DPI for thermal-printer crisp resolution
          useCORS: true,
          logging: false,
          backgroundColor: '#ffffff',
        });

        const imgData = canvas.toDataURL('image/png', 1.0);
        const imgWidth = 100;
        const imgHeight = (canvas.height * imgWidth) / canvas.width;
        pdf.addImage(imgData, 'PNG', 0, 0, imgWidth, Math.min(imgHeight, 150), undefined, 'FAST');

        const fileName = `INFOSTORS-ShippingLabel-${currentOrder.orderId}.pdf`;
        pdf.save(fileName);
      } else {
        // Multi-order combined batch PDF (Requirement 7)
        let processedCount = 0;
        const failedOrders: string[] = [];

        for (let i = 0; i < activeOrdersList.length; i++) {
          const ord = activeOrdersList[i];
          try {
            const el = document.getElementById(`shipping-label-item-${ord.orderId}`) || (ord.orderId === currentOrder.orderId ? labelRef.current : null);
            if (!el) {
              failedOrders.push(ord.orderId);
              continue;
            }

            const canvas = await html2canvasFn(el, {
              scale: 3,
              useCORS: true,
              logging: false,
              backgroundColor: '#ffffff',
            });

            if (processedCount > 0) {
              pdf.addPage([100, 150], 'portrait');
            }

            const imgData = canvas.toDataURL('image/png', 1.0);
            const imgWidth = 100;
            const imgHeight = (canvas.height * imgWidth) / canvas.width;
            pdf.addImage(imgData, 'PNG', 0, 0, imgWidth, Math.min(imgHeight, 150), undefined, 'FAST');
            processedCount++;
          } catch (err) {
            console.error(`Failed to generate label for order ${ord.orderId}:`, err);
            failedOrders.push(ord.orderId);
          }
        }

        if (processedCount > 0) {
          const fileName = `INFOSTORS-ShippingLabels-Batch-${processedCount}-Orders.pdf`;
          pdf.save(fileName);
        }

        if (failedOrders.length > 0) {
          console.warn(`Generated ${processedCount} labels. Failed orders: ${failedOrders.join(', ')}`);
        }
      }
    } catch (err) {
      console.error('Failed to generate shipping label PDF:', err);
    } finally {
      setIsGeneratingPdf(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/75 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 animate-in fade-in duration-150">
      <div className="bg-white dark:bg-slate-900 text-slate-900 dark:text-white w-full max-w-5xl rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col max-h-[96vh]">
        {/* Top Control Bar (Hidden on print) */}
        <div className="px-5 py-3.5 bg-slate-900 text-white flex flex-wrap items-center justify-between gap-3 print:hidden shrink-0 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-blue-500/20 text-blue-400 flex items-center justify-center font-bold text-xs">
              100×150
            </div>
            <div>
              <h3 className="font-bold text-xs flex items-center gap-2">
                <span>Thermal Courier Shipping Label</span>
                {activeOrdersList.length > 1 && (
                  <span className="px-2 py-0.5 rounded-full bg-blue-600/40 text-blue-300 text-[10px] font-mono">
                    {safeCurrentIndex + 1} of {activeOrdersList.length} Orders Selected
                  </span>
                )}
              </h3>
              <p className="text-[10px] text-slate-400">1 Code128 Barcode + 1 QR Code • Dynamic Auto-Reflow • Thermal Print Ready</p>
            </div>
          </div>

          {/* Center Navigation if multiple orders selected */}
          {activeOrdersList.length > 1 && (
            <div className="flex items-center gap-1.5 bg-slate-800 px-2 py-1 rounded-xl">
              <button
                type="button"
                onClick={() => setCurrentIndex(prev => Math.max(0, prev - 1))}
                disabled={safeCurrentIndex === 0}
                className="p-1 rounded text-slate-300 hover:text-white disabled:opacity-30 cursor-pointer"
                title="Previous label"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <span className="text-xs font-mono font-bold px-2">
                Order #{currentOrder.orderId}
              </span>
              <button
                type="button"
                onClick={() => setCurrentIndex(prev => Math.min(activeOrdersList.length - 1, prev + 1))}
                disabled={safeCurrentIndex === activeOrdersList.length - 1}
                className="p-1 rounded text-slate-300 hover:text-white disabled:opacity-30 cursor-pointer"
                title="Next label"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          )}

          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowConfigDrawer(!showConfigDrawer)}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-colors ${
                showConfigDrawer ? 'bg-blue-600 text-white' : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
              }`}
              title="Toggle Field & Section Visibility Controls"
            >
              <Sliders className="w-3.5 h-3.5" />
              <span>{showConfigDrawer ? 'Hide Settings' : 'Customize Label'}</span>
            </button>

            <button
              onClick={handleDownloadPdf}
              disabled={isGeneratingPdf}
              className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs rounded-lg flex items-center gap-1.5 cursor-pointer shadow-xs transition-colors disabled:opacity-50"
              id="btn-download-shipping-label-pdf"
              title="Download 100mm x 150mm PDF"
            >
              <Download className="w-3.5 h-3.5 text-blue-400" />
              <span>
                {isGeneratingPdf
                  ? 'Generating PDF...'
                  : activeOrdersList.length > 1
                  ? `Download All (${activeOrdersList.length}) Labels PDF`
                  : 'Download PDF'}
              </span>
            </button>

            <button
              onClick={handlePrint}
              className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded-lg flex items-center gap-1.5 cursor-pointer shadow-xs transition-colors"
              id="btn-print-shipping-label"
              title="Direct Thermal Print (100mm x 150mm)"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>{activeOrdersList.length > 1 ? `Print All (${activeOrdersList.length}) Labels` : 'Print Label'}</span>
            </button>

            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg cursor-pointer transition-colors"
              title="Close"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Workspace Body: Split View with Configuration Drawer on Right if toggled */}
        <div className="flex-1 flex overflow-hidden bg-slate-100 dark:bg-slate-950">
          {/* Main Label Preview Area (Centered, thermal-sheet container) */}
          <div className="flex-1 p-3 sm:p-6 overflow-y-auto flex flex-col items-center justify-start">
            <div className="mb-2 text-[11px] text-slate-500 font-medium flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block animate-pulse" />
              <span>Live Dynamic Auto-Reflow Preview (100mm Thermal Format)</span>
            </div>

            {/* Printable Thermal Label (Exact 100mm width, Dynamic Content Height) */}
            <div
              id="shipping-label-printable"
              ref={labelRef}
              className="shadow-2xl rounded-xs transition-all duration-150"
            >
              <ShippingLabelContent
                order={currentOrder}
                config={labelConfig}
                storeSettings={storeSettings}
                barcodeSvg={current1DBarcodeSvg}
                qrSvg={current2DQrSvg}
              />
            </div>

            {/* Hidden container for rendering all selected labels for bulk PDF/Print */}
            {activeOrdersList.length > 1 && (
              <div
                style={{ position: 'fixed', left: '-9999px', top: '-9999px', width: '100mm', zIndex: -10 }}
                aria-hidden="true"
              >
                {activeOrdersList.map(ord => (
                  <div key={ord.orderId} id={`shipping-label-item-${ord.orderId}`}>
                    <ShippingLabelContent
                      order={ord}
                      config={labelConfig}
                      storeSettings={storeSettings}
                      barcodeSvg={svgMap[ord.orderId]?.barcode || ''}
                      qrSvg={svgMap[ord.orderId]?.qr || ''}
                    />
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Interactive Label Configuration Drawer (Presets & Fields) */}
          {showConfigDrawer && (
            <div className="w-80 bg-white dark:bg-slate-900 border-l border-slate-200 dark:border-slate-800 p-4 overflow-y-auto space-y-4 text-xs text-slate-800 dark:text-slate-100 shrink-0">
              <div className="flex items-center justify-between pb-2 border-b border-slate-200 dark:border-slate-800">
                <h4 className="font-bold text-sm flex items-center gap-1.5 text-slate-900 dark:text-white">
                  <Sliders className="w-4 h-4 text-blue-500" />
                  <span>Label Customizer</span>
                </h4>
                <button
                  onClick={() => setShowConfigDrawer(false)}
                  className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Presets (Requirement 14) */}
              <div className="space-y-1.5">
                <label className="font-extrabold text-[11px] uppercase tracking-wider block text-slate-900 dark:text-white">
                  Layout Presets
                </label>
                <div className="grid grid-cols-3 gap-1.5">
                  {(['standard', 'minimal', 'full', 'courier', 'pickup', 'cod'] as const).map(pKey => (
                    <button
                      key={pKey}
                      type="button"
                      onClick={() => applyPreset(pKey)}
                      className={`px-2 py-1.5 rounded-lg font-bold text-[10px] capitalize transition-colors cursor-pointer border ${
                        activePreset === pKey
                          ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                          : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100'
                      }`}
                    >
                      {pKey}
                    </button>
                  ))}
                </div>
              </div>

              {/* Codes Control: EXACTLY 1D Barcode + 2D QR Code */}
              <div className="space-y-2 pt-2 border-t border-slate-200 dark:border-slate-800">
                <span className="font-extrabold text-[11px] uppercase tracking-wider block text-slate-900 dark:text-white">
                  Barcode & QR Code
                </span>
                <div className="space-y-1.5">
                  <label className="flex items-center justify-between p-2 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 cursor-pointer">
                    <span className="font-semibold text-xs">1D Barcode (Code128)</span>
                    <input
                      type="checkbox"
                      checked={labelConfig.showBarcode !== false}
                      onChange={e => setLabelConfig({ ...labelConfig, showBarcode: e.target.checked })}
                      className="w-4 h-4 rounded text-blue-600 cursor-pointer"
                    />
                  </label>

                  <label className="flex items-center justify-between p-2 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 cursor-pointer">
                    <span className="font-semibold text-xs">2D QR Code</span>
                    <input
                      type="checkbox"
                      checked={labelConfig.showQrCode !== false}
                      onChange={e => setLabelConfig({ ...labelConfig, showQrCode: e.target.checked })}
                      className="w-4 h-4 rounded text-blue-600 cursor-pointer"
                    />
                  </label>
                </div>
              </div>

              {/* Field Visibility Toggles (Requirement 2, 3, 4, 13) */}
              <div className="space-y-2 pt-2 border-t border-slate-200 dark:border-slate-800">
                <span className="font-extrabold text-[11px] uppercase tracking-wider block text-slate-900 dark:text-white">
                  Field Visibility (Auto-Reflow)
                </span>
                <div className="space-y-1.5 max-h-56 overflow-y-auto pr-1">
                  {[
                    { key: 'showLogo', label: 'Store Brand Logo' },
                    { key: 'showStoreName', label: 'Store Name & Tagline' },
                    { key: 'showOrderId', label: 'Order ID Number' },
                    { key: 'showDate', label: 'Order Date' },
                    { key: 'showCourier', label: 'Logistics Partner' },
                    { key: 'showTrackingNumber', label: 'Tracking / AWB' },
                    { key: 'showCustomerPhone', label: 'Customer Mobile' },
                    { key: 'showCustomerEmail', label: 'Customer Email' },
                    { key: 'showAddress', label: 'Delivery Address' },
                    { key: 'showPincode', label: 'Destination PIN Code' },
                    { key: 'showSpecialInstructions', label: 'Special Instructions / Notes' },
                    { key: 'showPaymentMethod', label: 'Payment Method (COD/Prepaid)' },
                    { key: 'showCodAmount', label: 'COD Collectable Amount' },
                    { key: 'showProductSummary', label: 'Product Summary & Items' },
                    { key: 'showPickupLocation', label: 'Return Hub Address' },
                    { key: 'showPickupContact', label: 'Return Hub Contact' },
                    { key: 'showFooter', label: 'Thermal Footer Notice' },
                  ].map(item => (
                    <label key={item.key} className="flex items-center justify-between p-1.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 cursor-pointer text-[11px]">
                      <span>{item.label}</span>
                      <input
                        type="checkbox"
                        checked={(labelConfig as any)[item.key] !== false}
                        onChange={e => setLabelConfig({ ...labelConfig, [item.key]: e.target.checked })}
                        className="w-3.5 h-3.5 rounded text-blue-600 cursor-pointer"
                      />
                    </label>
                  ))}
                </div>
              </div>

              {/* Section Visibility Toggles */}
              <div className="space-y-2 pt-2 border-t border-slate-200 dark:border-slate-800">
                <span className="font-extrabold text-[11px] uppercase tracking-wider block text-slate-900 dark:text-white">
                  Section Collapsing
                </span>
                <div className="space-y-1.5 max-h-40 overflow-y-auto pr-1">
                  {[
                    { key: 'showHeader', label: 'Header Section' },
                    { key: 'showCourierDetails', label: 'Courier Section' },
                    { key: 'showCodeArea', label: 'Code Area (Barcode/QR)' },
                    { key: 'showCustomerDetails', label: 'Delivery Section' },
                    { key: 'showPaymentDetails', label: 'Payment Section' },
                    { key: 'showOrderDetails', label: 'Product Summary Section' },
                    { key: 'showPickupDetails', label: 'Return Hub Section' },
                    { key: 'showFooter', label: 'Footer Section' },
                  ].map(item => (
                    <label key={item.key} className="flex items-center justify-between p-1.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 cursor-pointer text-[11px]">
                      <span>{item.label}</span>
                      <input
                        type="checkbox"
                        checked={(labelConfig as any)[item.key] !== false}
                        onChange={e => setLabelConfig({ ...labelConfig, [item.key]: e.target.checked })}
                        className="w-3.5 h-3.5 rounded text-blue-600 cursor-pointer"
                      />
                    </label>
                  ))}
                </div>
              </div>

              {/* Save Configuration to Database */}
              <div className="pt-2 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={handleSaveConfigAsDefault}
                  className="w-full py-2 bg-slate-900 dark:bg-slate-800 hover:bg-slate-800 dark:hover:bg-slate-700 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 cursor-pointer shadow-xs transition-colors"
                >
                  <Save className="w-3.5 h-3.5 text-blue-400" />
                  <span>{savedSettingsNotice ? 'Settings Saved!' : 'Save as Store Default'}</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
