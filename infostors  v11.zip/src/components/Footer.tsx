import React, { useState } from 'react';
import { Phone, Mail, MapPin, ShieldCheck, Truck, RotateCcw, Smartphone, Play, Send, Check, AlertCircle } from 'lucide-react';
import { useShop } from '../context/ShopContext';
import { InfostorsLogo } from './InfostorsLogo';
import { WhatsAppIcon } from './WhatsAppIcon';
import { usePwaInstall } from '../utils/usePwaInstall';

export const Footer: React.FC = () => {
  const { storeSettings, setPolicyModal, setSelectedCategory } = useShop();
  const { isInstalled, canInstall, promptInstall, isAndroid, isIOS } = usePwaInstall();
  const [subscriberEmail, setSubscriberEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);
  const [playStoreFeedback, setPlayStoreFeedback] = useState<string | null>(null);

  const pwaSettings = storeSettings.pwaSettings;
  const isApkAvailable = isAndroid && pwaSettings?.enableApkDownload !== false && Boolean(pwaSettings?.apkDetails?.fileName && pwaSettings?.apkDetails?.status === 'available');
  const showPwaInstall = !isInstalled && pwaSettings?.pwaInstallEnabled !== false && pwaSettings?.showInstallButton !== false;
  const showPlayStore = pwaSettings?.playStoreEnabled !== false && !isIOS;
  const playStoreUrl = pwaSettings?.playStoreUrl?.trim();

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (subscriberEmail.trim() && subscriberEmail.includes('@')) {
      setSubscribed(true);
      setTimeout(() => {
        setSubscribed(false);
        setSubscriberEmail('');
      }, 3000);
    }
  };

  const handlePlayStoreClick = (e: React.MouseEvent) => {
    if (playStoreUrl) {
      fetch('/api/app/track-download', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type: 'playstore' }),
      }).catch(() => {});
      window.open(playStoreUrl, '_blank', 'noopener,noreferrer');
    } else {
      e.preventDefault();
      setPlayStoreFeedback('Google Play Store link is not configured yet in Admin Settings.');
      setTimeout(() => setPlayStoreFeedback(null), 4000);
    }
  };

  const handleInstallPwa = async () => {
    if (isApkAvailable) {
      fetch('/api/app/track-download', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type: 'apk', version: pwaSettings?.apkDetails?.version }),
      }).catch(() => {});
      const apkLink = document.createElement('a');
      apkLink.href = '/api/app/download-apk';
      apkLink.download = pwaSettings?.apkDetails?.fileName || 'infostors.apk';
      document.body.appendChild(apkLink);
      apkLink.click();
      document.body.removeChild(apkLink);
      setPlayStoreFeedback('APK download started. Check your notifications to install.');
      setTimeout(() => setPlayStoreFeedback(null), 5000);
      return;
    }

    if (canInstall) {
      await promptInstall();
    } else {
      setPlayStoreFeedback(
        isIOS
          ? 'To install, tap Share (⎋) at the bottom and choose "Add to Home Screen".'
          : 'To install, open your browser menu (⋮) and choose "Install app" or "Add to Home screen".'
      );
      setTimeout(() => setPlayStoreFeedback(null), 5000);
    }
  };

  const handleWhatsAppHelp = () => {
    const rawNumber = (storeSettings.helpline || '9477839200').replace(/[^0-9]/g, '');
    const fullNumber = rawNumber.startsWith('91') ? rawNumber : `91${rawNumber}`;
    window.open(
      `https://wa.me/${fullNumber}?text=${encodeURIComponent(`Hi ${storeSettings.storeName || 'INFOSTORS'}, I need assistance with an order or product.`)}`,
      '_blank',
      'noopener,noreferrer'
    );
  };

  return (
    <footer className="w-full bg-slate-900 text-slate-300 border-t border-slate-800 text-xs mt-12 pb-24 md:pb-8">
      {/* 1. Value Props Rail */}
      <div className="border-b border-slate-800 py-6 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto grid grid-cols-2 sm:grid-cols-4 gap-6 text-center sm:text-left">
          <div className="flex flex-col sm:flex-row items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-500/10 text-blue-400 flex items-center justify-center shrink-0">
              <Truck className="w-5 h-5" />
            </div>
            <div>
              <p className="font-bold text-white text-xs">Free Nationwide Delivery</p>
              <p className="text-[11px] text-slate-400">On orders above ₹{storeSettings.freeDeliveryMin || 499}</p>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center shrink-0">
              <RotateCcw className="w-5 h-5" />
            </div>
            <div>
              <p className="font-bold text-white text-xs">{storeSettings.returnWindow || '7 Days Replacement'}</p>
              <p className="text-[11px] text-slate-400">Hassle-free guarantee</p>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 text-amber-400 flex items-center justify-center shrink-0">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <p className="font-bold text-white text-xs">100% Secure Checkout</p>
              <p className="text-[11px] text-slate-400">UPI, Cards, NetBanking, COD</p>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-500/10 text-indigo-400 flex items-center justify-center shrink-0">
              <Phone className="w-5 h-5" />
            </div>
            <div>
              <p className="font-bold text-white text-xs">Direct Support</p>
              <p className="text-[11px] text-slate-400">{storeSettings.helpline || '+91 94778 39200'}</p>
            </div>
          </div>
        </div>
      </div>

      {/* 2. Main Footer Navigation & Brand Section */}
      <div className="max-w-7xl mx-auto py-10 px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
        {/* Brand Column (Span 2 on lg) */}
        <div className="lg:col-span-2 space-y-4">
          {storeSettings.logoUrl ? (
            <img
              src={storeSettings.logoUrl}
              alt={storeSettings.storeName || 'INFOSTORS'}
              className="h-10 w-auto max-w-[200px] object-contain"
            />
          ) : (
            <InfostorsLogo className="h-10 w-auto" />
          )}
          <p className="text-slate-400 text-xs leading-relaxed max-w-sm">
            {storeSettings.tagline || 'Smart Gadgets | Better Life'} — Premium lifestyle electronics, GaN fast chargers, audio devices, smart lighting and everyday essentials delivered nationwide across India.
          </p>

          {/* Mobile Apps & Official Links */}
          <div className="space-y-2 pt-1">
            <p className="text-[11px] font-bold text-slate-300 uppercase tracking-wider">Experience on Mobile</p>
            <div className="flex flex-wrap items-center gap-2.5">
              {/* Real PWA Install Button (Disappears when actually installed) */}
              {showPwaInstall && (
                <button
                  type="button"
                  onClick={handleInstallPwa}
                  className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-bold flex items-center gap-2 border border-slate-700 transition cursor-pointer shadow-xs"
                  title="Install Progressive Web App on your device"
                  id="footer-btn-install-pwa"
                >
                  <Smartphone className="w-4 h-4 text-blue-400" />
                  <span>Install Android App</span>
                </button>
              )}

              {/* Official Google Play Store Button */}
              {showPlayStore && (
                <div className="relative">
                  <button
                    type="button"
                    onClick={handlePlayStoreClick}
                    className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-bold flex items-center gap-2 border border-slate-700 transition cursor-pointer shadow-xs"
                    title={playStoreUrl ? 'Open Google Play Store' : 'Google Play Store link not configured'}
                    id="footer-btn-play-store"
                  >
                    <Play className="w-3.5 h-3.5 text-emerald-400 fill-emerald-400" />
                    <span>Google Play</span>
                  </button>
                </div>
              )}

              {/* Genuine WhatsApp Support Button with Official WhatsApp Branding */}
              <button
                type="button"
                onClick={handleWhatsAppHelp}
                className="px-3.5 py-1.5 bg-[#25D366]/20 hover:bg-[#25D366]/30 text-emerald-400 rounded-xl text-xs font-bold flex items-center gap-2 border border-emerald-500/40 transition cursor-pointer shadow-xs"
                title="Chat on WhatsApp"
                id="footer-btn-whatsapp"
              >
                <WhatsAppIcon className="w-4 h-4 fill-[#25D366]" />
                <span>WhatsApp Help</span>
              </button>
            </div>

            {/* Notification Feedback Toast */}
            {playStoreFeedback && (
              <div className="animate-in fade-in duration-200 mt-2 p-2 bg-slate-800 border border-slate-700 text-amber-300 rounded-xl text-[11px] flex items-center gap-1.5">
                <AlertCircle className="w-3.5 h-3.5 shrink-0 text-amber-400" />
                <span>{playStoreFeedback}</span>
              </div>
            )}
          </div>
        </div>

        {/* Top Categories */}
        <div className="space-y-2">
          <h4 className="font-bold text-white text-xs uppercase tracking-wider">Top Categories</h4>
          <ul className="space-y-1.5 text-slate-400">
            <li>
              <button
                onClick={() => setSelectedCategory('audio-sound')}
                className="hover:text-blue-400 transition-colors cursor-pointer"
              >
                Audio & Sound
              </button>
            </li>
            <li>
              <button
                onClick={() => setSelectedCategory('mobile-accessories')}
                className="hover:text-blue-400 transition-colors cursor-pointer"
              >
                Mobile Accessories
              </button>
            </li>
            <li>
              <button
                onClick={() => setSelectedCategory('rgb-lights')}
                className="hover:text-blue-400 transition-colors cursor-pointer"
              >
                RGB Smart Lights
              </button>
            </li>
            <li>
              <button
                onClick={() => setSelectedCategory('smart-home')}
                className="hover:text-blue-400 transition-colors cursor-pointer"
              >
                Smart Home
              </button>
            </li>
          </ul>
        </div>

        {/* Customer Care & Policies */}
        <div className="space-y-2">
          <h4 className="font-bold text-white text-xs uppercase tracking-wider">Customer Care</h4>
          <ul className="space-y-1.5 text-slate-400">
            <li>
              <button
                onClick={() => setPolicyModal('returns')}
                className="hover:text-blue-400 transition-colors cursor-pointer"
              >
                Replacement Policy
              </button>
            </li>
            <li>
              <button
                onClick={() => setPolicyModal('privacy')}
                className="hover:text-blue-400 transition-colors cursor-pointer"
              >
                Privacy Policy
              </button>
            </li>
            <li>
              <button
                onClick={() => setPolicyModal('terms')}
                className="hover:text-blue-400 transition-colors cursor-pointer"
              >
                Terms of Service
              </button>
            </li>
            <li>
              <button
                onClick={() => setPolicyModal('shipping')}
                className="hover:text-blue-400 transition-colors cursor-pointer"
              >
                Shipping Information
              </button>
            </li>
          </ul>
        </div>

        {/* Newsletter & Contact */}
        <div className="space-y-3">
          <h4 className="font-bold text-white text-xs uppercase tracking-wider">Stay Connected</h4>
          <p className="text-[11px] text-slate-400">
            Subscribe for flash deal alerts & exclusive gadget launches.
          </p>
          <form onSubmit={handleSubscribe} className="space-y-2">
            <div className="flex gap-1.5">
              <input
                type="email"
                required
                value={subscriberEmail}
                onChange={e => setSubscriberEmail(e.target.value)}
                placeholder="your.email@gmail.com"
                className="w-full px-3 py-1.5 bg-slate-800 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 outline-none focus:border-blue-500"
              />
              <button
                type="submit"
                className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-bold cursor-pointer transition shrink-0"
              >
                {subscribed ? <Check className="w-3.5 h-3.5" /> : <Send className="w-3.5 h-3.5" />}
              </button>
            </div>
            {subscribed && (
              <p className="text-[10.5px] text-emerald-400 font-medium">Thank you for subscribing!</p>
            )}
          </form>

          <div className="pt-2 text-slate-400 space-y-1 text-[11px]">
            <p className="flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5 text-blue-400 shrink-0" />
              <span>{storeSettings.officeAddress || 'Kolkata 700084, India'}</span>
            </p>
            <p className="flex items-center gap-1.5">
              <Mail className="w-3.5 h-3.5 text-blue-400 shrink-0" />
              <span>{storeSettings.email || 'contactinfostors@gmail.com'}</span>
            </p>
          </div>
        </div>
      </div>

      {/* 3. Bottom Payment Badges & Copyright Bar */}
      <div className="border-t border-slate-800 pt-6 pb-2 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left">
        <div>
          <p className="text-slate-400 text-[11px]">
            © {new Date().getFullYear()} {storeSettings.storeName || 'INFOSTORS'} Enterprises. All rights reserved.
          </p>
          <p className="text-slate-500 text-[10px] mt-0.5">
            Prices inclusive of all applicable taxes unless otherwise noted.
          </p>
        </div>

        {/* Payment Badges */}
        <div className="flex flex-wrap items-center justify-center gap-2">
          {['UPI / QR', 'Visa', 'Mastercard', 'RuPay', 'NetBanking', 'Cash on Delivery'].map(badge => (
            <span
              key={badge}
              className="px-2 py-0.5 rounded-md bg-slate-800 border border-slate-700 text-slate-400 text-[10px] font-medium"
            >
              {badge}
            </span>
          ))}
        </div>
      </div>
    </footer>
  );
};
