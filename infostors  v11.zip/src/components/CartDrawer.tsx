import React from 'react';
import { 
  X, 
  Trash2, 
  Plus, 
  Minus, 
  ShoppingBag, 
  ArrowRight, 
  ShieldCheck, 
  Truck,
  Sparkles,
  Tag,
  Check
} from 'lucide-react';
import { useShop } from '../context/ShopContext';

export const CartDrawer: React.FC = () => {
  const {
    isCartOpen,
    setIsCartOpen,
    cart,
    cartCount,
    cartSubtotal,
    cartSavings,
    deliveryCharge,
    cartGrandTotal,
    updateQuantity,
    removeFromCart,
    clearCart,
    setIsCheckoutOpen,
    storeSettings,
    isGstActive,
    gstAmount,
    gstRate,
    gstType,
    featureFlags,
    activeCoupons,
    appliedCoupon,
    couponDiscount,
    applyCoupon,
    removeCoupon,
  } = useShop();

  const [couponCodeInput, setCouponCodeInput] = React.useState('');
  const [couponFeedback, setCouponFeedback] = React.useState<{ text: string; isError: boolean } | null>(null);

  const handleApplyCoupon = async (codeToApply?: string) => {
    const code = (codeToApply || couponCodeInput).trim();
    if (!code) return;
    const res = await applyCoupon(code);
    if (res.success) {
      setCouponFeedback({ text: res.message || 'Coupon applied!', isError: false });
      setCouponCodeInput('');
    } else {
      setCouponFeedback({ text: res.error || 'Invalid coupon.', isError: true });
    }
    setTimeout(() => setCouponFeedback(null), 3500);
  };

  if (!isCartOpen) return null;

  const isFreeDeliveryAlways = (storeSettings?.standardDeliveryCharge ?? 49) === 0;
  const isFreeThresholdEnabled = storeSettings?.enableFreeDeliveryThreshold ?? true;
  const freeDeliveryThreshold = storeSettings?.freeDeliveryMin ?? 499;
  const differenceForFreeDelivery = freeDeliveryThreshold - cartSubtotal;

  const handleProceedToCheckout = () => {
    setIsCartOpen(false);
    setIsCheckoutOpen(true);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-slate-900/60 backdrop-blur-xs flex justify-end animate-in fade-in duration-200">
      <div 
        className="bg-white dark:bg-slate-900 w-full max-w-md h-full shadow-2xl flex flex-col justify-between overflow-hidden text-slate-800 dark:text-slate-100 transition-colors duration-200"
        id="cart-drawer-container"
      >
        {/* Cart Header */}
        <div className="px-5 py-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between bg-slate-50/70 dark:bg-slate-800/70">
          <div className="flex items-center gap-2">
            <ShoppingBag className="w-5 h-5 text-blue-600 dark:text-blue-400" />
            <h2 className="font-bold text-base text-slate-900 dark:text-slate-100">Your Shopping Cart</h2>
            <span className="bg-blue-100 dark:bg-blue-950/80 text-blue-800 dark:text-blue-300 text-xs font-bold px-2 py-0.5 rounded-full">
              {cartCount} {cartCount === 1 ? 'item' : 'items'}
            </span>
          </div>

          <button
            onClick={() => setIsCartOpen(false)}
            className="p-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-200/60 dark:hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
            aria-label="Close cart"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Free Delivery Tracker */}
        {cart.length > 0 && (
          <div className="bg-blue-50/80 px-5 py-2.5 border-b border-blue-100 text-xs">
            {isFreeDeliveryAlways ? (
              <div className="flex items-center gap-1.5 text-emerald-700 font-bold">
                <Truck className="w-4 h-4 text-emerald-600" />
                <span>100% Free Delivery on all orders across India!</span>
              </div>
            ) : isFreeThresholdEnabled && differenceForFreeDelivery > 0 ? (
              <div className="space-y-1.5">
                <div className="flex justify-between text-blue-900 font-semibold">
                  <span>Add ₹{differenceForFreeDelivery.toLocaleString('en-IN')} more for FREE Delivery!</span>
                  <span>{Math.round((cartSubtotal / freeDeliveryThreshold) * 100)}%</span>
                </div>
                <div className="w-full bg-blue-200 h-1.5 rounded-full overflow-hidden">
                  <div
                    className="bg-blue-600 h-full rounded-full transition-all duration-300"
                    style={{ width: `${Math.min(100, (cartSubtotal / freeDeliveryThreshold) * 100)}%` }}
                  ></div>
                </div>
              </div>
            ) : isFreeThresholdEnabled ? (
              <div className="flex items-center gap-1.5 text-emerald-700 font-bold">
                <Truck className="w-4 h-4 text-emerald-600" />
                <span>Congratulations! You qualify for FREE Delivery across India.</span>
              </div>
            ) : (
              <div className="flex items-center gap-1.5 text-slate-700 font-medium">
                <Truck className="w-4 h-4 text-blue-600" />
                <span>Flat shipping fee of ₹{storeSettings?.standardDeliveryCharge ?? 49} across India.</span>
              </div>
            )}
          </div>
        )}

        {/* Cart Items List */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
          {cart.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center space-y-4 py-12">
              <div className="w-20 h-20 rounded-full bg-slate-100 flex items-center justify-center text-slate-400">
                <ShoppingBag className="w-10 h-10 stroke-1" />
              </div>
              <div className="space-y-1">
                <h3 className="font-bold text-slate-800 text-base">Your cart is empty</h3>
                <p className="text-xs text-slate-500 max-w-xs">
                  Discover electronics, gadgets, and daily essentials and add them to your cart.
                </p>
              </div>
              <button
                onClick={() => setIsCartOpen(false)}
                className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl shadow-xs transition-colors cursor-pointer"
              >
                Continue Shopping
              </button>
            </div>
          ) : (
            <>
              <div className="space-y-3">
                {cart.map(item => (
                  <div
                    key={item.product.id}
                    className="flex gap-3.5 p-3 rounded-xl border border-slate-200/80 bg-slate-50/40 hover:bg-white hover:border-slate-300 transition-all"
                  >
                    <div className="w-20 h-20 rounded-lg bg-white border border-slate-200/60 p-1.5 shrink-0 flex items-center justify-center">
                      <img
                        src={item.product.image}
                        alt={item.product.name}
                        className="w-full h-full object-contain"
                      />
                    </div>

                    <div className="flex-1 flex flex-col justify-between">
                      <div className="space-y-0.5">
                        <div className="flex items-start justify-between gap-1">
                          <h4 className="font-bold text-xs text-slate-900 line-clamp-2 leading-tight">
                            {item.product.name}
                          </h4>
                          <button
                            onClick={() => removeFromCart(item.product.id)}
                            className="text-slate-400 hover:text-rose-500 p-1 transition-colors cursor-pointer"
                            title="Remove item"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                        <div className="text-[10px] text-slate-500 font-medium">
                          {item.product.brand}
                        </div>
                      </div>

                      <div className="flex items-center justify-between pt-1">
                        <div className="flex items-baseline gap-1.5">
                          <span className="font-extrabold text-sm text-slate-900">
                            ₹{(item.product.price * item.quantity).toLocaleString('en-IN')}
                          </span>
                          {item.quantity > 1 && (
                            <span className="text-[10px] text-slate-400">
                              (₹{item.product.price} each)
                            </span>
                          )}
                        </div>

                        {/* Quantity Counter */}
                        <div className="flex items-center border border-slate-300 rounded-lg bg-white shadow-xs">
                          <button
                            onClick={() => updateQuantity(item.product.id, item.quantity - 1)}
                            className="p-1 text-slate-600 hover:text-blue-600 cursor-pointer"
                            title="Decrease"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="px-2 text-xs font-bold text-slate-800">
                            {item.quantity}
                          </span>
                          <button
                            onClick={() => updateQuantity(item.product.id, item.quantity + 1)}
                            disabled={item.quantity >= item.product.stock}
                            className="p-1 text-slate-600 hover:text-blue-600 disabled:opacity-30 cursor-pointer"
                            title="Increase"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <div className="flex justify-between items-center pt-2">
                <button
                  onClick={clearCart}
                  className="text-xs text-rose-600 hover:text-rose-700 font-semibold cursor-pointer"
                >
                  Clear All Items
                </button>
                <div className="text-[11px] text-slate-500">
                  Secure 256-Bit Encrypted
                </div>
              </div>
            </>
          )}
        </div>

        {/* Cart Footer with Calculations & Checkout Button */}
        {cart.length > 0 && (
          <div className="p-4 sm:p-5 border-t border-slate-200 bg-slate-50 space-y-3.5 shadow-lg">
            {/* Coupon Code Section */}
            {featureFlags.coupons && (
              <div className="space-y-2 pb-2 border-b border-slate-200">
                {appliedCoupon ? (
                  <div className="flex items-center justify-between p-2.5 bg-emerald-50 border border-emerald-200 rounded-xl text-xs">
                    <div className="flex items-center gap-2">
                      <div className="w-6 h-6 rounded-lg bg-emerald-600 text-white flex items-center justify-center">
                        <Check className="w-3.5 h-3.5" />
                      </div>
                      <div>
                        <span className="font-mono font-bold text-emerald-800">{appliedCoupon.code}</span>
                        <span className="text-emerald-700 ml-1.5 font-semibold">Applied (-₹{couponDiscount})</span>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={removeCoupon}
                      className="text-xs text-rose-600 hover:text-rose-700 font-bold cursor-pointer"
                    >
                      Remove
                    </button>
                  </div>
                ) : (
                  <div className="space-y-1.5">
                    <div className="flex gap-2">
                      <div className="relative flex-1">
                        <Tag className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                        <input
                          type="text"
                          value={couponCodeInput}
                          onChange={e => setCouponCodeInput(e.target.value.toUpperCase())}
                          placeholder="Enter coupon code"
                          className="w-full pl-8 pr-3 py-1.5 text-xs font-mono font-bold uppercase bg-white border border-slate-300 rounded-xl outline-none focus:border-blue-500"
                        />
                      </div>
                      <button
                        type="button"
                        onClick={() => handleApplyCoupon()}
                        disabled={!couponCodeInput.trim()}
                        className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-700 disabled:opacity-40 text-white text-xs font-bold rounded-xl transition cursor-pointer"
                      >
                        Apply
                      </button>
                    </div>

                    {couponFeedback && (
                      <p className={`text-[11px] font-semibold ${couponFeedback.isError ? 'text-rose-600' : 'text-emerald-600'}`}>
                        {couponFeedback.text}
                      </p>
                    )}

                    {activeCoupons.length > 0 && !appliedCoupon && (
                      <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pt-1">
                        <span className="text-[10px] text-slate-400 font-medium shrink-0">Available:</span>
                        {activeCoupons.slice(0, 3).map(c => (
                          <button
                            key={c.id}
                            type="button"
                            onClick={() => handleApplyCoupon(c.code)}
                            className="px-2 py-0.5 bg-white hover:bg-blue-50 border border-dashed border-blue-300 text-blue-700 text-[10px] font-mono font-bold rounded-md shrink-0 cursor-pointer"
                          >
                            {c.code}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}

            <div className="space-y-1.5 text-xs">
              <div className="flex justify-between text-slate-600 dark:text-slate-400">
                <span>Subtotal</span>
                <span className="font-bold text-slate-800 dark:text-slate-200">₹{cartSubtotal.toLocaleString('en-IN')}</span>
              </div>

              {cartSavings > 0 && (
                <div className="flex justify-between text-emerald-600 dark:text-emerald-400 font-medium">
                  <span>Special Discount Savings</span>
                  <span>-₹{cartSavings.toLocaleString('en-IN')}</span>
                </div>
              )}

              {couponDiscount > 0 && (
                <div className="flex justify-between text-emerald-600 dark:text-emerald-400 font-bold">
                  <span>Coupon Discount ({appliedCoupon?.code})</span>
                  <span>-₹{couponDiscount.toLocaleString('en-IN')}</span>
                </div>
              )}

              <div className="flex justify-between text-slate-600 dark:text-slate-400">
                <span>Delivery Charges</span>
                <span className="font-bold">
                  {deliveryCharge === 0 ? (
                    <span className="text-emerald-600 dark:text-emerald-400 font-extrabold uppercase text-[11px]">FREE</span>
                  ) : (
                    `₹${deliveryCharge}`
                  )}
                </span>
              </div>

              {isGstActive && (
                <div className="flex justify-between text-slate-600 dark:text-slate-400">
                  <span className="flex items-center gap-1">
                    <span>GST ({gstRate}%)</span>
                    <span className="text-[10px] text-slate-400">
                      ({gstType === 'exclusive' ? 'Extra' : 'Included'})
                    </span>
                  </span>
                  <span className="font-bold text-slate-800 dark:text-slate-200">
                    {gstType === 'exclusive' ? `+₹${gstAmount.toLocaleString('en-IN')}` : `₹${gstAmount.toLocaleString('en-IN')}`}
                  </span>
                </div>
              )}

              <div className="border-t border-slate-200 dark:border-slate-800 pt-2 flex justify-between items-baseline">
                <span className="font-extrabold text-sm text-slate-900 dark:text-slate-100">Total Amount</span>
                <span className="font-black text-xl text-blue-700 dark:text-blue-400">
                  ₹{Math.max(0, cartGrandTotal - couponDiscount).toLocaleString('en-IN')}
                </span>
              </div>
            </div>

            <div className="space-y-2">
              <button
                onClick={handleProceedToCheckout}
                className="w-full py-3 px-4 bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white font-bold text-sm rounded-xl shadow-lg shadow-blue-600/25 hover:shadow-blue-600/40 transition-all flex items-center justify-center gap-2 cursor-pointer"
                id="cart-proceed-checkout"
              >
                <span>Proceed to Checkout</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={() => setIsCartOpen(false)}
                className="w-full py-2 text-slate-600 hover:text-slate-900 font-semibold text-xs transition-colors cursor-pointer"
              >
                Continue Shopping
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
