import React, { useState } from 'react';
import { Tag, Sparkles, Copy, Check, ArrowRight } from 'lucide-react';
import { useShop } from '../../context/ShopContext';

export const PromotionalOffersSection: React.FC = () => {
  const { activeOffers, featureFlags, setSelectedSection, applyCoupon, setIsCartOpen } = useShop();
  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  if (!featureFlags.offers || activeOffers.length === 0) {
    return null;
  }

  const handleCopyCode = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCode(code);
    setTimeout(() => setCopiedCode(null), 2500);
  };

  const handleApplyAndShop = (code?: string) => {
    if (code) {
      applyCoupon(code);
    }
    setSelectedSection('deals');
    const el = document.getElementById('products-grid-section');
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section className="my-6 max-w-7xl mx-auto px-3 sm:px-4 md:px-6">
      <div className="flex items-center justify-between pb-3">
        <div className="flex items-center gap-2">
          <div className="p-1.5 rounded-lg bg-blue-100 text-blue-700">
            <Tag className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-base sm:text-lg font-black text-slate-900 tracking-tight flex items-center gap-1.5">
              <span>Exclusive Offers & Coupons</span>
              <Sparkles className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
            </h3>
            <p className="text-xs text-slate-500">Apply valid coupons at checkout to unlock guaranteed instant savings</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5 sm:gap-4">
        {activeOffers.map(offer => {
          const isCopied = copiedCode === offer.code;

          return (
            <div
              key={offer.id}
              className="relative bg-gradient-to-br from-slate-900 via-slate-800 to-indigo-950 text-white rounded-2xl p-4 sm:p-5 flex flex-col justify-between border border-slate-700/80 shadow-md hover:shadow-xl transition-all overflow-hidden group"
            >
              {/* Decorative accent */}
              <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/10 rounded-full blur-xl pointer-events-none group-hover:bg-blue-500/20 transition-all" />

              <div className="space-y-2 relative z-10">
                <div className="flex items-center justify-between">
                  <span className="bg-amber-400/20 text-amber-300 border border-amber-400/30 text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-md tracking-wider">
                    {offer.badge || 'PROMO DEAL'}
                  </span>
                  <span className="text-[10px] text-slate-400">
                    Valid till {new Date(offer.validTill).toLocaleDateString('en-IN', { month: 'short', day: 'numeric' })}
                  </span>
                </div>

                <h4 className="text-sm sm:text-base font-black text-white tracking-tight line-clamp-1">
                  {offer.title}
                </h4>

                <p className="text-xs text-slate-300 font-normal line-clamp-2">
                  {offer.description}
                </p>

                <div className="text-lg sm:text-xl font-black bg-gradient-to-r from-amber-300 via-yellow-200 to-amber-400 bg-clip-text text-transparent">
                  {offer.discountText}
                </div>
              </div>

              {/* Action coupon box */}
              {offer.code && (
                <div className="mt-4 pt-3 border-t border-slate-700/70 flex items-center justify-between gap-2">
                  <div className="flex items-center gap-1.5 bg-black/40 border border-dashed border-blue-400/40 px-2.5 py-1 rounded-xl">
                    <span className="font-mono font-black text-xs text-blue-300 tracking-wider">
                      {offer.code}
                    </span>
                    <button
                      type="button"
                      onClick={() => handleCopyCode(offer.code!)}
                      className="text-slate-400 hover:text-white transition p-0.5"
                      title="Copy Coupon Code"
                    >
                      {isCopied ? (
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                    </button>
                  </div>

                  <button
                    type="button"
                    onClick={() => handleApplyAndShop(offer.code)}
                    className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 active:bg-blue-700 text-white font-bold text-xs rounded-xl transition flex items-center gap-1 cursor-pointer shadow-xs"
                  >
                    <span>Shop Deal</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </section>
  );
};
