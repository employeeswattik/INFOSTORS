import React, { useState, useEffect } from 'react';
import { Flame, Clock, Sparkles, Zap, ArrowRight } from 'lucide-react';
import { useShop } from '../../context/ShopContext';
import { Product } from '../../types';

export const FlashSaleSection: React.FC = () => {
  const {
    activeFlashSales,
    products,
    featureFlags,
    layoutSettings,
    setSelectedProduct,
    buyNow,
    addToCart,
  } = useShop();

  const currentSale = activeFlashSales[0];

  // Calculate countdown time remaining - declared unconditionally
  const [timeLeft, setTimeLeft] = useState<{ hours: number; minutes: number; seconds: number }>({
    hours: 12,
    minutes: 45,
    seconds: 30,
  });

  useEffect(() => {
    if (!currentSale?.endDate) return;

    const updateCountdown = () => {
      const now = new Date().getTime();
      const end = new Date(currentSale.endDate).getTime();
      const distance = Math.max(0, end - now);

      const hours = Math.floor(distance / (1000 * 60 * 60));
      const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((distance % (1000 * 60)) / 1000);

      setTimeLeft({ hours, minutes, seconds });
    };

    updateCountdown();
    const interval = setInterval(updateCountdown, 1000);
    return () => clearInterval(interval);
  }, [currentSale?.endDate]);

  // Find products participating in this flash sale
  const saleProducts = (currentSale?.products || [])
    .map(sp => {
      const prod = products.find(p => p.id === sp.productId);
      if (!prod) return null;
      return {
        product: prod,
        flashPrice: sp.flashPrice,
        flashStock: sp.flashStock,
        soldCount: sp.soldCount,
      };
    })
    .filter((item): item is { product: Product; flashPrice: number; flashStock: number; soldCount: number } => item !== null);

  // If feature disabled, no active flash sale, hidden by layout settings, or no products, do not render
  if (
    !featureFlags.flashSale ||
    !currentSale ||
    saleProducts.length === 0 ||
    layoutSettings?.customer?.showFlashSaleSection === false
  ) {
    return null;
  }

  return (
    <section className="my-6 max-w-7xl mx-auto px-3 sm:px-4 md:px-6">
      <div className="bg-gradient-to-r from-red-600 via-rose-600 to-amber-600 rounded-3xl p-4 sm:p-6 shadow-xl shadow-rose-900/10 text-white overflow-hidden relative">
        {/* Subtle decorative background glow */}
        <div className="absolute -top-12 -right-12 w-48 h-48 bg-white/10 rounded-full blur-2xl pointer-events-none" />
        <div className="absolute -bottom-12 -left-12 w-48 h-48 bg-amber-400/20 rounded-full blur-2xl pointer-events-none" />

        {/* Section Header with Countdown Timer */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-white/20">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center shadow-inner">
              <Flame className="w-6 h-6 text-amber-300 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg sm:text-xl font-black tracking-tight text-white flex items-center gap-2">
                  {currentSale.title}
                </h3>
                <span className="bg-amber-400 text-slate-950 text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full shadow-xs">
                  {currentSale.discountPercentage}% OFF
                </span>
              </div>
              <p className="text-xs text-white/80 font-medium">
                {currentSale.subtitle || 'Limited-time explosive gadget deals. Stock is running out fast!'}
              </p>
            </div>
          </div>

          {/* Countdown Clock Display */}
          <div className="flex items-center gap-2 self-start sm:self-auto bg-black/30 backdrop-blur-md px-3.5 py-1.5 rounded-2xl border border-white/10">
            <Clock className="w-4 h-4 text-amber-300 animate-spin-slow" />
            <span className="text-[11px] font-bold text-white/90 uppercase tracking-wider">Ends in:</span>
            <div className="flex items-center gap-1 font-mono font-black text-sm">
              <span className="bg-white/20 px-2 py-0.5 rounded-lg text-amber-200">
                {String(timeLeft.hours).padStart(2, '0')}
              </span>
              <span>:</span>
              <span className="bg-white/20 px-2 py-0.5 rounded-lg text-amber-200">
                {String(timeLeft.minutes).padStart(2, '0')}
              </span>
              <span>:</span>
              <span className="bg-white/20 px-2 py-0.5 rounded-lg text-amber-200">
                {String(timeLeft.seconds).padStart(2, '0')}
              </span>
            </div>
          </div>
        </div>

        {/* Products Rail */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3 sm:gap-4 pt-4">
          {saleProducts.slice(0, 4).map(({ product, flashPrice, flashStock, soldCount }) => {
            const percentClaimed = Math.min(100, Math.round((soldCount / (flashStock + soldCount)) * 100));

            return (
              <div
                key={product.id}
                onClick={() => setSelectedProduct(product)}
                className="bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 rounded-2xl p-3 flex flex-col justify-between shadow-lg hover:shadow-2xl transition-all cursor-pointer group border border-transparent dark:border-slate-800"
              >
                <div className="relative pt-[80%] bg-slate-50 dark:bg-slate-800/60 rounded-xl overflow-hidden mb-2.5">
                  <img
                    src={product.image}
                    alt={product.name}
                    className="absolute inset-0 w-full h-full object-contain p-2 group-hover:scale-105 transition-transform"
                    loading="lazy"
                  />
                  <span className="absolute top-1.5 left-1.5 bg-rose-600 text-white font-extrabold text-[10px] px-1.5 py-0.5 rounded shadow-xs">
                    FLASH SALE
                  </span>
                </div>

                <div className="space-y-1">
                  <h4 className="font-bold text-xs sm:text-sm text-slate-900 dark:text-slate-100 line-clamp-1 group-hover:text-rose-600 dark:group-hover:text-rose-400 transition-colors">
                    {product.name}
                  </h4>
                  <div className="flex items-baseline gap-1.5">
                    <span className="text-base sm:text-lg font-black text-rose-600 dark:text-rose-400">
                      ₹{flashPrice.toLocaleString('en-IN')}
                    </span>
                    <span className="text-xs text-slate-400 dark:text-slate-500 line-through">
                      ₹{product.originalPrice.toLocaleString('en-IN')}
                    </span>
                  </div>

                  {/* Stock sold progress bar */}
                  <div className="space-y-0.5 pt-1">
                    <div className="flex justify-between text-[10px] text-slate-500 dark:text-slate-400 font-semibold">
                      <span>Sold: {soldCount}</span>
                      <span className="text-rose-600 dark:text-rose-400 font-bold">{flashStock} left</span>
                    </div>
                    <div className="w-full bg-slate-100 dark:bg-slate-800 h-1.5 rounded-full overflow-hidden">
                      <div
                        className="bg-rose-600 h-full rounded-full transition-all duration-500"
                        style={{ width: `${percentClaimed}%` }}
                      />
                    </div>
                  </div>
                </div>

                <div className="pt-2.5 grid grid-cols-2 gap-1.5">
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      addToCart({ ...product, price: flashPrice }, 1);
                    }}
                    className="py-1.5 px-1.5 sm:px-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 text-[11px] sm:text-xs font-bold rounded-xl transition cursor-pointer flex items-center justify-center gap-1 w-full"
                    title="Add to Cart"
                  >
                    <span className="hidden sm:inline whitespace-nowrap leading-none">Add to Cart</span>
                    <span className="sm:hidden whitespace-nowrap leading-none">Add</span>
                  </button>
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      buyNow({ ...product, price: flashPrice }, 1);
                    }}
                    className="py-1.5 px-1.5 sm:px-2 bg-rose-600 hover:bg-rose-700 text-white text-[11px] sm:text-xs font-bold rounded-xl transition flex items-center justify-center gap-1 cursor-pointer shadow-xs w-full"
                    title="Buy Now"
                  >
                    <Zap className="w-3 h-3 fill-white shrink-0" />
                    <span className="hidden sm:inline whitespace-nowrap leading-none">Buy Now</span>
                    <span className="sm:hidden whitespace-nowrap leading-none">Buy</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
