import React, { useState, useEffect } from 'react';
import { X, Search, Package, Truck, CheckCircle2, Clock, AlertCircle, ShoppingBag, CreditCard, MapPin, Calendar, ExternalLink, Loader2 } from 'lucide-react';
import { useShop } from '../../context/ShopContext';

interface OrderTrackingModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialOrderId?: string;
}

export const OrderTrackingModal: React.FC<OrderTrackingModalProps> = ({
  isOpen,
  onClose,
  initialOrderId = '',
}) => {
  const { orders, isAdminAuthenticated, setIsAdminOpen } = useShop();
  const [searchId, setSearchId] = useState(initialOrderId);
  const [searchedOrder, setSearchedOrder] = useState<any>(null);
  const [hasSearched, setHasSearched] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  // Helper to extract Order ID from raw scan (supports plain ID, #ID, or scanned URL)
  const extractOrderId = (input: string): string => {
    let clean = (input || '').trim();
    if (!clean) return '';

    // If input is a scanned URL (e.g. from camera scanner: https://.../track?order=ORD-...)
    if (clean.includes('?') || clean.startsWith('http://') || clean.startsWith('https://')) {
      try {
        const url = new URL(clean.startsWith('http') ? clean : `https://dummy.com/${clean}`);
        const orderParam =
          url.searchParams.get('order') ||
          url.searchParams.get('orderId') ||
          url.searchParams.get('track') ||
          url.searchParams.get('order_id');
        if (orderParam) return orderParam.trim();
      } catch {
        const match = clean.match(/[?&](?:order|orderId|track|order_id)=([^&]+)/i);
        if (match && match[1]) return decodeURIComponent(match[1]).trim();
      }
    }

    // Strip leading hash symbol if present
    return clean.replace(/^#/, '').trim();
  };

  // Perform search in local state and directly query Supabase / backend API
  const executeSearch = async (rawQuery: string) => {
    const cleanId = extractOrderId(rawQuery);
    if (!cleanId) return;

    setSearchId(cleanId);
    setHasSearched(true);
    setIsLoading(true);

    const upper = cleanId.toUpperCase();

    // 1. Search in memory orders (from Supabase state)
    let found = orders.find(
      o => o.orderId?.toUpperCase() === upper || o.orderId?.toUpperCase().includes(upper)
    );

    // 2. If not found in memory, query server /api/orders/:id directly
    if (!found) {
      try {
        const res = await fetch(`/api/orders/${encodeURIComponent(cleanId)}`);
        const data = await res.json();
        if (data?.success && data?.order) {
          const o = data.order;
          found = {
            orderId: o.id || o.orderId,
            customerId: o.customerId,
            date: o.createdAt || o.date,
            customer: o.customer,
            items: o.items?.map((it: any) => ({
              product: it.product || {
                id: it.productId,
                name: it.name,
                price: it.price,
                image: it.image || '',
                stock: 10,
                category: 'electronics',
                originalPrice: it.price,
                discount: 0,
                description: '',
                shortDescription: '',
                features: [],
                rating: 4.8,
                reviewsCount: 100,
                brand: 'INFOSTORS',
              },
              quantity: it.quantity || 1,
            })) || [],
            subtotal: o.subtotal,
            deliveryCharge: o.shipping ?? o.deliveryCharge ?? 0,
            discountSavings: o.discount ?? o.discountSavings ?? 0,
            tax: o.tax,
            taxBreakdown: o.taxBreakdown,
            totalAmount: o.finalAmount || o.totalAmount,
            paymentMethod: o.paymentMethod,
            paymentStatus: o.paymentStatus,
            orderStatus: o.orderStatus,
            status: o.orderStatus === 'confirmed' ? 'received' : o.orderStatus === 'shipped' ? 'dispatched' : o.orderStatus || 'received',
            courierPartner: o.courierPartner,
            trackingId: o.trackingId,
            estimatedDeliveryDate: o.estimatedDeliveryDate,
            resolution: o.resolution,
          };
        }
      } catch (err) {
        console.warn('Direct order query error:', err);
      }
    }

    setSearchedOrder(found || null);
    setIsLoading(false);
  };

  // Automatically trigger search on mount or when initialOrderId changes
  useEffect(() => {
    if (isOpen && initialOrderId) {
      const clean = extractOrderId(initialOrderId);
      setSearchId(clean);
      executeSearch(clean);
    }
  }, [isOpen, initialOrderId, orders]);

  if (!isOpen) return null;

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    executeSearch(searchId);
  };

  const getStatusStep = (status: string) => {
    switch (status?.toLowerCase()) {
      case 'received':
      case 'confirmed':
      case 'processing':
        return 1;
      case 'dispatched':
      case 'shipped':
        return 2;
      case 'out_for_delivery':
        return 3;
      case 'delivered':
        return 4;
      default:
        return 1;
    }
  };

  const currentStep = searchedOrder ? getStatusStep(searchedOrder.status) : 1;

  // Format customer name responsibly for privacy (mask if viewing publicly)
  const getMaskedRecipient = (customer: any) => {
    if (!customer?.fullName) return 'Valued Customer';
    if (isAdminAuthenticated) return customer.fullName;
    const parts = customer.fullName.trim().split(' ');
    if (parts.length === 1) return parts[0];
    return `${parts[0]} ${parts[parts.length - 1][0]}.`;
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-150">
      <div className="bg-white dark:bg-slate-900 w-full max-w-lg rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col max-h-[92vh]">
        <div className="px-5 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Truck className="w-5 h-5 text-blue-600" />
            <h3 className="font-bold text-sm text-slate-900 dark:text-white">Order Details & Tracking</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
            title="Close"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-5 space-y-4 overflow-y-auto text-xs">
          <form onSubmit={handleSearch} className="flex gap-2">
            <input
              type="text"
              value={searchId}
              onChange={e => setSearchId(e.target.value)}
              placeholder="Enter or scan Order ID (e.g. ORD-2026-MUFH934-5591)..."
              className="flex-1 px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl outline-none focus:border-blue-500 font-mono text-xs uppercase"
              required
            />
            <button
              type="submit"
              disabled={isLoading}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer disabled:opacity-50"
            >
              {isLoading ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Search className="w-4 h-4" />
              )}
              <span>Track</span>
            </button>
          </form>

          {hasSearched && !isLoading && !searchedOrder && (
            <div className="p-4 bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800 rounded-xl text-center text-amber-800 dark:text-amber-300">
              <AlertCircle className="w-6 h-6 mx-auto mb-1 text-amber-600" />
              <p className="font-bold">No order found with ID "{searchId}"</p>
              <p className="text-[11px] mt-0.5">Please verify the Order ID printed on the Shipping Label or sent in SMS/Email.</p>
            </div>
          )}

          {searchedOrder && (
            <div className="space-y-4 border border-slate-200 dark:border-slate-800 rounded-xl p-4 bg-slate-50/50 dark:bg-slate-800/40">
              {/* Order Header */}
              <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-700 pb-3">
                <div>
                  <span className="text-[10px] text-slate-400 uppercase font-mono block">Order ID</span>
                  <p className="font-black text-slate-900 dark:text-white font-mono text-sm">
                    #{searchedOrder.orderId}
                  </p>
                  {searchedOrder.date && (
                    <span className="text-[10px] text-slate-500 flex items-center gap-1 mt-0.5">
                      <Calendar className="w-3 h-3" />
                      {new Date(searchedOrder.date).toLocaleDateString('en-IN', {
                        day: 'numeric',
                        month: 'short',
                        year: 'numeric',
                      })}
                    </span>
                  )}
                </div>
                <div className="text-right">
                  <span className="px-2.5 py-1 rounded-full text-[11px] font-bold uppercase bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200 inline-block">
                    {searchedOrder.status === 'received' ? 'Order Confirmed' : searchedOrder.status || 'Confirmed'}
                  </span>
                  {isAdminAuthenticated && (
                    <button
                      type="button"
                      onClick={() => {
                        onClose();
                        setIsAdminOpen(true);
                      }}
                      className="block text-[10px] font-bold text-blue-600 hover:underline mt-1 cursor-pointer"
                    >
                      Open in Admin Console →
                    </button>
                  )}
                </div>
              </div>

              {/* Progress Steps */}
              <div className="py-2">
                <div className="flex items-center justify-between relative">
                  <div className="absolute left-0 top-1/2 -translate-y-1/2 h-1 bg-slate-200 dark:bg-slate-700 w-full z-0" />
                  <div
                    className="absolute left-0 top-1/2 -translate-y-1/2 h-1 bg-blue-600 transition-all duration-300 z-0"
                    style={{ width: `${((currentStep - 1) / 3) * 100}%` }}
                  />

                  {['Confirmed', 'Dispatched', 'Out for Delivery', 'Delivered'].map((step, idx) => {
                    const stepNum = idx + 1;
                    const isPassed = stepNum <= currentStep;
                    return (
                      <div key={step} className="flex flex-col items-center relative z-10">
                        <div
                          className={`w-7 h-7 rounded-full flex items-center justify-center font-bold text-xs transition-colors ${
                            isPassed
                              ? 'bg-blue-600 text-white ring-4 ring-blue-100 dark:ring-blue-950'
                              : 'bg-slate-200 dark:bg-slate-700 text-slate-500'
                          }`}
                        >
                          {isPassed ? <CheckCircle2 className="w-4 h-4" /> : stepNum}
                        </div>
                        <span className="text-[9px] font-semibold text-slate-600 dark:text-slate-400 mt-1">
                          {step}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Logistics & Courier Details */}
              <div className="p-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl space-y-1.5">
                <div className="flex justify-between items-center text-[11px]">
                  <span className="text-slate-500 flex items-center gap-1">
                    <Truck className="w-3.5 h-3.5 text-blue-600" />
                    <span>Courier Partner:</span>
                  </span>
                  <span className="font-bold text-slate-800 dark:text-slate-200">
                    {searchedOrder.courierPartner || 'Delhivery Express'}
                  </span>
                </div>
                <div className="flex justify-between items-center text-[11px]">
                  <span className="text-slate-500">AWB Tracking ID:</span>
                  <span className="font-mono font-bold text-blue-600 dark:text-blue-400">
                    {searchedOrder.trackingId || `INF${(searchedOrder.orderId || '').replace(/\D/g, '') || '700084'}`}
                  </span>
                </div>
                <div className="flex justify-between items-center text-[11px] pt-1 border-t border-slate-100 dark:border-slate-800">
                  <span className="text-slate-500 flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Deliver To:</span>
                  </span>
                  <span className="font-semibold text-slate-700 dark:text-slate-300">
                    {getMaskedRecipient(searchedOrder.customer)} ({searchedOrder.customer?.city || 'Kolkata'}, {searchedOrder.customer?.pincode || '700084'})
                  </span>
                </div>
              </div>

              {/* Order Items List */}
              {searchedOrder.items && searchedOrder.items.length > 0 && (
                <div className="p-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl space-y-2">
                  <span className="text-[10px] uppercase font-bold text-slate-400 flex items-center gap-1">
                    <ShoppingBag className="w-3.5 h-3.5 text-slate-500" />
                    <span>Ordered Items ({searchedOrder.items.length})</span>
                  </span>
                  <div className="space-y-1.5 max-h-40 overflow-y-auto pr-1">
                    {searchedOrder.items.map((it: any, idx: number) => {
                      const itemName = it.product?.name || it.name || it.productId || 'Item';
                      const itemQty = it.quantity || 1;
                      const itemPrice = it.product?.price || it.price || 0;
                      return (
                        <div key={idx} className="flex justify-between items-center text-[11px] border-b border-slate-50 dark:border-slate-800 pb-1 last:border-0">
                          <span className="font-semibold text-slate-800 dark:text-slate-200 truncate max-w-[260px]">
                            {itemQty}x {itemName}
                          </span>
                          <span className="font-mono text-slate-600 dark:text-slate-400 shrink-0">
                            ₹{(itemPrice * itemQty).toLocaleString('en-IN')}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Payment Summary */}
              <div className="p-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl flex items-center justify-between text-xs">
                <div>
                  <span className="text-[10px] text-slate-400 uppercase font-mono block">Payment Mode</span>
                  <p className="font-bold text-slate-800 dark:text-slate-200 uppercase flex items-center gap-1">
                    <CreditCard className="w-3.5 h-3.5 text-blue-600" />
                    <span>{searchedOrder.paymentMethod === 'cod' ? 'Cash on Delivery (COD)' : 'Prepaid Online'}</span>
                  </p>
                </div>
                <div className="text-right">
                  <span className="text-[10px] text-slate-400 uppercase font-mono block">Order Total</span>
                  <p className="font-black text-sm text-slate-900 dark:text-white">
                    ₹{(searchedOrder.totalAmount || 0).toLocaleString('en-IN')}
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

