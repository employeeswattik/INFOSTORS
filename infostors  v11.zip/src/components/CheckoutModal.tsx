import React, { useState, useEffect } from 'react';
import { 
  X, 
  ShieldCheck, 
  Truck, 
  IndianRupee, 
  Smartphone, 
  Banknote, 
  ArrowLeft,
  CheckCircle2,
  AlertCircle,
  CreditCard,
  Zap,
  Lock,
  BadgeCheck,
  Building2,
  Wallet,
  RotateCcw,
  Tag
} from 'lucide-react';
import { useShop } from '../context/ShopContext';
import { CustomerDetails, Order } from '../types';
import { parseApiResponse } from '../utils/safeApi';

const INDIAN_STATES = [
  'Andhra Pradesh', 'Assam', 'Bihar', 'Delhi', 'Goa', 'Gujarat', 
  'Haryana', 'Karnataka', 'Kerala', 'Madhya Pradesh', 'Maharashtra', 
  'Punjab', 'Rajasthan', 'Tamil Nadu', 'Telangana', 'Uttar Pradesh', 'West Bengal'
];

type CheckoutPaymentOption = 'razorpay' | 'upi' | 'cod';

export const CheckoutModal: React.FC = () => {
  const {
    isCheckoutOpen,
    setIsCheckoutOpen,
    cart,
    activeCheckoutItems,
    activeCheckoutSubtotal,
    activeCheckoutDeliveryCharge,
    activeCheckoutSavings,
    activeCheckoutGrandTotal,
    activeCheckoutGstAmount,
    isBuyNowMode,
    cancelBuyNow,
    confirmOrderSuccess,
    customer: currentCustomer,
    customerToken,
    setIsAccountOpen,
    storeSettings,
    isGstActive,
    gstRate,
    gstType,
    deliveryLocation,
    featureFlags,
    appliedCoupon,
    couponDiscount,
    applyCoupon,
    removeCoupon,
    activeCoupons,
    walletBalance,
    useWalletBalance,
    setUseWalletBalance,
    walletDeduction,
    loyaltyBalance,
    redeemedLoyaltyDiscount,
    redeemLoyaltyPoints,
    clearLoyaltyRedemption,
  } = useShop();

  const [couponCodeInput, setCouponCodeInput] = useState('');
  const [couponFeedback, setCouponFeedback] = useState<{ text: string; isError: boolean } | null>(null);

  const handleApplyCoupon = async (codeToApply?: string) => {
    const code = (codeToApply || couponCodeInput).trim();
    if (!code) return;
    const res = await applyCoupon(code);
    if (res.success) {
      setCouponFeedback({ text: res.message || 'Coupon applied!', isError: false });
      setCouponCodeInput('');
    } else {
      setCouponFeedback({ text: res.error || 'Invalid coupon.', isError: true });
    }
    setTimeout(() => setCouponFeedback(null), 3500);
  };

  const [customer, setCustomer] = useState<CustomerDetails>({
    fullName: currentCustomer?.fullName || '',
    phone: currentCustomer?.mobile || '',
    email: currentCustomer?.email || '',
    address: currentCustomer?.address || '',
    city: currentCustomer?.city || deliveryLocation?.city || 'Kolkata',
    state: currentCustomer?.state || deliveryLocation?.state || 'West Bengal',
    pincode: currentCustomer?.pincode || deliveryLocation?.pincode || '700084',
  });

  const [showB2bInputs, setShowB2bInputs] = useState(false);
  const [b2bGstin, setB2bGstin] = useState('');
  const [b2bCompanyName, setB2bCompanyName] = useState('');

  // Sync customer details whenever currentCustomer updates without overwriting active edits
  useEffect(() => {
    if (currentCustomer) {
      setCustomer(prev => ({
        ...prev,
        fullName: prev.fullName || currentCustomer.fullName || '',
        phone: prev.phone || currentCustomer.mobile || '',
        email: prev.email || currentCustomer.email || '',
        address: prev.address || currentCustomer.address || '',
        city: prev.city || currentCustomer.city || deliveryLocation?.city || 'Kolkata',
        state: prev.state || currentCustomer.state || deliveryLocation?.state || 'West Bengal',
        pincode: prev.pincode || currentCustomer.pincode || deliveryLocation?.pincode || '700084',
      }));
    }
  }, [currentCustomer, deliveryLocation]);

  // Payment method: strictly razorpay, upi, or cod
  const [paymentMethod, setPaymentMethod] = useState<CheckoutPaymentOption>('razorpay');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submissionStep, setSubmissionStep] = useState<string>('');
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitError, setSubmitError] = useState<string | null>(null);

  if (!isCheckoutOpen) return null;

  const validate = () => {
    const errs: Record<string, string> = {};
    if (!customer.fullName.trim()) errs.fullName = 'Full name is required';
    if (!/^\d{10}$/.test(customer.phone.trim().replace(/\D/g, '').slice(-10))) {
      errs.phone = 'Enter a valid 10-digit Indian mobile number';
    }
    if (!customer.email.trim() || !customer.email.includes('@')) {
      errs.email = 'Valid email address is required';
    }
    if (!customer.address.trim()) errs.address = 'Complete delivery address is required';
    if (!customer.city.trim()) errs.city = 'City name is required';
    if (!/^\d{6}$/.test(customer.pincode.trim())) {
      errs.pincode = 'Valid 6-digit PIN code required';
    }
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmitOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isSubmitting) return;

    // Customer Authentication Requirement (Guest can browse and fill address, but must sign in before order confirmation)
    if (!customerToken && !currentCustomer) {
      setSubmitError('Customer login is required to confirm and place your order. Please sign in or register below.');
      setIsAccountOpen(true);
      return;
    }

    if (!validate()) return;
    if (activeCheckoutItems.length === 0) return;

    setIsSubmitting(true);
    setSubmitError(null);

    const cleanMobile = customer.phone.trim().replace(/\D/g, '').slice(-10);
    const sanitizedCustomer = {
      ...customer,
      phone: cleanMobile,
      fullName: customer.fullName.trim(),
      email: customer.email.trim(),
      address: customer.address.trim(),
      city: customer.city.trim(),
      state: customer.state.trim(),
      pincode: customer.pincode.trim(),
    };

    const checkoutPayload = activeCheckoutItems.map(item => ({
      productId: item.product.id,
      quantity: item.quantity,
      price: item.product.price,
      name: item.product.name,
      image: item.product.image,
    }));

    // ─────────────────────────────────────────────────────────────
    // FLOW 1: CASH ON DELIVERY (NO Razorpay checkout)
    // ─────────────────────────────────────────────────────────────
    if (paymentMethod === 'cod') {
      setSubmissionStep('Confirming Cash on Delivery Order...');
      try {
        const b2bPayload = (showB2bInputs && b2bGstin.trim()) ? {
          gstin: b2bGstin.trim().toUpperCase(),
          companyName: b2bCompanyName.trim() || sanitizedCustomer.fullName,
        } : undefined;

        const response = await fetch('/api/orders/cod', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            ...(customerToken ? { Authorization: `Bearer ${customerToken}` } : {}),
          },
          body: JSON.stringify({
            customer: sanitizedCustomer,
            items: checkoutPayload,
            b2bDetails: b2bPayload,
          }),
        });

        const { ok, data, errorMessage } = await parseApiResponse(response);
        if (!ok || !data || !data.success) {
          throw new Error(errorMessage || data?.error || 'Failed to place Cash on Delivery order.');
        }

        const serverOrder = data.order;
        const confirmedOrder: Order = {
          orderId: serverOrder.id,
          customerId: serverOrder.customerId,
          date: serverOrder.createdAt,
          customer: {
            fullName: serverOrder.customer.fullName,
            phone: serverOrder.customer.phone,
            email: serverOrder.customer.email,
            address: serverOrder.customer.address,
            city: serverOrder.customer.city,
            state: serverOrder.customer.state,
            pincode: serverOrder.customer.pincode,
          },
          items: [...activeCheckoutItems],
          subtotal: serverOrder.subtotal,
          deliveryCharge: serverOrder.shipping,
          discountSavings: serverOrder.discount || activeCheckoutSavings,
          tax: serverOrder.tax,
          taxBreakdown: serverOrder.taxBreakdown,
          b2bDetails: serverOrder.b2bDetails,
          totalAmount: serverOrder.finalAmount,
          paymentMethod: 'cod',
          paymentStatus: 'pending',
          orderStatus: 'confirmed',
          status: 'received',
          estimatedDeliveryDate: serverOrder.estimatedDeliveryDate || 'In 3-4 business days',
        };

        confirmOrderSuccess(confirmedOrder);
      } catch (err: any) {
        console.error('COD Order creation failed:', err);
        setSubmitError(err?.message || 'Failed to place Cash on Delivery order. Please try again.');
      } finally {
        setIsSubmitting(false);
        setSubmissionStep('');
      }
      return;
    }

    // ─────────────────────────────────────────────────────────────
    // FLOW 2: RAZORPAY / UPI (Official Razorpay Checkout SDK)
    // ─────────────────────────────────────────────────────────────
    setSubmissionStep('Preparing secure Razorpay checkout...');
    try {
      // Step 1: Create backend order & Razorpay order
      const b2bPayload = (showB2bInputs && b2bGstin.trim()) ? {
        gstin: b2bGstin.trim().toUpperCase(),
        companyName: b2bCompanyName.trim() || sanitizedCustomer.fullName,
      } : undefined;

      const createOrderRes = await fetch('/api/payments/razorpay/order', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(customerToken ? { Authorization: `Bearer ${customerToken}` } : {}),
        },
        body: JSON.stringify({
          customer: sanitizedCustomer,
          items: checkoutPayload,
          paymentMethod: paymentMethod,
          b2bDetails: b2bPayload,
        }),
      });

      const { ok: orderInitOk, data: orderInitData, errorMessage: orderInitError } = await parseApiResponse(createOrderRes);
      if (!orderInitOk || !orderInitData || !orderInitData.success) {
        throw new Error(orderInitError || orderInitData?.message || orderInitData?.error || 'Failed to initialize payment gateway.');
      }

      // Ensure Razorpay Checkout script is loaded
      if (typeof (window as any).Razorpay === 'undefined') {
        const loaded = await new Promise<boolean>((resolve) => {
          const script = document.createElement('script');
          script.src = 'https://checkout.razorpay.com/v1/checkout.js';
          script.async = true;
          script.onload = () => resolve(true);
          script.onerror = () => resolve(false);
          document.head.appendChild(script);
          setTimeout(() => resolve(typeof (window as any).Razorpay !== 'undefined'), 3500);
        });

        if (!loaded && typeof (window as any).Razorpay === 'undefined') {
          throw new Error('Razorpay secure checkout SDK could not be loaded. Please check your internet connection and try again.');
        }
      }

      setSubmissionStep('Opening Razorpay Payment window...');

      // Configure Razorpay options
      const options: any = {
        key: orderInitData.keyId,
        amount: orderInitData.amount, // in paise
        currency: orderInitData.currency || 'INR',
        name: 'INFOSTORS',
        description: `Order #${orderInitData.internalOrderId}`,
        order_id: orderInitData.razorpayOrderId,
        prefill: {
          name: sanitizedCustomer.fullName,
          email: sanitizedCustomer.email,
          contact: sanitizedCustomer.phone,
        },
        theme: {
          color: '#2563EB', // INFOSTORS Brand Blue
        },
        modal: {
          ondismiss: function () {
            console.log('Customer closed/cancelled Razorpay modal');
            // Notify server of cancellation (non-blocking)
            fetch('/api/payments/razorpay/failed', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                internal_order_id: orderInitData.internalOrderId,
                razorpay_order_id: orderInitData.razorpayOrderId,
                reason: 'Customer dismissed payment window',
              }),
            }).catch(() => {});

            setIsSubmitting(false);
            setSubmissionStep('');
            setSubmitError('Payment was not completed. Please try again.');
          },
        },
        handler: async function (response: any) {
          // Customer successfully authorized payment! Immediately verify signature on server.
          setSubmissionStep('Verifying 256-Bit cryptographic payment signature...');
          try {
            const verifyRes = await fetch('/api/payments/razorpay/verify', {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                ...(customerToken ? { Authorization: `Bearer ${customerToken}` } : {}),
              },
              body: JSON.stringify({
                razorpay_order_id: response.razorpay_order_id,
                razorpay_payment_id: response.razorpay_payment_id,
                razorpay_signature: response.razorpay_signature,
                internal_order_id: orderInitData.internalOrderId,
              }),
            });

            const { ok: verifyOk, data: verifyData, errorMessage: verifyError } = await parseApiResponse(verifyRes);
            if (!verifyOk || !verifyData || !verifyData.success) {
              throw new Error(verifyError || verifyData?.error || 'Payment signature verification failed.');
            }

            const verifiedServerOrder = verifyData.order;
            const confirmedOrder: Order = {
              orderId: verifiedServerOrder.id,
              customerId: verifiedServerOrder.customerId,
              date: verifiedServerOrder.createdAt,
              customer: {
                fullName: verifiedServerOrder.customer.fullName,
                phone: verifiedServerOrder.customer.phone,
                email: verifiedServerOrder.customer.email,
                address: verifiedServerOrder.customer.address,
                city: verifiedServerOrder.customer.city,
                state: verifiedServerOrder.customer.state,
                pincode: verifiedServerOrder.customer.pincode,
              },
              items: [...activeCheckoutItems],
              subtotal: verifiedServerOrder.subtotal,
              deliveryCharge: verifiedServerOrder.shipping,
              discountSavings: verifiedServerOrder.discount || activeCheckoutSavings,
              tax: verifiedServerOrder.tax,
              taxBreakdown: verifiedServerOrder.taxBreakdown,
              b2bDetails: verifiedServerOrder.b2bDetails,
              totalAmount: verifiedServerOrder.finalAmount,
              paymentMethod: paymentMethod === 'upi' ? 'upi' : 'razorpay',
              paymentStatus: 'paid',
              orderStatus: 'confirmed',
              razorpayOrderId: verifiedServerOrder.razorpayOrderId,
              razorpayPaymentId: verifiedServerOrder.razorpayPaymentId,
              status: 'received',
              estimatedDeliveryDate: verifiedServerOrder.estimatedDeliveryDate || 'In 3-4 business days',
            };

            confirmOrderSuccess(confirmedOrder);
          } catch (verifyErr: any) {
            console.error('Razorpay verification error:', verifyErr);
            setSubmitError(verifyErr?.message || 'Payment signature verification failed. If money was deducted, our team will verify and confirm your order.');
          } finally {
            setIsSubmitting(false);
            setSubmissionStep('');
          }
        },
      };

      // If user selected UPI specifically, emphasize UPI in Razorpay Checkout config
      if (paymentMethod === 'upi') {
        options.config = {
          display: {
            blocks: {
              upi: {
                name: "Pay via UPI",
                instruments: [
                  { method: "upi" }
                ],
              },
            },
            sequence: ["block.upi"],
            preferences: {
              show_default_blocks: true,
            },
          },
        };
      }

      const rzpInstance = new (window as any).Razorpay(options);

      rzpInstance.on('payment.failed', function (failureResponse: any) {
        console.error('Razorpay payment failed callback:', failureResponse.error);
        fetch('/api/payments/razorpay/failed', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            internal_order_id: orderInitData.internalOrderId,
            razorpay_order_id: orderInitData.razorpayOrderId,
            reason: failureResponse.error?.description || 'Payment failed',
          }),
        }).catch(() => {});

        setIsSubmitting(false);
        setSubmissionStep('');
        setSubmitError(failureResponse.error?.description || 'Payment was not completed. Please try again.');
      });

      rzpInstance.open();
    } catch (err: any) {
      console.error('Razorpay flow initiation error:', err);
      setIsSubmitting(false);
      setSubmissionStep('');
      const msg = err?.message || 'Unable to start payment gateway. Please try again.';
      if (msg.toLowerCase().includes('not yet configured') || msg.toLowerCase().includes('not configured')) {
        setSubmitError('SETUP REQUIRED: Online payment gateway is not yet configured. Please choose Cash on Delivery (COD) to complete your order.');
      } else {
        setSubmitError(msg);
      }
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 md:p-6 animate-in fade-in duration-200">
      <div 
        className="bg-white dark:bg-slate-900 w-full max-w-4xl rounded-xl sm:rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-100 overflow-hidden my-auto max-h-[92vh] flex flex-col transition-colors duration-200"
        id="checkout-modal-container"
      >
        {/* Header */}
        <div className="px-3.5 sm:px-5 py-3 sm:py-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between bg-slate-50/80 dark:bg-slate-800/80 shrink-0">
          <div className="flex items-center gap-2 sm:gap-3 min-w-0">
            <button
              onClick={() => {
                cancelBuyNow();
                setIsCheckoutOpen(false);
              }}
              className="p-1 text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200 rounded-lg cursor-pointer transition-colors shrink-0"
              title="Return to shopping"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <h2 className="font-bold text-base sm:text-lg text-slate-900 dark:text-slate-100 leading-tight truncate">Fast & Secure Checkout</h2>
                {isBuyNowMode && (
                  <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-900 dark:text-amber-300 font-extrabold text-[10px] tracking-wide border border-amber-500/30 shrink-0">
                    ⚡ BUY NOW
                  </span>
                )}
              </div>
              <p className="text-[10px] sm:text-[11px] text-slate-500 dark:text-slate-400 truncate">
                INFOSTORS Assured Delivery • 256-Bit SSL Encrypted
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              cancelBuyNow();
              setIsCheckoutOpen(false);
            }}
            className="p-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded-lg cursor-pointer transition-colors shrink-0"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Customer Login Alert if not signed in */}
        {!customerToken && !currentCustomer && (
          <div className="bg-amber-50 border-b border-amber-200 px-3.5 sm:px-5 py-2.5 flex items-center justify-between gap-2 text-xs text-amber-900 shrink-0">
            <div className="flex items-center gap-2 min-w-0">
              <Lock className="w-4 h-4 text-amber-600 shrink-0" />
              <span className="truncate font-medium">
                Customer login required to place order. Your items and address details are saved.
              </span>
            </div>
            <button
              type="button"
              onClick={() => setIsAccountOpen(true)}
              className="px-3 py-1 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-lg text-xs shrink-0 cursor-pointer shadow-xs transition-colors"
            >
              Sign In / Register
            </button>
          </div>
        )}

        {/* Form Body */}
        <form onSubmit={handleSubmitOrder} className="overflow-y-auto flex-1 p-3.5 sm:p-6">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 sm:gap-8">
            {/* Left: Customer Details & Payment Methods (7 cols) */}
            <div className="lg:col-span-7 space-y-6">
              {/* Delivery Address Section */}
              <div className="space-y-4">
                <div className="flex items-center justify-between pb-2 border-b border-slate-200">
                  <div className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded-full bg-blue-600 text-white font-bold text-xs flex items-center justify-center">
                      1
                    </span>
                    <h3 className="font-bold text-sm text-slate-900">Shipping & Contact Details</h3>
                  </div>
                  {currentCustomer && (
                    <span className="text-[10px] font-semibold text-blue-700 bg-blue-50 border border-blue-200 px-2 py-0.5 rounded-full flex items-center gap-1">
                      <BadgeCheck className="w-3 h-3 text-blue-600" />
                      Logged in as {currentCustomer.fullName.split(' ')[0]}
                    </span>
                  )}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                  <div className="sm:col-span-2">
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Full Name *
                    </label>
                    <input
                      type="text"
                      value={customer.fullName}
                      onChange={e => setCustomer({ ...customer, fullName: e.target.value })}
                      placeholder="e.g. Rahul Sharma"
                      className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 focus:bg-white focus:border-blue-500 rounded-xl outline-none transition-colors"
                      id="checkout-fullname-input"
                    />
                    {errors.fullName && <p className="text-[10px] text-rose-500 mt-0.5">{errors.fullName}</p>}
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Mobile Number (10 Digits) *
                    </label>
                    <div className="relative">
                      <span className="absolute left-3 top-2 text-xs font-bold text-slate-400">+91</span>
                      <input
                        type="tel"
                        maxLength={10}
                        value={customer.phone}
                        onChange={e => setCustomer({ ...customer, phone: e.target.value.replace(/\D/g, '') })}
                        placeholder="9876543210"
                        className="w-full pl-11 pr-3 py-2 text-xs bg-slate-50 border border-slate-300 focus:bg-white focus:border-blue-500 rounded-xl outline-none transition-colors"
                        id="checkout-phone-input"
                      />
                    </div>
                    {errors.phone && <p className="text-[10px] text-rose-500 mt-0.5">{errors.phone}</p>}
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Email Address *
                    </label>
                    <input
                      type="email"
                      value={customer.email}
                      onChange={e => setCustomer({ ...customer, email: e.target.value })}
                      placeholder="rahul@example.com"
                      className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 focus:bg-white focus:border-blue-500 rounded-xl outline-none transition-colors"
                      id="checkout-email-input"
                    />
                    {errors.email && <p className="text-[10px] text-rose-500 mt-0.5">{errors.email}</p>}
                  </div>

                  <div className="sm:col-span-2">
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Complete Delivery Address (House / Street / Area) *
                    </label>
                    <textarea
                      rows={2}
                      value={customer.address}
                      onChange={e => setCustomer({ ...customer, address: e.target.value })}
                      placeholder="e.g. Flat 4B, Greenwood Apartments, MG Road"
                      className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 focus:bg-white focus:border-blue-500 rounded-xl outline-none transition-colors resize-none"
                      id="checkout-address-input"
                    />
                    {errors.address && <p className="text-[10px] text-rose-500 mt-0.5">{errors.address}</p>}
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      City *
                    </label>
                    <input
                      type="text"
                      value={customer.city}
                      onChange={e => setCustomer({ ...customer, city: e.target.value })}
                      placeholder="e.g. Mumbai"
                      className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 focus:bg-white focus:border-blue-500 rounded-xl outline-none transition-colors"
                      id="checkout-city-input"
                    />
                    {errors.city && <p className="text-[10px] text-rose-500 mt-0.5">{errors.city}</p>}
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      State *
                    </label>
                    <select
                      value={customer.state}
                      onChange={e => setCustomer({ ...customer, state: e.target.value })}
                      className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 focus:bg-white focus:border-blue-500 rounded-xl outline-none transition-colors"
                      id="checkout-state-select"
                    >
                      {INDIAN_STATES.map(st => (
                        <option key={st} value={st}>{st}</option>
                      ))}
                    </select>
                  </div>

                  <div className="sm:col-span-2">
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      PIN Code (6 Digits) *
                    </label>
                    <input
                      type="text"
                      maxLength={6}
                      value={customer.pincode}
                      onChange={e => setCustomer({ ...customer, pincode: e.target.value.replace(/\D/g, '') })}
                      placeholder="e.g. 700001"
                      className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 focus:bg-white focus:border-blue-500 rounded-xl outline-none transition-colors"
                      id="checkout-pincode-input"
                    />
                    {errors.pincode && <p className="text-[10px] text-rose-500 mt-0.5">{errors.pincode}</p>}
                  </div>
                </div>
              </div>

              {/* Optional B2B GSTIN Section (Active when store enables B2B GST) */}
              {storeSettings?.gstEnabled && storeSettings?.allowCustomerB2bGst && (
                <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-2xl space-y-2.5">
                  <label className="flex items-center gap-2 cursor-pointer select-none text-xs font-semibold text-slate-800">
                    <input
                      type="checkbox"
                      checked={showB2bInputs}
                      onChange={e => setShowB2bInputs(e.target.checked)}
                      className="w-4 h-4 text-blue-600 rounded-md border-slate-300 focus:ring-blue-500 cursor-pointer"
                      id="b2b-gst-checkbox"
                    />
                    <span>Add Business GSTIN for Input Tax Credit (B2B Invoice)</span>
                  </label>

                  {showB2bInputs && (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1 animate-in fade-in">
                      <div>
                        <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                          Business GSTIN (15 Digits) *
                        </label>
                        <input
                          type="text"
                          maxLength={15}
                          value={b2bGstin}
                          onChange={e => setB2bGstin(e.target.value.toUpperCase().trim())}
                          placeholder="e.g. 19AAACI1234F1Z8"
                          className="w-full px-3 py-2 text-xs font-mono font-bold bg-white border border-slate-300 rounded-xl outline-none focus:border-blue-500 uppercase"
                          id="b2b-gstin-input"
                        />
                      </div>
                      <div>
                        <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                          Company / Business Name *
                        </label>
                        <input
                          type="text"
                          value={b2bCompanyName}
                          onChange={e => setB2bCompanyName(e.target.value)}
                          placeholder="e.g. Acme Enterprises"
                          className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-xl outline-none focus:border-blue-500"
                          id="b2b-company-input"
                        />
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Payment Methods Section (STRICTLY ONLY THREE: Razorpay, UPI, Cash on Delivery) */}
              <div className="space-y-3.5 pt-2">
                <div className="flex items-center justify-between pb-2 border-b border-slate-200">
                  <div className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded-full bg-blue-600 text-white font-bold text-xs flex items-center justify-center">
                      2
                    </span>
                    <h3 className="font-bold text-sm text-slate-900">Select Payment Method</h3>
                  </div>
                  <span className="text-[10px] text-emerald-700 font-semibold flex items-center gap-1">
                    <Lock className="w-3 h-3 text-emerald-600" />
                    100% Encrypted & Safe
                  </span>
                </div>

                <div className="space-y-3">
                  {/* OPTION 1: Razorpay (Cards, Netbanking, Wallets, Pay Later) */}
                  <div
                    onClick={() => setPaymentMethod('razorpay')}
                    className={`rounded-2xl border transition-all cursor-pointer overflow-hidden ${
                      paymentMethod === 'razorpay'
                        ? 'border-blue-600 bg-blue-50/30 shadow-md ring-2 ring-blue-500/20'
                        : 'border-slate-200 hover:border-slate-300 bg-white'
                    }`}
                    id="payment-option-razorpay"
                  >
                    <div className="p-3.5 sm:p-4 flex items-start gap-3">
                      <input
                        type="radio"
                        name="paymentMethod"
                        value="razorpay"
                        checked={paymentMethod === 'razorpay'}
                        onChange={() => setPaymentMethod('razorpay')}
                        className="mt-1 accent-blue-600 cursor-pointer"
                        id="radio-razorpay"
                      />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between gap-2 flex-wrap">
                          <span className="font-bold text-xs sm:text-sm text-slate-900 flex items-center gap-2">
                            <span className="w-7 h-7 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center border border-blue-200 shrink-0">
                              <CreditCard className="w-4 h-4" />
                            </span>
                            <span>Razorpay (Cards, Netbanking, Wallets)</span>
                          </span>
                          <span className="text-[10px] font-bold text-blue-700 bg-blue-100 border border-blue-200 px-2 py-0.5 rounded-full shrink-0">
                            OFFICIAL GATEWAY
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-600 mt-1">
                          Visa, Mastercard, RuPay, 50+ Banks Netbanking, Cred, and Wallets
                        </p>
                        
                        {paymentMethod === 'razorpay' && (
                          <div className="mt-3 pt-2.5 border-t border-blue-100 flex flex-wrap items-center gap-1.5 text-[10px] text-slate-500">
                            <span className="px-2 py-0.5 bg-white border border-slate-200 rounded font-medium">Debit & Credit Cards</span>
                            <span className="px-2 py-0.5 bg-white border border-slate-200 rounded font-medium">Netbanking</span>
                            <span className="px-2 py-0.5 bg-white border border-slate-200 rounded font-medium">Wallets</span>
                            <span className="px-2 py-0.5 bg-white border border-slate-200 rounded font-medium">EMI / Pay Later</span>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* OPTION 2: UPI (Google Pay, PhonePe, Paytm, BHIM via Razorpay Checkout) */}
                  <div
                    onClick={() => setPaymentMethod('upi')}
                    className={`rounded-2xl border transition-all cursor-pointer overflow-hidden ${
                      paymentMethod === 'upi'
                        ? 'border-blue-600 bg-blue-50/30 shadow-md ring-2 ring-blue-500/20'
                        : 'border-slate-200 hover:border-slate-300 bg-white'
                    }`}
                    id="payment-option-upi"
                  >
                    <div className="p-3.5 sm:p-4 flex items-start gap-3">
                      <input
                        type="radio"
                        name="paymentMethod"
                        value="upi"
                        checked={paymentMethod === 'upi'}
                        onChange={() => setPaymentMethod('upi')}
                        className="mt-1 accent-blue-600 cursor-pointer"
                        id="radio-upi"
                      />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between gap-2 flex-wrap">
                          <span className="font-bold text-xs sm:text-sm text-slate-900 flex items-center gap-2">
                            <span className="w-7 h-7 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center border border-emerald-200 shrink-0">
                              <Smartphone className="w-4 h-4" />
                            </span>
                            <span>UPI (Google Pay, PhonePe, Paytm, BHIM)</span>
                          </span>
                          <span className="text-[10px] font-extrabold text-emerald-800 bg-emerald-100 border border-emerald-300 px-2 py-0.5 rounded-full flex items-center gap-1 shrink-0">
                            <Zap className="w-3 h-3 fill-emerald-600 text-emerald-600" />
                            INSTANT
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-600 mt-1">
                          Fast UPI checkout with instant verification via official Razorpay popup
                        </p>

                        {paymentMethod === 'upi' && (
                          <div className="mt-3 pt-2.5 border-t border-blue-100 flex flex-wrap items-center gap-1.5 text-[10px] text-slate-500">
                            <span className="px-2 py-0.5 bg-white border border-slate-200 rounded font-bold text-slate-700">Google Pay</span>
                            <span className="px-2 py-0.5 bg-white border border-slate-200 rounded font-bold text-slate-700">PhonePe</span>
                            <span className="px-2 py-0.5 bg-white border border-slate-200 rounded font-bold text-slate-700">Paytm</span>
                            <span className="px-2 py-0.5 bg-white border border-slate-200 rounded font-bold text-slate-700">BHIM UPI</span>
                            <span className="px-2 py-0.5 bg-white border border-slate-200 rounded font-bold text-slate-700">Scan QR</span>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* OPTION 3: Cash on Delivery (Direct order confirmation, NO Razorpay checkout) */}
                  <div
                    onClick={() => setPaymentMethod('cod')}
                    className={`rounded-2xl border transition-all cursor-pointer overflow-hidden ${
                      paymentMethod === 'cod'
                        ? 'border-blue-600 bg-blue-50/30 shadow-md ring-2 ring-blue-500/20'
                        : 'border-slate-200 hover:border-slate-300 bg-white'
                    }`}
                    id="payment-option-cod"
                  >
                    <div className="p-3.5 sm:p-4 flex items-start gap-3">
                      <input
                        type="radio"
                        name="paymentMethod"
                        value="cod"
                        checked={paymentMethod === 'cod'}
                        onChange={() => setPaymentMethod('cod')}
                        className="mt-1 accent-blue-600 cursor-pointer"
                        id="radio-cod"
                      />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between gap-2 flex-wrap">
                          <span className="font-bold text-xs sm:text-sm text-slate-900 flex items-center gap-2">
                            <span className="w-7 h-7 rounded-lg bg-amber-100 text-amber-800 flex items-center justify-center border border-amber-200 shrink-0">
                              <Banknote className="w-4 h-4" />
                            </span>
                            <span>Cash on Delivery (COD)</span>
                          </span>
                          <span className="text-[10px] font-semibold text-slate-600 bg-slate-100 px-2 py-0.5 rounded-full shrink-0">
                            Pay at Doorstep
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-600 mt-1">
                          No advance payment required. Inspect parcel upon delivery and pay cash or UPI to courier.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Right: Order Summary (5 cols) */}
            <div className="lg:col-span-5 space-y-4">
              <div className="bg-slate-50 rounded-2xl border border-slate-200 p-4 space-y-4">
                <div className="pb-2 border-b border-slate-200">
                  <div className="flex items-center justify-between">
                    <h3 className="font-bold text-sm text-slate-900 flex items-center gap-1.5">
                      {isBuyNowMode && (
                        <span className="px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-900 font-extrabold text-[10px] border border-amber-500/30">
                          ⚡ BUY NOW
                        </span>
                      )}
                      <span>Order Summary</span>
                    </h3>
                    <span className="text-xs text-slate-500 font-normal">
                      {activeCheckoutItems.length} {activeCheckoutItems.length === 1 ? 'item' : 'items'}
                    </span>
                  </div>
                  {isBuyNowMode && (
                    <p className="text-[11px] text-amber-800 bg-amber-50/80 p-2 rounded-lg mt-2 border border-amber-200/60 leading-tight">
                      Instant single-item checkout. Any products previously added to your cart remain preserved!
                    </p>
                  )}
                </div>

                {/* Items preview list */}
                <div className="space-y-2.5 max-h-56 overflow-y-auto pr-1">
                  {activeCheckoutItems.map(item => (
                    <div key={item.product.id} className="flex gap-2.5 items-center text-xs">
                      <img
                        src={item.product.image}
                        alt=""
                        className="w-12 h-12 object-contain bg-white rounded-lg border border-slate-200 p-1 shrink-0"
                      />
                      <div className="flex-1 min-w-0">
                        <p className="font-semibold text-slate-900 truncate">{item.product.name}</p>
                        <p className="text-[11px] text-slate-500">Qty: {item.quantity}</p>
                      </div>
                      <span className="font-bold text-slate-800 shrink-0">
                        ₹{(item.product.price * item.quantity).toLocaleString('en-IN')}
                      </span>
                    </div>
                  ))}
                </div>

                {/* Coupon Code Section */}
                {featureFlags.coupons && (
                  <div className="pt-2 border-t border-slate-200 space-y-2">
                    {appliedCoupon ? (
                      <div className="flex items-center justify-between p-2.5 bg-emerald-50 border border-emerald-200 rounded-xl text-xs">
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-bold text-emerald-800">{appliedCoupon.code}</span>
                          <span className="text-emerald-700 font-semibold">(-₹{couponDiscount})</span>
                        </div>
                        <button
                          type="button"
                          onClick={removeCoupon}
                          className="text-xs text-rose-600 hover:text-rose-700 font-bold cursor-pointer"
                        >
                          Remove
                        </button>
                      </div>
                    ) : (
                      <div className="space-y-1.5">
                        <div className="flex gap-2">
                          <div className="relative flex-1">
                            <Tag className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                            <input
                              type="text"
                              value={couponCodeInput}
                              onChange={e => setCouponCodeInput(e.target.value.toUpperCase())}
                              placeholder="Enter coupon code"
                              className="w-full pl-8 pr-3 py-1.5 text-xs font-mono font-bold uppercase bg-white border border-slate-300 rounded-xl outline-none focus:border-blue-500"
                            />
                          </div>
                          <button
                            type="button"
                            onClick={() => handleApplyCoupon()}
                            disabled={!couponCodeInput.trim()}
                            className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-700 disabled:opacity-40 text-white text-xs font-bold rounded-xl transition cursor-pointer"
                          >
                            Apply
                          </button>
                        </div>
                        {couponFeedback && (
                          <p className={`text-[11px] font-semibold ${couponFeedback.isError ? 'text-rose-600' : 'text-emerald-600'}`}>
                            {couponFeedback.text}
                          </p>
                        )}
                      </div>
                    )}
                  </div>
                )}

                {/* Wallet & Loyalty Credits Section */}
                {(featureFlags.wallet || featureFlags.loyalty) && (
                  <div className="pt-2 border-t border-slate-200 space-y-2 text-xs">
                    {featureFlags.wallet && walletBalance > 0 && (
                      <label className="flex items-center justify-between p-2.5 bg-blue-50/60 border border-blue-200/80 rounded-xl cursor-pointer">
                        <div className="flex items-center gap-2">
                          <input
                            type="checkbox"
                            checked={useWalletBalance}
                            onChange={e => setUseWalletBalance(e.target.checked)}
                            className="w-4 h-4 rounded text-blue-600 focus:ring-blue-500 cursor-pointer"
                          />
                          <div>
                            <span className="font-bold text-slate-900">Use Store Wallet Balance</span>
                            <span className="text-[11px] text-blue-700 ml-1 font-semibold">(Available: ₹{walletBalance})</span>
                          </div>
                        </div>
                        {useWalletBalance && (
                          <span className="font-bold text-emerald-600">-₹{walletDeduction}</span>
                        )}
                      </label>
                    )}

                    {featureFlags.loyalty && loyaltyBalance >= 50 && (
                      <div className="p-2.5 bg-amber-50/60 border border-amber-200/80 rounded-xl flex items-center justify-between">
                        <div className="space-y-0.5">
                          <div className="font-bold text-slate-900">Reward Points: {loyaltyBalance} pts</div>
                          <div className="text-[10px] text-slate-500">1 point = ₹1 discount on gadgets</div>
                        </div>
                        {redeemedLoyaltyDiscount > 0 ? (
                          <button
                            type="button"
                            onClick={clearLoyaltyRedemption}
                            className="text-xs text-rose-600 font-bold hover:underline"
                          >
                            Cancel (-₹{redeemedLoyaltyDiscount})
                          </button>
                        ) : (
                          <button
                            type="button"
                            onClick={() => redeemLoyaltyPoints(50)}
                            className="px-2.5 py-1 bg-amber-600 hover:bg-amber-700 text-white font-bold rounded-lg text-[11px]"
                          >
                            Redeem 50 pts
                          </button>
                        )}
                      </div>
                    )}
                  </div>
                )}

                {/* Price Breakdown */}
                <div className="border-t border-slate-200 pt-3 space-y-1.5 text-xs text-slate-600">
                  <div className="flex justify-between">
                    <span>Items Subtotal</span>
                    <span className="font-semibold text-slate-900">₹{activeCheckoutSubtotal.toLocaleString('en-IN')}</span>
                  </div>

                  {activeCheckoutSavings > 0 && (
                    <div className="flex justify-between text-emerald-600 font-medium">
                      <span>Total Discount Savings</span>
                      <span>-₹{activeCheckoutSavings.toLocaleString('en-IN')}</span>
                    </div>
                  )}

                  {couponDiscount > 0 && (
                    <div className="flex justify-between text-emerald-600 font-bold">
                      <span>Coupon Discount ({appliedCoupon?.code})</span>
                      <span>-₹{couponDiscount.toLocaleString('en-IN')}</span>
                    </div>
                  )}

                  {redeemedLoyaltyDiscount > 0 && (
                    <div className="flex justify-between text-amber-600 font-bold">
                      <span>Reward Points Discount</span>
                      <span>-₹{redeemedLoyaltyDiscount.toLocaleString('en-IN')}</span>
                    </div>
                  )}

                  {walletDeduction > 0 && (
                    <div className="flex justify-between text-blue-600 font-bold">
                      <span>Store Wallet Credit Applied</span>
                      <span>-₹{walletDeduction.toLocaleString('en-IN')}</span>
                    </div>
                  )}

                  <div className="flex justify-between">
                    <span>Delivery Charge</span>
                    <span>
                      {activeCheckoutDeliveryCharge === 0 ? (
                        <span className="text-emerald-600 font-bold">
                          FREE {storeSettings?.enableFreeDeliveryThreshold && (storeSettings?.freeDeliveryMin ?? 0) > 0 ? `(Orders ₹${storeSettings.freeDeliveryMin}+)` : ''}
                        </span>
                      ) : (
                        `₹${activeCheckoutDeliveryCharge}`
                      )}
                    </span>
                  </div>

                  {/* GST Line Item when GST is active */}
                  {isGstActive && (
                    <div className="flex justify-between text-slate-700">
                      <span className="flex items-center gap-1">
                        <span>GST ({gstRate}%)</span>
                        <span className="text-[10px] text-slate-400">
                          ({gstType === 'exclusive' ? 'Added extra' : 'Included in MRP'})
                        </span>
                      </span>
                      <span className="font-semibold text-slate-900">
                        {gstType === 'exclusive' ? `+₹${activeCheckoutGstAmount.toLocaleString('en-IN')}` : `₹${activeCheckoutGstAmount.toLocaleString('en-IN')}`}
                      </span>
                    </div>
                  )}

                  {/* Store GSTIN Compliance Badge */}
                  {storeSettings?.gstEnabled && storeSettings?.showGstinOnInvoice && storeSettings?.gstin && (
                    <div className="text-[10px] text-slate-400 flex items-center justify-between pt-0.5">
                      <span>Seller GSTIN:</span>
                      <span className="font-mono font-bold text-slate-600">{storeSettings.gstin}</span>
                    </div>
                  )}

                  <div className="border-t border-slate-200 pt-2 flex justify-between items-baseline">
                    <span className="font-bold text-sm text-slate-900">Grand Total</span>
                    <span className="font-black text-xl text-blue-700">
                      ₹{activeCheckoutGrandTotal.toLocaleString('en-IN')}
                    </span>
                  </div>
                </div>

                {/* Error Banner if submission fails or payment canceled */}
                {submitError && (
                  <div 
                    className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-800 space-y-1 animate-in fade-in"
                    id="checkout-error-banner"
                  >
                    <div className="flex items-center gap-1.5 font-bold text-rose-700">
                      <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
                      <span>Notice</span>
                    </div>
                    <p className="text-[11px] text-rose-700 leading-normal">
                      {submitError}
                    </p>
                    <p className="text-[10px] text-slate-500 mt-1">
                      Your items remain securely saved. You can review your details and try again anytime.
                    </p>
                  </div>
                )}

                {/* Place Order Button */}
                <button
                  type="submit"
                  disabled={isSubmitting || activeCheckoutItems.length === 0}
                  className="w-full py-3.5 px-4 bg-blue-600 hover:bg-blue-700 active:bg-blue-800 disabled:opacity-50 disabled:cursor-not-allowed text-white font-extrabold text-sm rounded-xl shadow-lg shadow-blue-600/30 hover:shadow-blue-600/50 transition-all flex items-center justify-center gap-2 cursor-pointer"
                  id="checkout-place-order-button"
                >
                  {isSubmitting ? (
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                      <span className="text-xs">{submissionStep || 'Processing...'}</span>
                    </div>
                  ) : paymentMethod === 'razorpay' ? (
                    <span className="flex items-center gap-2">
                      <Lock className="w-4 h-4" />
                      <span>Pay ₹{activeCheckoutGrandTotal.toLocaleString('en-IN')} with Razorpay</span>
                    </span>
                  ) : paymentMethod === 'upi' ? (
                    <span className="flex items-center gap-2">
                      <Smartphone className="w-4 h-4" />
                      <span>Pay ₹{activeCheckoutGrandTotal.toLocaleString('en-IN')} with UPI</span>
                    </span>
                  ) : (
                    <span className="flex items-center gap-2">
                      <Truck className="w-4 h-4" />
                      <span>Confirm Cash on Delivery Order (₹{activeCheckoutGrandTotal.toLocaleString('en-IN')})</span>
                    </span>
                  )}
                </button>

                <div className="flex items-center justify-center gap-2 text-[10px] text-slate-500 text-center">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                  <span>100% Genuine Products • 7 Days Easy Return Policy</span>
                </div>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
