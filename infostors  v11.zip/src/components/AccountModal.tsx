import React, { useState, useEffect } from 'react';
import { 
  X, 
  User, 
  Package, 
  Lock, 
  Eye, 
  EyeOff, 
  Mail, 
  Phone, 
  Key, 
  CheckCircle2, 
  AlertCircle, 
  ArrowRight, 
  LogOut, 
  ShoppingBag, 
  ChevronRight, 
  ShieldCheck, 
  LayoutDashboard, 
  Truck, 
  Clock, 
  Sparkles,
  ArrowLeft,
  RotateCcw,
  MessageSquare,
  Tag,
  Wallet,
  Award,
  IndianRupee,
  Sun,
  Moon
} from 'lucide-react';
import { useShop } from '../context/ShopContext';

type AuthView = 'signin' | 'signup' | 'forgot-password' | 'reset-password';
type AuthenticatedTab = 'dashboard' | 'orders' | 'messages' | 'wallet' | 'loyalty' | 'returns' | 'profile';

export const AccountModal: React.FC = () => {
  const {
    isAccountOpen,
    setIsAccountOpen,
    customer,
    customerToken,
    isCustomerLoading,
    customerOrders,
    customerRegister,
    customerLogin,
    customerLogout,
    customerUpdateProfile,
    customerChangePassword,
    customerForgotPassword,
    customerResetPassword,
    resetTokenParam,
    setResetTokenParam,
    setActiveOrder,
    setIsOrderSuccessOpen,
    setIsAdminOpen,
    walletBalance,
    walletTransactions,
    loyaltyBalance,
    loyaltyTransactions,
    customerReturns,
    submitReturnRequest,
    themeMode,
    setThemeMode,
    storeSettings,
  } = useShop();

  // Navigation state
  const [authView, setAuthView] = useState<AuthView>('signin');
  const [activeTab, setActiveTab] = useState<AuthenticatedTab>('dashboard');
  const [customerMessages, setCustomerMessages] = useState<any[]>([]);
  const [isLoadingMessages, setIsLoadingMessages] = useState(false);

  // Fetch private customer messages on tab view
  useEffect(() => {
    if (customer && customerToken && activeTab === 'messages') {
      setIsLoadingMessages(true);
      fetch('/api/customer/messages', {
        headers: { Authorization: `Bearer ${customerToken}` },
      })
        .then(res => res.json())
        .then(data => {
          if (data.success && Array.isArray(data.messages)) {
            setCustomerMessages(data.messages);
          }
        })
        .catch(() => {})
        .finally(() => setIsLoadingMessages(false));
    }
  }, [customer, customerToken, activeTab]);

  // Form states - Sign In
  const [loginIdentifier, setLoginIdentifier] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [showLoginPassword, setShowLoginPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);

  // Form states - Sign Up
  const [signupFullName, setSignupFullName] = useState('');
  const [signupEmail, setSignupEmail] = useState('');
  const [signupMobile, setSignupMobile] = useState('');
  const [signupPassword, setSignupPassword] = useState('');
  const [signupConfirmPassword, setSignupConfirmPassword] = useState('');
  const [showSignupPassword, setShowSignupPassword] = useState(false);
  const [showSignupConfirmPassword, setShowSignupConfirmPassword] = useState(false);

  // Form states - Forgot & Reset Password
  const [forgotEmail, setForgotEmail] = useState('');
  const [forgotSuccessMsg, setForgotSuccessMsg] = useState('');
  const [previewResetLink, setPreviewResetLink] = useState<string | null>(null);

  const [resetToken, setResetToken] = useState('');
  const [resetNewPassword, setResetNewPassword] = useState('');
  const [resetConfirmPassword, setResetConfirmPassword] = useState('');

  // Return request states
  const [returnOrderId, setReturnOrderId] = useState('');
  const [returnReason, setReturnReason] = useState('Defective / Not Working');
  const [returnDescription, setReturnDescription] = useState('');
  const [isReturnModalOpen, setIsReturnModalOpen] = useState(false);
  const [returnSubmitting, setReturnSubmitting] = useState(false);
  const [returnStatusMsg, setReturnStatusMsg] = useState<string | null>(null);

  const handleStartReturn = (order: any) => {
    setReturnOrderId(order.orderId);
    setReturnReason('Defective / Not Working');
    setReturnDescription('');
    setIsReturnModalOpen(true);
  };

  const handleSubmitReturn = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!returnOrderId) return;
    const order = customerOrders.find(o => o.orderId === returnOrderId);
    const items = order ? order.items.map(i => ({
      productId: i.product.id,
      name: i.product.name,
      quantity: i.quantity,
      price: i.product.price,
    })) : [];

    setReturnSubmitting(true);
    const res = await submitReturnRequest(returnOrderId, items, returnReason, returnDescription);
    setReturnSubmitting(false);

    if (res.success) {
      setReturnStatusMsg(`Return request for Order #${returnOrderId} submitted successfully.`);
      setIsReturnModalOpen(false);
      setActiveTab('returns');
      setTimeout(() => setReturnStatusMsg(null), 4000);
    }
  };
  const [showResetNewPassword, setShowResetNewPassword] = useState(false);

  // Form states - Profile Update
  const [profileName, setProfileName] = useState('');
  const [profileEmail, setProfileEmail] = useState('');
  const [profileMobile, setProfileMobile] = useState('');

  // Form states - Change Password
  const [currentPassword, setCurrentPassword] = useState('');
  const [changeNewPassword, setChangeNewPassword] = useState('');
  const [changeConfirmPassword, setChangeConfirmPassword] = useState('');
  const [showChangeCurrentPassword, setShowChangeCurrentPassword] = useState(false);
  const [showChangeNewPassword, setShowChangeNewPassword] = useState(false);

  // Status alerts
  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  // Synchronize profile inputs when customer changes
  useEffect(() => {
    if (customer) {
      setProfileName(customer.fullName || '');
      setProfileEmail(customer.email || '');
      setProfileMobile(customer.mobile || '');
    }
  }, [customer]);

  // Handle URL reset token parameter if present
  useEffect(() => {
    if (resetTokenParam) {
      setResetToken(resetTokenParam);
      setAuthView('reset-password');
    }
  }, [resetTokenParam]);

  if (!isAccountOpen) return null;

  const clearAlerts = () => {
    setErrorMessage('');
    setSuccessMessage('');
  };

  const handleSwitchAuthView = (view: AuthView) => {
    clearAlerts();
    setAuthView(view);
  };

  // 1. Customer Sign In
  const handleSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    clearAlerts();

    if (!loginIdentifier.trim() || !loginPassword) {
      setErrorMessage('Please enter your email/mobile and password.');
      return;
    }

    const res = await customerLogin(loginIdentifier, loginPassword);
    if (!res.success) {
      setErrorMessage(res.error || 'Invalid email/mobile number or password.');
    } else {
      setSuccessMessage(res.message || 'Signed in successfully.');
      setActiveTab('dashboard');
    }
  };

  // 2. Customer Sign Up
  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    clearAlerts();

    if (
      !signupFullName.trim() ||
      !signupEmail.trim() ||
      !signupMobile.trim() ||
      !signupPassword ||
      !signupConfirmPassword
    ) {
      setErrorMessage('All fields are required.');
      return;
    }

    if (signupFullName.trim().length < 2) {
      setErrorMessage('Please enter your full name (at least 2 characters).');
      return;
    }

    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(signupEmail.trim())) {
      setErrorMessage('Please enter a valid email address.');
      return;
    }

    // Indian mobile number validation (10 digits starting with 6-9)
    const cleanedMobile = signupMobile.replace(/\D/g, '').slice(-10);
    if (!/^[6-9]\d{9}$/.test(cleanedMobile)) {
      setErrorMessage('Please enter a valid 10-digit Indian mobile number (starting with 6, 7, 8, or 9).');
      return;
    }

    if (signupPassword.length < 6) {
      setErrorMessage('Password must be at least 6 characters long.');
      return;
    }

    if (signupPassword !== signupConfirmPassword) {
      setErrorMessage('Passwords do not match.');
      return;
    }

    const res = await customerRegister(
      signupFullName,
      signupEmail,
      cleanedMobile,
      signupPassword,
      signupConfirmPassword
    );

    if (!res.success) {
      setErrorMessage(res.error || 'Failed to create account.');
    } else {
      setSuccessMessage(res.message || 'Account created successfully!');
      setActiveTab('dashboard');
    }
  };

  // 3. Customer Forgot Password
  const handleForgotPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    clearAlerts();

    if (!forgotEmail.trim()) {
      setErrorMessage('Please enter your registered email address.');
      return;
    }

    const res = await customerForgotPassword(forgotEmail.trim());
    if (res.success) {
      setForgotSuccessMsg(res.message || 'If an account exists with this email, a password reset link has been sent.');
      if (res.previewLink) {
        setPreviewResetLink(res.previewLink);
      }
    } else {
      setErrorMessage(res.error || 'Failed to process request.');
    }
  };

  // 4. Customer Reset Password
  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    clearAlerts();

    if (!resetToken.trim()) {
      setErrorMessage('Password reset token is missing or invalid.');
      return;
    }

    if (resetNewPassword.length < 6) {
      setErrorMessage('New password must be at least 6 characters long.');
      return;
    }

    if (resetNewPassword !== resetConfirmPassword) {
      setErrorMessage('Passwords do not match.');
      return;
    }

    const res = await customerResetPassword(resetToken.trim(), resetNewPassword, resetConfirmPassword);
    if (!res.success) {
      setErrorMessage(res.error || 'Failed to update password.');
    } else {
      setSuccessMessage('Your password has been updated successfully! Please sign in with your new password.');
      setResetToken('');
      setResetTokenParam(null);
      setResetNewPassword('');
      setResetConfirmPassword('');
      setTimeout(() => {
        setAuthView('signin');
      }, 1500);
    }
  };

  // 5. Update Profile
  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    clearAlerts();

    if (!profileName.trim() || !profileEmail.trim() || !profileMobile.trim()) {
      setErrorMessage('All profile fields are required.');
      return;
    }

    const res = await customerUpdateProfile(profileName, profileEmail, profileMobile);
    if (!res.success) {
      setErrorMessage(res.error || 'Failed to update profile.');
    } else {
      setSuccessMessage(res.message || 'Profile updated successfully.');
      setTimeout(() => setSuccessMessage(''), 3000);
    }
  };

  // 6. Change Password
  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    clearAlerts();

    if (!currentPassword || !changeNewPassword || !changeConfirmPassword) {
      setErrorMessage('Please fill in all password fields.');
      return;
    }

    if (changeNewPassword.length < 6) {
      setErrorMessage('New password must be at least 6 characters long.');
      return;
    }

    if (changeNewPassword !== changeConfirmPassword) {
      setErrorMessage('New password confirmation does not match.');
      return;
    }

    const res = await customerChangePassword(currentPassword, changeNewPassword, changeConfirmPassword);
    if (!res.success) {
      setErrorMessage(res.error || 'Failed to update password.');
    } else {
      setSuccessMessage(res.message || 'Your password has been updated successfully.');
      setCurrentPassword('');
      setChangeNewPassword('');
      setChangeConfirmPassword('');
      setTimeout(() => setSuccessMessage(''), 4000);
    }
  };

  // Order counts for dashboard
  const totalOrdersCount = customerOrders.length;
  const receivedOrdersCount = customerOrders.filter(o => o.status === 'received').length;
  const dispatchedOrdersCount = customerOrders.filter(o => o.status === 'dispatched').length;
  const deliveredOrdersCount = customerOrders.filter(o => o.status === 'delivered').length;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 md:p-6 animate-in fade-in duration-200">
      <div 
        className="bg-white dark:bg-slate-900 w-full max-w-2xl rounded-xl sm:rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-100 overflow-hidden my-auto max-h-[92vh] flex flex-col transition-colors duration-200"
        id="customer-account-modal"
      >
        {/* Top Header */}
        <div className="px-3.5 sm:px-6 py-3 sm:py-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between bg-slate-50 dark:bg-slate-800/80 shrink-0">
          <div className="flex items-center gap-2 sm:gap-3 min-w-0">
            {customer ? (
              <>
                <div className="w-10 h-10 rounded-full bg-blue-600 text-white font-black text-base flex items-center justify-center shadow-xs">
                  {customer.fullName.charAt(0).toUpperCase()}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="font-bold text-base text-slate-900 dark:text-slate-100">{customer.fullName}</h2>
                    <span className="px-2 py-0.5 text-[10px] font-bold bg-blue-100 text-blue-800 rounded-full">
                      Customer
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 dark:text-slate-400">{customer.email} • +91 {customer.mobile}</p>
                </div>
              </>
            ) : (
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-2xl bg-blue-50 dark:bg-blue-950/60 border border-blue-100 dark:border-blue-900 text-blue-600 dark:text-blue-400 flex items-center justify-center">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="font-bold text-base text-slate-900 dark:text-slate-100">
                    {authView === 'signin' && 'Customer Sign In'}
                    {authView === 'signup' && 'Create Customer Account'}
                    {authView === 'forgot-password' && 'Reset Password'}
                    {authView === 'reset-password' && 'Set New Password'}
                  </h2>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    {authView === 'signin' && 'Sign in to view your orders, address & profile'}
                    {authView === 'signup' && 'Join INFOSTORS for instant tracking & easy shopping'}
                    {authView === 'forgot-password' && 'Enter your email to receive a secure reset link'}
                    {authView === 'reset-password' && 'Enter your secure new account password'}
                  </p>
                </div>
              </div>
            )}
          </div>

          <div className="flex items-center gap-2 sm:gap-3">
            {/* Theme Mode Switcher in Account Header */}
            <div className="flex items-center bg-slate-100 dark:bg-slate-800 rounded-xl p-0.5 border border-slate-200 dark:border-slate-700">
              <button
                type="button"
                onClick={() => setThemeMode('light')}
                className={`p-1.5 px-2 rounded-lg text-xs font-bold transition-all flex items-center gap-1 cursor-pointer ${
                  themeMode === 'light'
                    ? 'bg-white text-slate-900 shadow-2xs'
                    : 'text-slate-500 hover:text-slate-900 dark:hover:text-slate-200'
                }`}
                title="Switch to Light Theme"
                id="btn-account-theme-light"
              >
                <Sun className="w-3.5 h-3.5 text-amber-500" />
                <span className="hidden xs:inline text-[11px]">Light</span>
              </button>
              <button
                type="button"
                onClick={() => setThemeMode('dark')}
                className={`p-1.5 px-2 rounded-lg text-xs font-bold transition-all flex items-center gap-1 cursor-pointer ${
                  themeMode === 'dark'
                    ? 'bg-slate-900 text-white shadow-2xs'
                    : 'text-slate-500 hover:text-slate-900 dark:hover:text-slate-200'
                }`}
                title="Switch to Dark Theme"
                id="btn-account-theme-dark"
              >
                <Moon className="w-3.5 h-3.5 text-indigo-400" />
                <span className="hidden xs:inline text-[11px]">Dark</span>
              </button>
            </div>

            {customer && (
              <button
                onClick={customerLogout}
                className="px-3 py-1.5 text-xs font-semibold text-rose-600 hover:text-rose-700 hover:bg-rose-50 dark:hover:bg-rose-950/30 rounded-xl flex items-center gap-1.5 cursor-pointer transition-colors"
                title="Log Out"
                id="btn-customer-logout"
              >
                <LogOut className="w-4 h-4" />
                <span className="hidden sm:inline">Logout</span>
              </button>
            )}
            <button
              onClick={() => setIsAccountOpen(false)}
              className="p-2 text-slate-400 hover:text-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl cursor-pointer transition-colors"
              id="btn-close-account-modal"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Global Notifications */}
        {errorMessage && (
          <div className="mx-6 mt-4 p-3.5 bg-rose-50 border border-rose-200 text-rose-800 text-xs rounded-xl flex items-center gap-2.5 animate-in fade-in">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
            <span className="font-medium">{errorMessage}</span>
          </div>
        )}

        {successMessage && (
          <div className="mx-6 mt-4 p-3.5 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs rounded-xl flex items-center gap-2.5 animate-in fade-in">
            <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />
            <span className="font-medium">{successMessage}</span>
          </div>
        )}

        {/* LOGGED IN VIEW: Dashboard, My Orders, Profile */}
        {customer ? (
          <>
            {/* Tabs Bar */}
            <div className="flex border-b border-slate-200 dark:border-slate-800 px-4 sm:px-6 bg-white dark:bg-slate-900 gap-4 sm:gap-6 text-xs font-bold overflow-x-auto no-scrollbar touch-pan-x overscroll-x-contain shrink-0">
              <button
                onClick={() => setActiveTab('dashboard')}
                className={`py-3.5 border-b-2 flex items-center gap-2 cursor-pointer transition-colors ${
                  activeTab === 'dashboard'
                    ? 'border-blue-600 text-blue-600'
                    : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
                id="tab-customer-dashboard"
              >
                <LayoutDashboard className="w-4 h-4" />
                <span>Dashboard</span>
              </button>

              <button
                onClick={() => setActiveTab('orders')}
                className={`py-3.5 border-b-2 flex items-center gap-2 cursor-pointer transition-colors ${
                  activeTab === 'orders'
                    ? 'border-blue-600 text-blue-600'
                    : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
                id="tab-customer-orders"
              >
                <Package className="w-4 h-4" />
                <span>My Orders ({customerOrders.length})</span>
              </button>

              <button
                onClick={() => setActiveTab('messages')}
                className={`py-3.5 border-b-2 flex items-center gap-2 cursor-pointer transition-colors ${
                  activeTab === 'messages'
                    ? 'border-blue-600 text-blue-600'
                    : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
                id="tab-customer-messages"
              >
                <MessageSquare className="w-4 h-4" />
                <span>Offers & Messages</span>
                {customerMessages.length > 0 && (
                  <span className="bg-blue-100 text-blue-800 text-[10px] font-extrabold px-1.5 py-0.2 rounded-full">
                    {customerMessages.length}
                  </span>
                )}
              </button>

              <button
                onClick={() => setActiveTab('wallet')}
                className={`py-3.5 border-b-2 flex items-center gap-1.5 cursor-pointer transition-colors whitespace-nowrap ${
                  activeTab === 'wallet'
                    ? 'border-blue-600 text-blue-600'
                    : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
                id="tab-customer-wallet"
              >
                <Wallet className="w-4 h-4" />
                <span>Wallet (₹{walletBalance})</span>
              </button>

              <button
                onClick={() => setActiveTab('loyalty')}
                className={`py-3.5 border-b-2 flex items-center gap-1.5 cursor-pointer transition-colors whitespace-nowrap ${
                  activeTab === 'loyalty'
                    ? 'border-blue-600 text-blue-600'
                    : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
                id="tab-customer-loyalty"
              >
                <Award className="w-4 h-4 text-amber-500" />
                <span>Rewards ({loyaltyBalance} pts)</span>
              </button>

              <button
                onClick={() => setActiveTab('returns')}
                className={`py-3.5 border-b-2 flex items-center gap-1.5 cursor-pointer transition-colors whitespace-nowrap ${
                  activeTab === 'returns'
                    ? 'border-blue-600 text-blue-600'
                    : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
                id="tab-customer-returns"
              >
                <RotateCcw className="w-4 h-4" />
                <span>Returns ({customerReturns.length})</span>
              </button>

              <button
                onClick={() => setActiveTab('profile')}
                className={`py-3.5 border-b-2 flex items-center gap-2 cursor-pointer transition-colors whitespace-nowrap ${
                  activeTab === 'profile'
                    ? 'border-blue-600 text-blue-600'
                    : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
                id="tab-customer-profile"
              >
                <User className="w-4 h-4" />
                <span>Profile & Security</span>
              </button>
            </div>

            {/* Tab Body */}
            <div className="overflow-y-auto p-6 flex-1 space-y-5">
              {/* TAB 1: DASHBOARD */}
              {activeTab === 'dashboard' && (
                <div className="space-y-6">
                  {/* Greeting Box */}
                  <div className="bg-gradient-to-r from-blue-900 to-indigo-900 text-white rounded-2xl p-5 shadow-sm relative overflow-hidden">
                    <div className="relative z-10 space-y-1.5">
                      <div className="flex items-center gap-2 text-blue-200 text-xs font-semibold">
                        <Sparkles className="w-4 h-4 text-amber-400" />
                        <span>Welcome back</span>
                      </div>
                      <h3 className="text-xl font-bold tracking-tight">{customer.fullName}</h3>
                      <p className="text-xs text-blue-200 max-w-md">
                        Manage your orders, personal delivery information, and password security all in one place.
                      </p>
                    </div>
                  </div>

                  {/* Summary Metric Cards */}
                  <div>
                    <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">
                      Order Overview
                    </h4>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                      <div className="bg-slate-50 border border-slate-200 rounded-2xl p-3.5">
                        <span className="text-[11px] font-semibold text-slate-500 block">Total Orders</span>
                        <span className="text-2xl font-black text-slate-900 mt-1 block">
                          {totalOrdersCount}
                        </span>
                      </div>

                      <div className="bg-blue-50/60 border border-blue-100 rounded-2xl p-3.5">
                        <span className="text-[11px] font-semibold text-blue-700 block">Received</span>
                        <span className="text-2xl font-black text-blue-900 mt-1 block">
                          {receivedOrdersCount}
                        </span>
                      </div>

                      <div className="bg-amber-50/60 border border-amber-100 rounded-2xl p-3.5">
                        <span className="text-[11px] font-semibold text-amber-700 block">Dispatched</span>
                        <span className="text-2xl font-black text-amber-900 mt-1 block">
                          {dispatchedOrdersCount}
                        </span>
                      </div>

                      <div className="bg-emerald-50/60 border border-emerald-100 rounded-2xl p-3.5">
                        <span className="text-[11px] font-semibold text-emerald-700 block">Delivered</span>
                        <span className="text-2xl font-black text-emerald-900 mt-1 block">
                          {deliveredOrdersCount}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Quick Action Buttons */}
                  <div className="grid sm:grid-cols-2 gap-3 pt-1">
                    <button
                      onClick={() => setActiveTab('orders')}
                      className="p-4 rounded-2xl border border-slate-200 hover:border-blue-500 bg-white hover:bg-blue-50/30 transition-all flex items-center justify-between group cursor-pointer text-left"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center">
                          <Package className="w-5 h-5" />
                        </div>
                        <div>
                          <p className="font-bold text-xs text-slate-900">View My Orders</p>
                          <p className="text-[11px] text-slate-500">Track shipments and live progress</p>
                        </div>
                      </div>
                      <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-blue-600 transition-colors" />
                    </button>

                    <button
                      onClick={() => setActiveTab('profile')}
                      className="p-4 rounded-2xl border border-slate-200 hover:border-blue-500 bg-white hover:bg-blue-50/30 transition-all flex items-center justify-between group cursor-pointer text-left"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-xl bg-slate-100 text-slate-700 flex items-center justify-center">
                          <User className="w-5 h-5" />
                        </div>
                        <div>
                          <p className="font-bold text-xs text-slate-900">Edit Profile & Password</p>
                          <p className="text-[11px] text-slate-500">Update name, phone, and password</p>
                        </div>
                      </div>
                      <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-blue-600 transition-colors" />
                    </button>
                  </div>
                </div>
              )}

              {/* TAB 2: MY ORDERS (Strictly customer's own orders) */}
              {activeTab === 'orders' && (
                <div className="space-y-4">
                  {customerOrders.length === 0 ? (
                    <div className="text-center py-16 space-y-3">
                      <div className="w-16 h-16 rounded-full bg-slate-100 flex items-center justify-center mx-auto text-slate-400">
                        <ShoppingBag className="w-8 h-8" />
                      </div>
                      <h3 className="font-bold text-slate-800 text-sm">No orders found</h3>
                      <p className="text-xs text-slate-500 max-w-xs mx-auto">
                        You have not placed any orders yet with your account. Any orders you place will appear here with live shipment tracking.
                      </p>
                      <button
                        onClick={() => setIsAccountOpen(false)}
                        className="px-5 py-2.5 bg-blue-600 text-white font-bold text-xs rounded-xl hover:bg-blue-700 cursor-pointer shadow-xs transition-colors"
                      >
                        Start Shopping
                      </button>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {customerOrders.map(order => (
                        <div
                          key={order.orderId}
                          className="border border-slate-200 rounded-2xl p-4 bg-slate-50/50 hover:bg-white transition-all space-y-3.5"
                        >
                          {/* Order Header */}
                          <div className="flex flex-wrap items-center justify-between gap-2 pb-2.5 border-b border-slate-200/80 text-xs">
                            <div className="flex items-center gap-2">
                              <span className="font-black text-slate-900">#{order.orderId}</span>
                              <span className="text-slate-400">•</span>
                              <span className="text-slate-500">
                                {new Date(order.date).toLocaleDateString('en-IN', {
                                  day: 'numeric',
                                  month: 'short',
                                  year: 'numeric',
                                })}
                              </span>
                              <span className="text-slate-400">•</span>
                              <span className="uppercase text-[10px] font-bold px-2 py-0.5 rounded bg-slate-200 text-slate-700">
                                {order.paymentMethod === 'cod' ? '💵 Cash on Delivery' : '💳 Instant UPI'}
                              </span>
                            </div>

                            <div className="flex items-center gap-2">
                              <span className={`font-bold px-2.5 py-0.5 rounded-full text-[11px] flex items-center gap-1 ${
                                order.status === 'delivered' 
                                  ? 'bg-emerald-100 text-emerald-800' 
                                  : order.status === 'dispatched'
                                  ? 'bg-amber-100 text-amber-800'
                                  : 'bg-blue-100 text-blue-800'
                              }`}>
                                <CheckCircle2 className="w-3 h-3" />
                                <span className="capitalize">
                                  {order.status === 'received' ? 'Order Received' : order.status === 'dispatched' ? 'Dispatched' : 'Delivered'}
                                </span>
                              </span>

                              <button
                                onClick={() => {
                                  setActiveOrder(order);
                                  setIsAccountOpen(false);
                                  setIsOrderSuccessOpen(true);
                                }}
                                className="text-blue-600 hover:text-blue-800 font-bold text-xs flex items-center gap-0.5 cursor-pointer ml-1"
                              >
                                <span>Track & Receipt</span>
                                <ChevronRight className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>

                          {/* 3-Step Live Shipment Tracker */}
                          <div className="bg-white rounded-xl p-3 border border-slate-200/80">
                            <div className="flex items-center justify-between text-[11px] relative">
                              {/* Step 1: Received */}
                              <div className={`flex items-center gap-1.5 font-bold ${
                                order.status === 'received' || order.status === 'dispatched' || order.status === 'delivered'
                                  ? 'text-blue-700'
                                  : 'text-slate-400'
                              }`}>
                                <div className="w-2.5 h-2.5 rounded-full bg-blue-600 ring-4 ring-blue-100" />
                                <span>Order Received</span>
                              </div>

                              {/* Connector 1 */}
                              <div className={`h-0.5 flex-1 mx-2 transition-colors ${
                                order.status === 'dispatched' || order.status === 'delivered' ? 'bg-blue-600' : 'bg-slate-200'
                              }`} />

                              {/* Step 2: Dispatched */}
                              <div className={`flex items-center gap-1.5 font-bold ${
                                order.status === 'dispatched' || order.status === 'delivered'
                                  ? 'text-amber-700'
                                  : 'text-slate-400'
                              }`}>
                                <div className={`w-2.5 h-2.5 rounded-full ${
                                  order.status === 'dispatched' || order.status === 'delivered'
                                    ? 'bg-amber-600 ring-4 ring-amber-100'
                                    : 'bg-slate-300'
                                }`} />
                                <span>Dispatched</span>
                              </div>

                              {/* Connector 2 */}
                              <div className={`h-0.5 flex-1 mx-2 transition-colors ${
                                order.status === 'delivered' ? 'bg-emerald-600' : 'bg-slate-200'
                              }`} />

                              {/* Step 3: Delivered */}
                              <div className={`flex items-center gap-1.5 font-bold ${
                                order.status === 'delivered' ? 'text-emerald-700' : 'text-slate-400'
                              }`}>
                                <div className={`w-2.5 h-2.5 rounded-full ${
                                  order.status === 'delivered' ? 'bg-emerald-600 ring-4 ring-emerald-100' : 'bg-slate-300'
                                }`} />
                                <span>Delivered</span>
                              </div>
                            </div>
                          </div>

                          {/* Items Preview */}
                          <div className="space-y-2">
                            {order.items.map(it => (
                              <div key={it.product.id} className="flex items-center justify-between text-xs">
                                <div className="flex items-center gap-2.5 min-w-0">
                                  <img
                                    src={it.product.image}
                                    alt=""
                                    className="w-10 h-10 object-contain bg-white rounded-lg border border-slate-200 p-1 shrink-0"
                                  />
                                  <div className="min-w-0">
                                    <p className="font-semibold text-slate-800 truncate">{it.product.name}</p>
                                    <p className="text-[11px] text-slate-500">Qty: {it.quantity}</p>
                                  </div>
                                </div>
                                <span className="font-bold text-slate-900 shrink-0">
                                  ₹{(it.product.price * it.quantity).toLocaleString('en-IN')}
                                </span>
                              </div>
                            ))}
                          </div>

                          {/* Footer */}
                          <div className="pt-2.5 border-t border-slate-200/80 flex items-center justify-between text-xs">
                            <div className="space-y-0.5">
                              <div className="text-slate-600 flex items-center gap-1.5">
                                <Truck className="w-3.5 h-3.5 text-blue-600" />
                                <span>Estimated Delivery: <strong>{order.estimatedDeliveryDate}</strong></span>
                              </div>
                              {order.trackingId && (
                                <div className="text-[11px] text-slate-500 font-mono flex items-center gap-1">
                                  <span>{order.courierPartner || 'Courier'}:</span>
                                  <strong className="text-blue-700 bg-blue-50 px-1.5 py-0.5 rounded border border-blue-200">{order.trackingId}</strong>
                                </div>
                              )}
                            </div>
                            <div className="text-right">
                              <div className="font-black text-sm text-slate-900">
                                Total: ₹{order.totalAmount.toLocaleString('en-IN')}
                              </div>
                              <div className="text-[10px] text-slate-500 flex items-center justify-end gap-1.5">
                                <span>Delivery: {order.deliveryCharge === 0 ? 'FREE' : `₹${order.deliveryCharge}`}</span>
                                {order.taxBreakdown?.gstEnabled && (
                                  <>
                                    <span>•</span>
                                    <span>GST: ₹{order.taxBreakdown.gstAmount.toLocaleString('en-IN')}</span>
                                  </>
                                )}
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* TAB: OFFERS & MESSAGES (Section 17) */}
              {activeTab === 'messages' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between pb-2 border-b border-slate-200">
                    <div>
                      <h4 className="font-bold text-sm text-slate-900 flex items-center gap-2">
                        <MessageSquare className="w-4 h-4 text-blue-600" />
                        <span>Exclusive Offers & Messages</span>
                      </h4>
                      <p className="text-xs text-slate-500">
                        Personal discount coupons, product recommendations, and priority updates
                      </p>
                    </div>
                  </div>

                  {isLoadingMessages ? (
                    <div className="py-12 text-center text-slate-400 text-xs">
                      Loading messages...
                    </div>
                  ) : customerMessages.length === 0 ? (
                    <div className="text-center py-16 space-y-3 bg-slate-50 border border-slate-200 rounded-2xl p-6">
                      <div className="w-14 h-14 rounded-full bg-blue-100 flex items-center justify-center mx-auto text-blue-600">
                        <MessageSquare className="w-7 h-7" />
                      </div>
                      <div className="space-y-1">
                        <h4 className="font-bold text-slate-800 text-sm">No Messages Yet</h4>
                        <p className="text-xs text-slate-500 max-w-sm mx-auto">
                          Personal coupons, flash sale codes, and order assistance from INFOSTORS will appear here.
                        </p>
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {customerMessages.map(msg => (
                        <div
                          key={msg.id}
                          className="p-4 rounded-2xl border border-slate-200 bg-white hover:border-blue-300 transition-all shadow-xs space-y-2"
                        >
                          <div className="flex items-center justify-between gap-2">
                            <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-blue-50 text-blue-700 border border-blue-200">
                              {msg.messageType === 'offer' ? '🎟️ Special Offer' : msg.messageType === 'order_update' ? '📦 Order Note' : '💬 Support'}
                            </span>
                            <span className="text-[11px] text-slate-400">
                              {new Date(msg.createdAt).toLocaleDateString('en-IN', {
                                day: 'numeric',
                                month: 'short',
                                hour: '2-digit',
                                minute: '2-digit',
                              })}
                            </span>
                          </div>

                          <h5 className="font-bold text-xs sm:text-sm text-slate-900 leading-snug">
                            {msg.subject}
                          </h5>

                          <p className="text-xs text-slate-600 leading-relaxed whitespace-pre-wrap">
                            {msg.message}
                          </p>

                          <div className="pt-1 text-[11px] text-slate-400 flex items-center justify-between border-t border-slate-100">
                            <span>From: <strong>{msg.senderName}</strong></span>
                            <span className="text-emerald-600 font-semibold">Verified Store Communication</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* TAB 3: PROFILE & SECURITY */}
              {activeTab === 'profile' && (
                <div className="space-y-8 max-w-lg">
                  {/* Section A: Personal Information */}
                  <form onSubmit={handleUpdateProfile} className="space-y-4">
                    <div className="border-b border-slate-200 pb-2">
                      <h4 className="font-bold text-sm text-slate-900 flex items-center gap-2">
                        <User className="w-4 h-4 text-blue-600" />
                        <span>Personal Information</span>
                      </h4>
                      <p className="text-xs text-slate-500">Update your account name, email, and mobile number</p>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Full Name
                      </label>
                      <input
                        type="text"
                        value={profileName}
                        onChange={e => setProfileName(e.target.value)}
                        required
                        className="w-full px-3.5 py-2.5 text-xs bg-slate-50 border border-slate-300 rounded-xl outline-none focus:bg-white focus:border-blue-500 focus:ring-2 focus:ring-blue-100 transition-all"
                      />
                    </div>

                    <div className="grid sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1">
                          Email Address
                        </label>
                        <input
                          type="email"
                          value={profileEmail}
                          onChange={e => setProfileEmail(e.target.value)}
                          required
                          className="w-full px-3.5 py-2.5 text-xs bg-slate-50 border border-slate-300 rounded-xl outline-none focus:bg-white focus:border-blue-500 focus:ring-2 focus:ring-blue-100 transition-all"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1">
                          Mobile Number (10 digits)
                        </label>
                        <div className="relative">
                          <span className="absolute left-3 top-2.5 text-xs font-semibold text-slate-400">+91</span>
                          <input
                            type="tel"
                            maxLength={10}
                            value={profileMobile}
                            onChange={e => setProfileMobile(e.target.value.replace(/\D/g, ''))}
                            required
                            className="w-full pl-11 pr-3 py-2.5 text-xs bg-slate-50 border border-slate-300 rounded-xl outline-none focus:bg-white focus:border-blue-500 focus:ring-2 focus:ring-blue-100 transition-all"
                          />
                        </div>
                      </div>
                    </div>

                    <button
                      type="submit"
                      disabled={isCustomerLoading}
                      className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl shadow-xs transition-colors cursor-pointer disabled:opacity-50"
                    >
                      {isCustomerLoading ? 'Saving...' : 'Save Profile Changes'}
                    </button>
                  </form>

                  {/* Section B: Change Password */}
                  <form onSubmit={handleChangePassword} className="space-y-4 pt-4 border-t border-slate-200">
                    <div className="border-b border-slate-200 pb-2">
                      <h4 className="font-bold text-sm text-slate-900 flex items-center gap-2">
                        <Lock className="w-4 h-4 text-blue-600" />
                        <span>Change Password</span>
                      </h4>
                      <p className="text-xs text-slate-500">Ensure your account is using a long, random password to stay secure</p>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Current Password
                      </label>
                      <div className="relative">
                        <input
                          type={showChangeCurrentPassword ? 'text' : 'password'}
                          value={currentPassword}
                          onChange={e => setCurrentPassword(e.target.value)}
                          required
                          className="w-full px-3.5 py-2.5 pr-10 text-xs bg-slate-50 border border-slate-300 rounded-xl outline-none focus:bg-white focus:border-blue-500 focus:ring-2 focus:ring-blue-100 transition-all"
                        />
                        <button
                          type="button"
                          onClick={() => setShowChangeCurrentPassword(!showChangeCurrentPassword)}
                          className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-600 cursor-pointer"
                        >
                          {showChangeCurrentPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        </button>
                      </div>
                    </div>

                    <div className="grid sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1">
                          New Password (min 6 chars)
                        </label>
                        <div className="relative">
                          <input
                            type={showChangeNewPassword ? 'text' : 'password'}
                            value={changeNewPassword}
                            onChange={e => setChangeNewPassword(e.target.value)}
                            required
                            minLength={6}
                            className="w-full px-3.5 py-2.5 pr-10 text-xs bg-slate-50 border border-slate-300 rounded-xl outline-none focus:bg-white focus:border-blue-500 focus:ring-2 focus:ring-blue-100 transition-all"
                          />
                          <button
                            type="button"
                            onClick={() => setShowChangeNewPassword(!showChangeNewPassword)}
                            className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-600 cursor-pointer"
                          >
                            {showChangeNewPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                          </button>
                        </div>
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1">
                          Confirm New Password
                        </label>
                        <input
                          type="password"
                          value={changeConfirmPassword}
                          onChange={e => setChangeConfirmPassword(e.target.value)}
                          required
                          minLength={6}
                          className="w-full px-3.5 py-2.5 text-xs bg-slate-50 border border-slate-300 rounded-xl outline-none focus:bg-white focus:border-blue-500 focus:ring-2 focus:ring-blue-100 transition-all"
                        />
                      </div>
                    </div>

                    <button
                      type="submit"
                      disabled={isCustomerLoading}
                      className="px-5 py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl shadow-xs transition-colors cursor-pointer disabled:opacity-50"
                    >
                      {isCustomerLoading ? 'Updating Password...' : 'Update Password'}
                    </button>
                  </form>

                  {/* Section C: Theme & Appearance */}
                  <div className="space-y-4 pt-4 border-t border-slate-200 dark:border-slate-800">
                    <div className="border-b border-slate-200 dark:border-slate-800 pb-2">
                      <h4 className="font-bold text-sm text-slate-900 dark:text-slate-100 flex items-center gap-2">
                        {themeMode === 'dark' ? <Moon className="w-4 h-4 text-indigo-400" /> : <Sun className="w-4 h-4 text-amber-500" />}
                        <span>Theme & Appearance</span>
                      </h4>
                      <p className="text-xs text-slate-500 dark:text-slate-400">
                        Choose how INFOSTORS looks to you. Seamlessly switch between Light and Dark mode anytime.
                      </p>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <button
                        type="button"
                        onClick={() => setThemeMode('light')}
                        className={`p-3.5 rounded-2xl border text-left transition-all cursor-pointer flex flex-col justify-between gap-3 ${
                          themeMode === 'light'
                            ? 'bg-amber-50/60 dark:bg-slate-800 border-amber-400 dark:border-amber-400 ring-2 ring-amber-400/20 shadow-xs'
                            : 'bg-slate-50 dark:bg-slate-800/60 border-slate-200 dark:border-slate-700 hover:border-slate-300'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <div className="w-8 h-8 rounded-xl bg-amber-100 text-amber-600 flex items-center justify-center">
                            <Sun className="w-4 h-4" />
                          </div>
                          {themeMode === 'light' && (
                            <span className="text-[10px] font-bold bg-amber-500 text-white px-1.5 py-0.5 rounded-md">
                              Active
                            </span>
                          )}
                        </div>
                        <div>
                          <div className="font-bold text-xs text-slate-900 dark:text-slate-100">Light Mode</div>
                          <div className="text-[11px] text-slate-500 dark:text-slate-400">Clean, crisp & high clarity</div>
                        </div>
                      </button>

                      <button
                        type="button"
                        onClick={() => setThemeMode('dark')}
                        className={`p-3.5 rounded-2xl border text-left transition-all cursor-pointer flex flex-col justify-between gap-3 ${
                          themeMode === 'dark'
                            ? 'bg-indigo-950/40 dark:bg-slate-800 border-indigo-500 ring-2 ring-indigo-500/20 shadow-xs'
                            : 'bg-slate-50 dark:bg-slate-800/60 border-slate-200 dark:border-slate-700 hover:border-slate-300'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <div className="w-8 h-8 rounded-xl bg-indigo-900 text-indigo-300 flex items-center justify-center">
                            <Moon className="w-4 h-4" />
                          </div>
                          {themeMode === 'dark' && (
                            <span className="text-[10px] font-bold bg-indigo-600 text-white px-1.5 py-0.5 rounded-md">
                              Active
                            </span>
                          )}
                        </div>
                        <div>
                          <div className="font-bold text-xs text-slate-900 dark:text-slate-100">Dark Mode</div>
                          <div className="text-[11px] text-slate-500 dark:text-slate-400">Deep tones & reduced glare</div>
                        </div>
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 4: STORE WALLET */}
              {activeTab === 'wallet' && (
                <div className="space-y-6 max-w-xl">
                  {/* Balance Hero Card */}
                  <div className="bg-gradient-to-r from-blue-700 via-indigo-700 to-slate-900 rounded-3xl p-6 text-white shadow-lg space-y-2 relative overflow-hidden">
                    <div className="absolute top-0 right-0 w-48 h-48 bg-white/10 rounded-full blur-2xl pointer-events-none" />
                    <div className="flex items-center justify-between text-xs text-blue-200">
                      <span className="font-semibold uppercase tracking-wider">Store Wallet Balance</span>
                      <Wallet className="w-5 h-5 text-blue-300" />
                    </div>
                    <div className="text-3xl sm:text-4xl font-black text-white tracking-tight">
                      ₹{walletBalance.toLocaleString('en-IN')}
                    </div>
                    <p className="text-xs text-blue-100/90 pt-1">
                      Wallet balance is automatically applied as instant credit during checkout on any order.
                    </p>
                  </div>

                  {/* Wallet Transactions History */}
                  <div className="space-y-3">
                    <h4 className="font-bold text-sm text-slate-900">Wallet Activity & Refunds</h4>
                    {walletTransactions.length > 0 ? (
                      <div className="space-y-2">
                        {walletTransactions.map(tx => (
                          <div
                            key={tx.id}
                            className="p-3 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between text-xs"
                          >
                            <div className="space-y-0.5">
                              <div className="font-bold text-slate-800">{tx.description}</div>
                              <div className="text-[10px] text-slate-400">
                                {new Date(tx.createdAt).toLocaleDateString('en-IN', {
                                  month: 'short',
                                  day: 'numeric',
                                  year: 'numeric',
                                })}
                              </div>
                            </div>
                            <span
                              className={`font-black text-sm ${
                                tx.type === 'credit' ? 'text-emerald-600' : 'text-slate-800'
                              }`}
                            >
                              {tx.type === 'credit' ? `+₹${tx.amount}` : `-₹${tx.amount}`}
                            </span>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl text-center text-xs text-slate-500">
                        No transactions recorded yet. Any store refunds or promo credits will appear here.
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* TAB 5: LOYALTY & REWARDS */}
              {activeTab === 'loyalty' && (
                <div className="space-y-6 max-w-xl">
                  {/* Loyalty Points Card */}
                  <div className="bg-gradient-to-r from-amber-500 via-amber-600 to-orange-600 rounded-3xl p-6 text-white shadow-lg space-y-2 relative overflow-hidden">
                    <div className="absolute top-0 right-0 w-48 h-48 bg-white/10 rounded-full blur-2xl pointer-events-none" />
                    <div className="flex items-center justify-between text-xs text-amber-100">
                      <span className="font-semibold uppercase tracking-wider">Reward Points Balance</span>
                      <Award className="w-5 h-5 text-amber-200" />
                    </div>
                    <div className="text-3xl sm:text-4xl font-black text-white tracking-tight">
                      {loyaltyBalance.toLocaleString('en-IN')} <span className="text-lg font-bold">PTS</span>
                    </div>
                    <p className="text-xs text-amber-100/90 pt-1">
                      1 Point = ₹1 Rupee. Redeem up to 500 points directly at checkout on gadget orders!
                    </p>
                  </div>

                  {/* Rewards Breakdown */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                    <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-2xl space-y-1">
                      <span className="font-bold text-slate-900">How to Earn</span>
                      <p className="text-slate-600 text-[11px]">
                        Earn 5 reward points on every ₹100 spent on any product in our smart gadget catalog.
                      </p>
                    </div>
                    <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-2xl space-y-1">
                      <span className="font-bold text-slate-900">How to Redeem</span>
                      <p className="text-slate-600 text-[11px]">
                        During checkout, click "Redeem Points" to deduct instant cash discount from your order total.
                      </p>
                    </div>
                  </div>

                  {/* Loyalty History */}
                  <div className="space-y-3">
                    <h4 className="font-bold text-sm text-slate-900">Points History</h4>
                    {loyaltyTransactions.length > 0 ? (
                      <div className="space-y-2">
                        {loyaltyTransactions.map(tx => (
                          <div
                            key={tx.id}
                            className="p-3 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between text-xs"
                          >
                            <div>
                              <div className="font-bold text-slate-800">{tx.description}</div>
                              <div className="text-[10px] text-slate-400">
                                {new Date(tx.createdAt).toLocaleDateString('en-IN', {
                                  month: 'short',
                                  day: 'numeric',
                                })}
                              </div>
                            </div>
                            <span
                              className={`font-black text-xs ${
                                tx.type === 'earned' ? 'text-emerald-600' : 'text-slate-800'
                              }`}
                            >
                              {tx.type === 'earned' ? `+${tx.points} pts` : `-${tx.points} pts`}
                            </span>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl text-center text-xs text-slate-500">
                        Welcome bonus points are active in your account!
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* TAB 6: RETURNS & REPLACEMENTS */}
              {activeTab === 'returns' && (
                <div className="space-y-6">
                  <div className="flex items-center justify-between pb-3 border-b border-slate-200">
                    <div>
                      <h4 className="font-bold text-sm text-slate-900">{storeSettings.returnWindow || '7 Days Replacement'} & Return Requests</h4>
                      <p className="text-xs text-slate-500">Track current return status or submit replacement for delivered orders</p>
                    </div>

                    <button
                      type="button"
                      onClick={() => setActiveTab('orders')}
                      className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl transition cursor-pointer"
                    >
                      View Orders to Return
                    </button>
                  </div>

                  {returnStatusMsg && (
                    <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs rounded-xl flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                      <span>{returnStatusMsg}</span>
                    </div>
                  )}

                  {/* Returns List */}
                  <div className="space-y-3">
                    {customerReturns.length > 0 ? (
                      customerReturns.map(ret => (
                        <div
                          key={ret.id}
                          className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-2 text-xs"
                        >
                          <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-slate-200">
                            <div>
                              <span className="font-bold text-slate-900">Order #{ret.orderId}</span>
                              <span className="text-slate-400 ml-2">Req: {ret.id}</span>
                            </div>
                            <span
                              className={`text-[10px] font-extrabold px-2.5 py-0.5 rounded-full uppercase ${
                                ret.status === 'completed'
                                  ? 'bg-emerald-100 text-emerald-800'
                                  : ret.status === 'approved'
                                  ? 'bg-blue-100 text-blue-800'
                                  : ret.status === 'pickup_scheduled'
                                  ? 'bg-amber-100 text-amber-800'
                                  : ret.status === 'rejected'
                                  ? 'bg-rose-100 text-rose-800'
                                  : 'bg-slate-200 text-slate-700'
                              }`}
                            >
                              {ret.status.replace('_', ' ')}
                            </span>
                          </div>

                          <div className="text-slate-700">
                            <span className="font-semibold">Items: </span>
                            {ret.items.map(i => `${i.name} (x${i.quantity})`).join(', ')}
                          </div>

                          <div className="text-slate-600">
                            <span className="font-semibold">Reason: </span>
                            {ret.reason}
                          </div>

                          {ret.description && (
                            <div className="text-[11px] text-slate-500 italic">
                              "{ret.description}"
                            </div>
                          )}

                          <div className="text-[10px] text-slate-400 pt-1">
                            Submitted on {new Date(ret.createdAt).toLocaleDateString('en-IN', {
                              month: 'short',
                              day: 'numeric',
                              year: 'numeric',
                            })}
                          </div>
                        </div>
                      ))
                    ) : (
                      <div className="p-8 text-center bg-slate-50 border border-slate-200 rounded-2xl space-y-2">
                        <RotateCcw className="w-8 h-8 text-slate-400 mx-auto" />
                        <h5 className="font-bold text-slate-800 text-sm">No Active Return Requests</h5>
                        <p className="text-xs text-slate-500 max-w-xs mx-auto">
                          If you ever receive a damaged or defective item, you can request a return directly from the "My Orders" tab within 7 days of delivery.
                        </p>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          </>
        ) : (
          /* NOT LOGGED IN: Sign In / Sign Up / Forgot Password / Reset Password */
          <div className="overflow-y-auto p-6 flex-1">
            {/* 1. SIGN IN VIEW */}
            {authView === 'signin' && (
              <form onSubmit={handleSignIn} className="max-w-md mx-auto space-y-4" id="form-customer-signin">
                <div className="space-y-1">
                  <label className="block text-xs font-bold text-slate-800">
                    Email or Mobile Number
                  </label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                    <input
                      type="text"
                      placeholder="e.g. rahul@infostors.com or 9477839200"
                      value={loginIdentifier}
                      onChange={e => setLoginIdentifier(e.target.value)}
                      required
                      className="w-full pl-10 pr-3.5 py-2.5 text-xs bg-slate-50 border border-slate-300 rounded-xl outline-none focus:bg-white focus:border-blue-500 focus:ring-2 focus:ring-blue-100 transition-all"
                      id="input-customer-login-identifier"
                    />
                  </div>
                </div>

                <div className="space-y-1">
                  <div className="flex items-center justify-between">
                    <label className="block text-xs font-bold text-slate-800">
                      Password
                    </label>
                    <button
                      type="button"
                      onClick={() => handleSwitchAuthView('forgot-password')}
                      className="text-xs font-semibold text-blue-600 hover:text-blue-800 cursor-pointer"
                      id="link-customer-forgot-password"
                    >
                      Forgot password?
                    </button>
                  </div>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                    <input
                      type={showLoginPassword ? 'text' : 'password'}
                      placeholder="Enter your account password"
                      value={loginPassword}
                      onChange={e => setLoginPassword(e.target.value)}
                      required
                      className="w-full pl-10 pr-10 py-2.5 text-xs bg-slate-50 border border-slate-300 rounded-xl outline-none focus:bg-white focus:border-blue-500 focus:ring-2 focus:ring-blue-100 transition-all"
                      id="input-customer-login-password"
                    />
                    <button
                      type="button"
                      onClick={() => setShowLoginPassword(!showLoginPassword)}
                      className="absolute right-3.5 top-3 text-slate-400 hover:text-slate-600 cursor-pointer"
                    >
                      {showLoginPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-1">
                  <label className="flex items-center gap-2 cursor-pointer text-xs text-slate-600">
                    <input
                      type="checkbox"
                      checked={rememberMe}
                      onChange={e => setRememberMe(e.target.checked)}
                      className="rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                    />
                    <span>Remember me on this browser</span>
                  </label>
                </div>

                <button
                  type="submit"
                  disabled={isCustomerLoading}
                  className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl shadow-md transition-all cursor-pointer flex items-center justify-center gap-2 disabled:opacity-50"
                  id="btn-customer-signin"
                >
                  {isCustomerLoading ? 'Signing in...' : 'Sign In'}
                  <ArrowRight className="w-4 h-4" />
                </button>

                <div className="text-center pt-2 border-t border-slate-100">
                  <p className="text-xs text-slate-600">
                    Don't have an account?{' '}
                    <button
                      type="button"
                      onClick={() => handleSwitchAuthView('signup')}
                      className="font-bold text-blue-600 hover:text-blue-800 cursor-pointer"
                      id="link-customer-switch-to-signup"
                    >
                      Sign Up
                    </button>
                  </p>
                </div>

                {/* Helpful demo hint */}
                <div className="p-3 bg-blue-50/70 border border-blue-100 rounded-xl text-[11px] text-blue-900 space-y-1">
                  <span className="font-bold block">💡 Quick Demo Customer Account:</span>
                  <p>Email: <code className="font-mono font-bold bg-white px-1 py-0.5 rounded">rahul@infostors.com</code></p>
                  <p>Password: <code className="font-mono font-bold bg-white px-1 py-0.5 rounded">Password@123</code></p>
                </div>
              </form>
            )}

            {/* 2. SIGN UP VIEW */}
            {authView === 'signup' && (
              <form onSubmit={handleSignUp} className="max-w-md mx-auto space-y-3.5" id="form-customer-signup">
                <div className="space-y-1">
                  <label className="block text-xs font-bold text-slate-800">
                    Full Name <span className="text-rose-500">*</span>
                  </label>
                  <div className="relative">
                    <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                    <input
                      type="text"
                      placeholder="e.g. Rahul Sharma"
                      value={signupFullName}
                      onChange={e => setSignupFullName(e.target.value)}
                      required
                      className="w-full pl-10 pr-3.5 py-2.5 text-xs bg-slate-50 border border-slate-300 rounded-xl outline-none focus:bg-white focus:border-blue-500 focus:ring-2 focus:ring-blue-100 transition-all"
                      id="input-customer-signup-name"
                    />
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="block text-xs font-bold text-slate-800">
                    Email Address <span className="text-rose-500">*</span>
                  </label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                    <input
                      type="email"
                      placeholder="e.g. rahul@example.com"
                      value={signupEmail}
                      onChange={e => setSignupEmail(e.target.value)}
                      required
                      className="w-full pl-10 pr-3.5 py-2.5 text-xs bg-slate-50 border border-slate-300 rounded-xl outline-none focus:bg-white focus:border-blue-500 focus:ring-2 focus:ring-blue-100 transition-all"
                      id="input-customer-signup-email"
                    />
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="block text-xs font-bold text-slate-800">
                    Mobile Number (Indian 10-Digits) <span className="text-rose-500">*</span>
                  </label>
                  <div className="relative">
                    <span className="absolute left-3.5 top-2.5 text-xs font-bold text-slate-500">+91</span>
                    <input
                      type="tel"
                      maxLength={10}
                      placeholder="9876543210"
                      value={signupMobile}
                      onChange={e => setSignupMobile(e.target.value.replace(/\D/g, ''))}
                      required
                      className="w-full pl-12 pr-3.5 py-2.5 text-xs bg-slate-50 border border-slate-300 rounded-xl outline-none focus:bg-white focus:border-blue-500 focus:ring-2 focus:ring-blue-100 transition-all"
                      id="input-customer-signup-mobile"
                    />
                  </div>
                </div>

                <div className="grid sm:grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="block text-xs font-bold text-slate-800">
                      Password (min 6) <span className="text-rose-500">*</span>
                    </label>
                    <div className="relative">
                      <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                      <input
                        type={showSignupPassword ? 'text' : 'password'}
                        placeholder="••••••••"
                        value={signupPassword}
                        onChange={e => setSignupPassword(e.target.value)}
                        required
                        minLength={6}
                        className="w-full pl-9 pr-9 py-2.5 text-xs bg-slate-50 border border-slate-300 rounded-xl outline-none focus:bg-white focus:border-blue-500 focus:ring-2 focus:ring-blue-100 transition-all"
                        id="input-customer-signup-password"
                      />
                      <button
                        type="button"
                        onClick={() => setShowSignupPassword(!showSignupPassword)}
                        className="absolute right-2.5 top-3 text-slate-400 hover:text-slate-600 cursor-pointer"
                      >
                        {showSignupPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                  </div>

                  <div className="space-y-1">
                    <label className="block text-xs font-bold text-slate-800">
                      Confirm Password <span className="text-rose-500">*</span>
                    </label>
                    <div className="relative">
                      <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                      <input
                        type={showSignupConfirmPassword ? 'text' : 'password'}
                        placeholder="••••••••"
                        value={signupConfirmPassword}
                        onChange={e => setSignupConfirmPassword(e.target.value)}
                        required
                        minLength={6}
                        className="w-full pl-9 pr-9 py-2.5 text-xs bg-slate-50 border border-slate-300 rounded-xl outline-none focus:bg-white focus:border-blue-500 focus:ring-2 focus:ring-blue-100 transition-all"
                        id="input-customer-signup-confirm"
                      />
                      <button
                        type="button"
                        onClick={() => setShowSignupConfirmPassword(!showSignupConfirmPassword)}
                        className="absolute right-2.5 top-3 text-slate-400 hover:text-slate-600 cursor-pointer"
                      >
                        {showSignupConfirmPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isCustomerLoading}
                  className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl shadow-md transition-all cursor-pointer flex items-center justify-center gap-2 disabled:opacity-50 mt-2"
                  id="btn-customer-create-account"
                >
                  {isCustomerLoading ? 'Creating Account...' : 'Create Account'}
                  <ArrowRight className="w-4 h-4" />
                </button>

                <div className="text-center pt-2 border-t border-slate-100">
                  <p className="text-xs text-slate-600">
                    Already have an account?{' '}
                    <button
                      type="button"
                      onClick={() => handleSwitchAuthView('signin')}
                      className="font-bold text-blue-600 hover:text-blue-800 cursor-pointer"
                      id="link-customer-switch-to-signin"
                    >
                      Sign In
                    </button>
                  </p>
                </div>
              </form>
            )}

            {/* 3. FORGOT PASSWORD VIEW (Zero-cost, No SMS OTP) */}
            {authView === 'forgot-password' && (
              <form onSubmit={handleForgotPassword} className="max-w-md mx-auto space-y-4" id="form-customer-forgot-password">
                <div className="text-center space-y-1">
                  <div className="w-12 h-12 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center mx-auto mb-2">
                    <Key className="w-6 h-6" />
                  </div>
                  <h3 className="font-bold text-base text-slate-900">Forgot Your Password?</h3>
                  <p className="text-xs text-slate-500">
                    We'll email you a secure, single-use password reset link. No SMS OTP or paid services needed.
                  </p>
                </div>

                {forgotSuccessMsg ? (
                  <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl space-y-3">
                    <div className="flex items-start gap-2.5 text-xs text-emerald-800">
                      <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                      <div>
                        <p className="font-bold">Email Dispatched!</p>
                        <p className="mt-1">{forgotSuccessMsg}</p>
                      </div>
                    </div>

                    {previewResetLink && (
                      <div className="mt-3 pt-3 border-t border-emerald-200/80">
                        <span className="text-[11px] font-bold text-emerald-900 block mb-1.5">
                          ⚡ Instant Preview Test Link:
                        </span>
                        <a
                          href={previewResetLink}
                          className="inline-flex items-center gap-1.5 text-xs font-bold bg-emerald-600 text-white px-3 py-1.5 rounded-lg hover:bg-emerald-700 transition-colors"
                        >
                          <span>Open Password Reset Screen</span>
                          <ChevronRight className="w-3.5 h-3.5" />
                        </a>
                      </div>
                    )}
                  </div>
                ) : (
                  <>
                    <div className="space-y-1">
                      <label className="block text-xs font-bold text-slate-800">
                        Registered Email Address
                      </label>
                      <div className="relative">
                        <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                        <input
                          type="email"
                          placeholder="e.g. rahul@infostors.com"
                          value={forgotEmail}
                          onChange={e => setForgotEmail(e.target.value)}
                          required
                          className="w-full pl-10 pr-3.5 py-2.5 text-xs bg-slate-50 border border-slate-300 rounded-xl outline-none focus:bg-white focus:border-blue-500 focus:ring-2 focus:ring-blue-100 transition-all"
                          id="input-customer-forgot-email"
                        />
                      </div>
                    </div>

                    <button
                      type="submit"
                      disabled={isCustomerLoading}
                      className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl shadow-md transition-all cursor-pointer flex items-center justify-center gap-2 disabled:opacity-50"
                      id="btn-customer-send-reset-link"
                    >
                      {isCustomerLoading ? 'Sending link...' : 'Send Password Reset Link'}
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  </>
                )}

                <div className="text-center pt-2">
                  <button
                    type="button"
                    onClick={() => handleSwitchAuthView('signin')}
                    className="inline-flex items-center gap-1.5 text-xs font-bold text-slate-600 hover:text-slate-900 cursor-pointer"
                  >
                    <ArrowLeft className="w-3.5 h-3.5" />
                    <span>Back to Sign In</span>
                  </button>
                </div>
              </form>
            )}

            {/* 4. SET NEW PASSWORD VIEW (After clicking email reset link) */}
            {authView === 'reset-password' && (
              <form onSubmit={handleResetPassword} className="max-w-md mx-auto space-y-4" id="form-customer-set-new-password">
                <div className="text-center space-y-1">
                  <div className="w-12 h-12 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center mx-auto mb-2">
                    <Lock className="w-6 h-6" />
                  </div>
                  <h3 className="font-bold text-base text-slate-900">Choose New Password</h3>
                  <p className="text-xs text-slate-500">
                    Enter a new secure password for your INFOSTORS customer account.
                  </p>
                </div>

                <div className="space-y-1">
                  <label className="block text-xs font-bold text-slate-800">
                    Reset Token
                  </label>
                  <input
                    type="text"
                    placeholder="Reset token string"
                    value={resetToken}
                    onChange={e => setResetToken(e.target.value)}
                    required
                    className="w-full px-3.5 py-2.5 text-xs bg-slate-50 border border-slate-300 rounded-xl outline-none focus:bg-white focus:border-blue-500 font-mono"
                  />
                </div>

                <div className="space-y-1">
                  <label className="block text-xs font-bold text-slate-800">
                    New Password (min 6 characters)
                  </label>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                    <input
                      type={showResetNewPassword ? 'text' : 'password'}
                      placeholder="Enter new password"
                      value={resetNewPassword}
                      onChange={e => setResetNewPassword(e.target.value)}
                      required
                      minLength={6}
                      className="w-full pl-10 pr-10 py-2.5 text-xs bg-slate-50 border border-slate-300 rounded-xl outline-none focus:bg-white focus:border-blue-500"
                    />
                    <button
                      type="button"
                      onClick={() => setShowResetNewPassword(!showResetNewPassword)}
                      className="absolute right-3.5 top-3 text-slate-400 hover:text-slate-600 cursor-pointer"
                    >
                      {showResetNewPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="block text-xs font-bold text-slate-800">
                    Confirm New Password
                  </label>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                    <input
                      type="password"
                      placeholder="Repeat new password"
                      value={resetConfirmPassword}
                      onChange={e => setResetConfirmPassword(e.target.value)}
                      required
                      minLength={6}
                      className="w-full pl-10 pr-3.5 py-2.5 text-xs bg-slate-50 border border-slate-300 rounded-xl outline-none focus:bg-white focus:border-blue-500"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isCustomerLoading}
                  className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl shadow-md transition-all cursor-pointer flex items-center justify-center gap-2 disabled:opacity-50"
                >
                  {isCustomerLoading ? 'Saving new password...' : 'Update Password'}
                  <CheckCircle2 className="w-4 h-4" />
                </button>

                <div className="text-center pt-2">
                  <button
                    type="button"
                    onClick={() => handleSwitchAuthView('signin')}
                    className="inline-flex items-center gap-1.5 text-xs font-bold text-slate-600 hover:text-slate-900 cursor-pointer"
                  >
                    <ArrowLeft className="w-3.5 h-3.5" />
                    <span>Back to Sign In</span>
                  </button>
                </div>
              </form>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
