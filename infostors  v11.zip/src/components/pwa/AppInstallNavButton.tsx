import React, { useState } from 'react';
import { Smartphone } from 'lucide-react';
import { useShop } from '../../context/ShopContext';
import { usePwaInstall } from '../../utils/usePwaInstall';

interface AppInstallNavButtonProps {
  className?: string;
  variant?: 'header' | 'footer' | 'default' | 'mobile';
}

export const AppInstallNavButton: React.FC<AppInstallNavButtonProps> = ({
  className = '',
  variant = 'default',
}) => {
  const { storeSettings } = useShop();
  const { isInstalled, canInstall, promptInstall, isAndroid, isIOS } = usePwaInstall();
  const [helpNotice, setHelpNotice] = useState<string | null>(null);

  const pwa = storeSettings.pwaSettings;

  // If master PWA toggle is OFF or showInstallButton is false, or already installed, do not render!
  if (
    pwa?.pwaInstallEnabled === false ||
    pwa?.showInstallButton === false ||
    isInstalled
  ) {
    return null;
  }

  const handleInstall = async () => {
    if (isAndroid && pwa?.enableApkDownload !== false && pwa?.apkDetails?.status === 'available') {
      const apkLink = document.createElement('a');
      apkLink.href = '/api/app/download-apk';
      apkLink.download = pwa?.apkDetails?.fileName || 'infostors.apk';
      document.body.appendChild(apkLink);
      apkLink.click();
      document.body.removeChild(apkLink);
      return;
    }

    if (canInstall) {
      await promptInstall();
    } else {
      setHelpNotice(
        isIOS
          ? 'To install, tap Share (⎋) at the bottom and choose "Add to Home Screen".'
          : 'To install, tap your browser menu (⋮) and choose "Install app" or "Add to Home screen".'
      );
      setTimeout(() => setHelpNotice(null), 5000);
    }
  };

  return (
    <div className="relative inline-block">
      <button
        type="button"
        onClick={handleInstall}
        className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
          variant === 'header'
            ? 'bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 hover:bg-blue-100 dark:hover:bg-blue-900/60 border border-blue-200 dark:border-blue-800'
            : 'bg-blue-600 text-white hover:bg-blue-500 shadow-xs'
        } ${className}`}
        title="Install INFOSTORS Progressive Web App"
        id="nav-install-android-app-btn"
      >
        <Smartphone className="w-3.5 h-3.5" />
        <span>{pwa?.installButtonText || 'Install App'}</span>
      </button>

      {helpNotice && (
        <div className="absolute top-full mt-1.5 right-0 z-50 w-64 p-2.5 bg-slate-900 text-white text-[11px] rounded-xl shadow-xl border border-slate-700 animate-in fade-in">
          {helpNotice}
        </div>
      )}
    </div>
  );
};
