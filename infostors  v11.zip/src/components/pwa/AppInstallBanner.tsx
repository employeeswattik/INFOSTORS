import React, { useState } from 'react';
import { Smartphone, Download, X } from 'lucide-react';
import { useShop } from '../../context/ShopContext';
import { usePwaInstall } from '../../utils/usePwaInstall';

export const AppInstallBanner: React.FC = () => {
  const { storeSettings } = useShop();
  const { isInstalled, canInstall, promptInstall } = usePwaInstall();
  const [dismissedSession, setDismissedSession] = useState(false);

  const pwa = storeSettings.pwaSettings;

  const [showInstructions, setShowInstructions] = useState(false);

  // If master toggle is OFF, banner disabled, user dismissed for session, or already installed, do not show!
  if (
    pwa?.pwaInstallEnabled === false ||
    !pwa?.bannerEnabled ||
    dismissedSession ||
    isInstalled
  ) {
    return null;
  }

  const handleInstallClick = async () => {
    if (canInstall) {
      await promptInstall();
    } else {
      // If browser doesn't support direct programmatic prompt (e.g. iOS Safari / desktop Firefox)
      // Provide clean inline guidance without window.alert
      setShowInstructions(prev => !prev);
    }
  };

  return (
    <aside aria-label="App installation banner" className="relative w-full bg-gradient-to-r from-blue-700 via-indigo-700 to-slate-900 text-white px-3 py-2 text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-2 shadow-xs z-30 animate-in fade-in duration-300">
      <div className="flex items-center gap-2.5 max-w-[80%]">
        <div className="w-7 h-7 rounded-lg bg-white/20 flex items-center justify-center shrink-0">
          <Smartphone className="w-4 h-4 text-white" />
        </div>
        <div className="truncate">
          <span className="font-bold">{pwa?.installBannerText || 'Install INFOSTORS Android App'}</span>
          <span className="hidden sm:inline text-blue-200 ml-1.5">— Fast checkout and real-time order tracking</span>
        </div>
      </div>

      <div className="flex items-center gap-2 shrink-0">
        <button
          onClick={handleInstallClick}
          className="px-3 py-1 rounded-lg bg-white text-blue-700 hover:bg-blue-50 font-bold text-[11px] shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
          title="Install INFOSTORS App"
          id="banner-install-app-btn"
        >
          <Download className="w-3.5 h-3.5" />
          <span>{pwa?.installButtonText || 'Install App'}</span>
        </button>
        <button
          onClick={() => setDismissedSession(true)}
          className="p-1 text-white/80 hover:text-white transition-colors cursor-pointer"
          title="Dismiss"
          aria-label="Dismiss banner"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {showInstructions && (
        <div className="w-full bg-slate-950/90 border border-slate-700 p-2.5 rounded-xl text-[11px] text-slate-200 mt-1 flex items-center justify-between gap-3">
          <span>Tap your browser menu (<strong>⋮</strong> or <strong>Share ⎋</strong>) and select <strong>"Add to Home Screen"</strong> or <strong>"Install App"</strong>.</span>
          <button
            type="button"
            onClick={() => setShowInstructions(false)}
            className="text-slate-400 hover:text-white text-xs font-bold px-2 py-0.5"
          >
            Got it
          </button>
        </div>
      )}
    </aside>
  );
};
