import { Order, StoreSettings, WhatsAppNotificationSettings } from '../types';

export const OFFICIAL_DEFAULT_TEMPLATES = {
  received: `🛍️ *INFOSTORS — ORDER RECEIVED*

Hello {{customer_name}} 👋

Thank you for shopping with *INFOSTORS*.

✅ Your order has been successfully received and confirmed.

📦 *Order ID:* {{order_id}}
📅 *Date:* {{order_date}}
💰 *Order Total:* ₹{{order_total}}
💳 *Payment Method:* {{payment_method}}
🛍️ *Items:* {{product_name}} (Qty: {{quantity}})

📍 *Delivery Address:*
{{delivery_address}}

Our warehouse team is carefully preparing your shipment. We will notify you as soon as your package is dispatched! 🚚

Thank you for choosing *INFOSTORS* ❤️

For assistance:
📞 {{support_phone}}`,

  dispatched: `🚚 *INFOSTORS — ORDER DISPATCHED*

Hello {{customer_name}} 👋

Great news! Your order is now on its way. 📦✨

🆔 *Order ID:* {{order_id}}
🚚 *Courier Partner:* {{courier_name}}
🔎 *Tracking Number:* {{tracking_number}}
📋 *AWB / Delivery No:* {{delivery_number}}

📍 *Delivery Address:*
{{delivery_address}}

💰 *Amount Due:* {{payment_method}} (₹{{order_total}})

Track your package online anytime:
🔗 https://infostors.com/track?order={{order_id}}

Please keep your phone available for the delivery partner. 📞

Thank you for shopping with *INFOSTORS* ❤️`,

  delivered: `🎉 *INFOSTORS — ORDER DELIVERED*

Hello {{customer_name}} 👋

Your order has been successfully delivered! ✅📦

🆔 *Order ID:* {{order_id}}
💰 *Order Total:* ₹{{order_total}}
📍 *Delivered To:*
{{delivery_address}}

We hope you love your new gadgets! If you need any assistance, replacement, or warranty support, we're always here to help. ⭐

Thank you for shopping with *INFOSTORS* ❤️

Customer Support:
📞 {{support_phone}}`,
};

export const DEFAULT_WHATSAPP_NOTIFICATION_SETTINGS: WhatsAppNotificationSettings = {
  enabledTypes: {
    order_confirmed: true,
    order_processing: true,
    order_dispatched: true,
    out_for_delivery: true,
    order_delivered: true,
    order_cancelled: true,
    payment_received: true,
  },
  templates: {
    order_confirmed: {
      title: 'Order Received',
      body: OFFICIAL_DEFAULT_TEMPLATES.received,
    },
    order_processing: {
      title: 'Order Processing',
      body: OFFICIAL_DEFAULT_TEMPLATES.received,
    },
    order_dispatched: {
      title: 'Order Dispatched',
      body: OFFICIAL_DEFAULT_TEMPLATES.dispatched,
    },
    out_for_delivery: {
      title: 'Out for Delivery',
      body: OFFICIAL_DEFAULT_TEMPLATES.dispatched,
    },
    order_delivered: {
      title: 'Order Delivered',
      body: OFFICIAL_DEFAULT_TEMPLATES.delivered,
    },
    order_cancelled: {
      title: 'Order Cancelled',
      body: 'Your order {{order_id}} has been cancelled. For queries contact {{support_phone}}.',
    },
    payment_received: {
      title: 'Payment Received',
      body: 'Payment for order {{order_id}} of ₹{{order_total}} has been received.',
    },
  },
  businessNumber: '+91 94778 39200',
  autoPromptOnStatusChange: true,
};

export const AVAILABLE_WHATSAPP_VARIABLES = [
  { key: '{{customer_name}}', label: 'Insert Customer Name', desc: "Customer's full name" },
  { key: '{{order_id}}', label: 'Insert Order ID', desc: 'Authoritative order reference' },
  { key: '{{order_date}}', label: 'Insert Order Date', desc: 'Date order was placed' },
  { key: '{{product_name}}', label: 'Insert Product Name', desc: 'Summary of ordered items' },
  { key: '{{quantity}}', label: 'Insert Quantity', desc: 'Total item units count' },
  { key: '{{order_total}}', label: 'Insert Order Total', desc: 'Grand total payable' },
  { key: '{{payment_method}}', label: 'Insert Payment Method', desc: 'COD or Prepaid Online' },
  { key: '{{delivery_address}}', label: 'Insert Delivery Address', desc: 'Full destination address' },
  { key: '{{courier_name}}', label: 'Insert Courier', desc: 'Assigned logistics carrier' },
  { key: '{{tracking_number}}', label: 'Insert Tracking Number', desc: 'Shipment tracking ID' },
  { key: '{{delivery_number}}', label: 'Insert Delivery Number', desc: 'AWB / Consignment number' },
  { key: '{{support_phone}}', label: 'Insert Support Number', desc: 'Store helpline phone' },
  { key: '{{store_name}}', label: 'Insert Store Name', desc: 'Brand / Store title' },
];

export function interpolateWhatsAppMessage(
  template: string,
  order: Partial<Order> | null,
  storeSettings?: Partial<StoreSettings>
): string {
  if (!template) return '';

  const cleanNum = (order?.orderId || '').replace(/\D/g, '');
  const trackingNumber = order?.trackingId || (cleanNum ? `INF${cleanNum}` : 'INF7842091');
  const deliveryNumber = (order as any)?.deliveryNumber || trackingNumber;
  const courier = order?.courierPartner || 'Delhivery Express';
  const supportPhone = storeSettings?.helpline || '+91 94778 39200';
  const storeName = storeSettings?.storeName || 'INFOSTORS';

  let itemsSummary = 'Smart Electronics Gadgets';
  let totalQty = 1;
  if (order?.items && order.items.length > 0) {
    itemsSummary = order.items
      .map(i => (i as any).name || i.product?.name || 'Gadget Item')
      .slice(0, 2)
      .join(', ');
    if (order.items.length > 2) {
      itemsSummary += ` + ${order.items.length - 2} more`;
    }
    totalQty = order.items.reduce((sum, item) => sum + (item.quantity || 1), 0);
  }

  const customerName = order?.customer?.fullName || 'Valued Customer';
  const orderId = order?.orderId || 'ORD-2026-7842';
  const orderTotal = String(order?.totalAmount ?? '1,499');
  const paymentMethod = order?.paymentMethod === 'cod' ? 'Cash on Delivery (COD)' : 'Prepaid Online';

  const fullAddress = [
    order?.customer?.address,
    order?.customer?.city,
    order?.customer?.state,
    order?.customer?.pincode ? `PIN: ${order.customer.pincode}` : '',
  ]
    .filter(Boolean)
    .join(', ') || 'Kolkata, West Bengal, PIN: 700084';

  const orderDate = order?.date
    ? new Date(order.date).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })
    : new Date().toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });

  const mapping: Record<string, string> = {
    customer_name: customerName,
    order_id: orderId,
    order_date: orderDate,
    product_name: itemsSummary,
    quantity: String(totalQty),
    order_total: orderTotal,
    amount: orderTotal,
    payment_method: paymentMethod,
    delivery_address: fullAddress,
    courier_name: courier,
    courier: courier,
    tracking_number: trackingNumber,
    tracking_id: trackingNumber,
    delivery_number: deliveryNumber,
    support_phone: supportPhone,
    store_name: storeName,
  };

  let result = template;
  for (const [key, val] of Object.entries(mapping)) {
    result = result.replace(new RegExp(`\\{\\{${key}\\}\\}`, 'gi'), val);
    result = result.replace(new RegExp(`\\{${key}\\}`, 'gi'), val);
  }

  return result;
}

export function generateSampleWhatsAppPreview(
  template: string,
  type: 'received' | 'dispatched' | 'delivered',
  storeSettings?: Partial<StoreSettings>
): string {
  const sampleOrder: Partial<Order> = {
    orderId: 'INF-20260926-1001',
    date: new Date().toISOString(),
    totalAmount: 1899,
    paymentMethod: 'cod',
    courierPartner: 'Delhivery Express',
    trackingId: 'INF8934120',
    customer: {
      fullName: 'Rahul Sharma',
      email: 'rahul.sharma@example.com',
      phone: '9876543210',
      address: 'Plot 42, Southern Avenue, Lake Gardens',
      city: 'Kolkata',
      state: 'West Bengal',
      pincode: '700029',
    },
    items: [
      {
        productId: 'inf-101',
        name: 'AeroBeat Pro ANC Wireless Earbuds',
        price: 1899,
        quantity: 1,
      } as any,
    ],
  };

  return interpolateWhatsAppMessage(template, sampleOrder, storeSettings);
}
