import React, { useState, useEffect } from 'react';
import { useShop } from './context/ShopContext';
import { Header } from './components/Header';
import { CategoryNav } from './components/CategoryNav';
import { HeroBanner } from './components/HeroBanner';
import { ProductSection } from './components/ProductSection';
import { ProductDetailModal } from './components/ProductDetailModal';
import { CartDrawer } from './components/CartDrawer';
import { WishlistDrawer } from './components/WishlistDrawer';
import { CheckoutModal } from './components/CheckoutModal';
import { OrderConfirmationModal } from './components/OrderConfirmationModal';
import { AccountModal } from './components/AccountModal';
import { PolicyModal } from './components/PolicyModal';
import { Footer } from './components/Footer';
import { MobileBottomNav } from './components/MobileBottomNav';
import { UnifiedFloatingActions } from './components/UnifiedFloatingActions';
import { OrderTrackingModal } from './components/customer/OrderTrackingModal';
import { CategoriesModal } from './components/customer/CategoriesModal';
import { FlashSaleSection } from './components/customer/FlashSaleSection';
import { PromotionalOffersSection } from './components/customer/PromotionalOffersSection';

/**
 * OFFICIAL INFOSTORS CUSTOMER WEBSITE
 * Exclusively presents the customer e-commerce shopping experience.
 * Fully decoupled from Admin views with zero admin controls.
 * Deep-linking support for:
 * /
 * /products
 * /categories
 * /category/:id
 * /product/:id
 * /search?q=...
 * /cart
 * /checkout
 * /login
 * /register
 * /account
 * /account/profile
 * /account/addresses
 * /account/orders
 * /account/orders/:id
 * /account/wishlist
 * /order-success
 * /order-tracking
 */
export const CustomerApp: React.FC = () => {
  const {
    products,
    categories,
    selectedCategory,
    setSelectedCategory,
    setSearchQuery,
    selectedProduct,
    setSelectedProduct,
    setIsCartOpen,
    setIsWishlistOpen,
    setIsCheckoutOpen,
    setIsAccountOpen,
    setIsOrderSuccessOpen,
    activeOrder,
    storeSettings,
  } = useShop();

  const [isOrderTrackingOpen, setIsOrderTrackingOpen] = useState(false);
  const [trackingOrderId, setTrackingOrderId] = useState<string>('');
  const [isCategoriesModalOpen, setIsCategoriesModalOpen] = useState(false);

  // Synchronize client-side routes on mount & popstate
  useEffect(() => {
    const handleUrlRoute = () => {
      const path = window.location.pathname.toLowerCase();
      const params = new URLSearchParams(window.location.search);

      // 1. Direct Product Link: /product/:id
      if (path.startsWith('/product/')) {
        const prodId = path.replace('/product/', '').trim();
        const found = products.find(p => p.id.toLowerCase() === prodId.toLowerCase());
        if (found) {
          setSelectedProduct(found);
          document.title = `${found.name} | ${storeSettings.storeName || 'INFOSTORS'}`;
        }
      }

      // 2. Direct Category Link: /category/:id
      if (path.startsWith('/category/')) {
        const catId = path.replace('/category/', '').trim();
        if (catId) {
          setSelectedCategory(catId);
          const foundCat = categories.find(c => c.id.toLowerCase() === catId.toLowerCase());
          if (foundCat) {
            document.title = `${foundCat.name} | ${storeSettings.storeName || 'INFOSTORS'}`;
          }
        }
      }

      // 3. Search: /search?q=...
      if (path === '/search' || params.has('search') || params.has('q')) {
        const query = params.get('q') || params.get('search') || '';
        if (query) {
          setSearchQuery(query);
          document.title = `Search: "${query}" | ${storeSettings.storeName || 'INFOSTORS'}`;
        }
      }

      // 4. Cart: /cart
      if (path === '/cart') {
        setIsCartOpen(true);
      }

      // 5. Checkout: /checkout
      if (path === '/checkout') {
        setIsCheckoutOpen(true);
      }

      // 6. Auth & Account routes: /login, /register, /account, /account/orders, etc.
      if (
        path === '/login' ||
        path === '/register' ||
        path === '/account' ||
        path.startsWith('/account/')
      ) {
        setIsAccountOpen(true);
      }

      // 7. Wishlist: /account/wishlist or /wishlist
      if (path === '/account/wishlist' || path === '/wishlist') {
        setIsWishlistOpen(true);
      }

      // 8. Order Tracking & Order Details Scan: /track, /order-tracking, /track-order, /order/:id or ?order=... / ?track=...
      const orderParam = params.get('order') || params.get('orderId') || params.get('track') || params.get('order_id') || '';
      if (
        path === '/track' ||
        path.startsWith('/track/') ||
        path === '/order-tracking' ||
        path === '/track-order' ||
        path.startsWith('/order/') ||
        Boolean(orderParam)
      ) {
        let orderIdParam = orderParam;
        if (!orderIdParam && path.startsWith('/track/')) {
          orderIdParam = path.replace('/track/', '').trim();
        } else if (!orderIdParam && path.startsWith('/order/')) {
          orderIdParam = path.replace('/order/', '').trim();
        }
        if (orderIdParam) {
          setTrackingOrderId(orderIdParam);
        }
        setIsOrderTrackingOpen(true);
        document.title = `Order #${orderIdParam || 'Details'} | ${storeSettings.storeName || 'INFOSTORS'}`;
      }

      // 9. Categories Showcase: /categories
      if (path === '/categories') {
        setIsCategoriesModalOpen(true);
      }

      // 10. Order Success: /order-success
      if (path === '/order-success' && activeOrder) {
        setIsOrderSuccessOpen(true);
      }
    };

    handleUrlRoute();
    window.addEventListener('popstate', handleUrlRoute);
    return () => window.removeEventListener('popstate', handleUrlRoute);
  }, [products, categories, storeSettings, activeOrder]);

  return (
    <div className="min-h-screen w-full max-w-full overflow-x-hidden flex flex-col bg-slate-50 dark:bg-slate-950 text-slate-800 dark:text-slate-100 antialiased selection:bg-blue-600 selection:text-white relative transition-colors duration-200">
      {/* Sticky Professional Customer Header */}
      <Header />

      {/* Horizontal Category Navigation Bar */}
      <CategoryNav />

      {/* Main Content Area */}
      <main className="flex-1">
        {/* Promotional Hero Section with Ambient Glow */}
        {storeSettings.layoutSettings?.customer?.showHeroBanner !== false && <HeroBanner />}

        {/* Flash Sale Banner & Countdown Rail */}
        <FlashSaleSection />

        {/* Promotional Offers Banner */}
        <PromotionalOffersSection />

        {/* Product Grid & Sections */}
        <ProductSection />
      </main>

      {/* Footer with Policies, Info, Newsletter & Payment badges */}
      <Footer />

      {/* Sticky Mobile Bottom Navigation (Home, Categories, Search, Wishlist, Cart, Account) */}
      <MobileBottomNav />

      {/* Unified Floating Actions Area: 📲 Install App + 💚 WhatsApp Support */}
      <UnifiedFloatingActions />

      {/* Customer Modals and Drawers */}
      <ProductDetailModal />
      <CartDrawer />
      <WishlistDrawer />
      <CheckoutModal />
      <OrderConfirmationModal />
      <AccountModal />
      <PolicyModal />

      {/* Standalone Live Order Tracking Modal */}
      <OrderTrackingModal
        isOpen={isOrderTrackingOpen}
        onClose={() => {
          setIsOrderTrackingOpen(false);
          if (window.location.pathname.includes('/order-tracking') || window.location.pathname.includes('/track-order')) {
            window.history.pushState(null, '', '/');
          }
        }}
        initialOrderId={trackingOrderId}
      />

      {/* Standalone Categories Showcase Modal */}
      <CategoriesModal
        isOpen={isCategoriesModalOpen}
        onClose={() => {
          setIsCategoriesModalOpen(false);
          if (window.location.pathname === '/categories') {
            window.history.pushState(null, '', '/');
          }
        }}
      />
    </div>
  );
};
