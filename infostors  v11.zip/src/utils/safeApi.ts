/**
 * Safe API response parsing utility for INFOSTORS.
 * Handles both JSON responses and non-JSON error fallbacks safely.
 * Prevents "Unexpected token '<', '<!DOCTYPE '... is not valid JSON" errors in frontend.
 */

export interface ParsedApiResponse<T = any> {
  ok: boolean;
  data: T | null;
  errorMessage?: string;
  status: number;
}

export async function parseApiResponse<T = any>(res: Response): Promise<ParsedApiResponse<T>> {
  let data: any = null;
  let errorMessage: string | undefined;

  try {
    const contentType = res.headers.get('content-type') || '';
    if (contentType.includes('application/json')) {
      data = await res.json();
    } else {
      const text = await res.text();
      if (text.trim().startsWith('<') || text.includes('<!DOCTYPE') || text.includes('<html')) {
        // Returned HTML (e.g. 404, 502 Bad Gateway, 504 Gateway Timeout, or reverse proxy error)
        errorMessage = `Service temporary unavailable (Status ${res.status}). Please try again shortly.`;
        data = null;
      } else {
        try {
          data = JSON.parse(text);
        } catch {
          data = text ? { message: text } : null;
        }
      }
    }
  } catch (err: any) {
    errorMessage = err?.message || 'Failed to parse response from server';
  }

  if (!res.ok) {
    errorMessage = data?.error || data?.message || errorMessage || `Request failed with status ${res.status}`;
  }

  return {
    ok: res.ok,
    data,
    errorMessage,
    status: res.status,
  };
}

export async function safeFetchJson<T = any>(url: string, init?: RequestInit): Promise<ParsedApiResponse<T>> {
  try {
    const res = await fetch(url, init);
    return await parseApiResponse<T>(res);
  } catch (err: any) {
    return {
      ok: false,
      data: null,
      errorMessage: err?.message || 'Network failure or server offline. Please check your connection.',
      status: 0,
    };
  }
}
