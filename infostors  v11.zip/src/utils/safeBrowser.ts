/**
 * Safe Browser Helpers
 * Guards against sandbox locker restrictions in iframe / preview environments
 */

export const safeConfirm = (message: string): boolean => {
  try {
    if (typeof window !== 'undefined' && typeof window.confirm === 'function') {
      return window.confirm(message);
    }
    return true;
  } catch {
    return true;
  }
};

export const safeAlert = (message: string): void => {
  try {
    if (typeof window !== 'undefined' && typeof window.alert === 'function') {
      window.alert(message);
    } else {
      console.warn('[Alert Notice]:', message);
    }
  } catch {
    console.warn('[Alert Notice]:', message);
  }
};

export const safePrint = (): void => {
  try {
    if (typeof window !== 'undefined' && typeof window.print === 'function') {
      window.print();
    }
  } catch (err) {
    console.warn('[Print Notice]:', err);
  }
};
