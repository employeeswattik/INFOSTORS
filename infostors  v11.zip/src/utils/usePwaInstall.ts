import { useState, useEffect, useCallback } from 'react';

// Shared global state so all components remain synchronized across the page lifecycle
let globalDeferredPrompt: any = null;
let globalIsInstalled = false;
let globalIsStandalone = false;
const listeners = new Set<() => void>();

function notifyListeners() {
  listeners.forEach(listener => {
    try {
      listener();
    } catch {
      // Ignore listener error
    }
  });
}

function checkStandaloneStatus(): boolean {
  if (typeof window === 'undefined') return false;
  return (
    window.matchMedia('(display-mode: standalone)').matches ||
    (window.navigator as any).standalone === true ||
    document.referrer.includes('android-app://')
  );
}

if (typeof window !== 'undefined') {
  globalIsStandalone = checkStandaloneStatus();

  // If running directly in standalone mode or flagged as installed:
  if (globalIsStandalone || localStorage.getItem('infostors_pwa_installed') === 'true') {
    globalIsInstalled = true;
  }

  // Listen to display-mode changes dynamically
  try {
    const mql = window.matchMedia('(display-mode: standalone)');
    mql.addEventListener('change', e => {
      globalIsStandalone = e.matches;
      if (e.matches) {
        globalIsInstalled = true;
        globalDeferredPrompt = null;
        try {
          localStorage.setItem('infostors_pwa_installed', 'true');
        } catch {
          // LocalStorage fallback
        }
      }
      notifyListeners();
    });
  } catch {
    // Media query listener fallback
  }

  // Native beforeinstallprompt event capture
  window.addEventListener('beforeinstallprompt', (e: Event) => {
    // Prevent the default browser mini-infobar on mobile to use our dedicated install action
    e.preventDefault();
    globalDeferredPrompt = e;
    globalIsInstalled = false; // Native prompt is available
    notifyListeners();
  });

  // Official native appinstalled event
  window.addEventListener('appinstalled', () => {
    globalIsInstalled = true;
    globalDeferredPrompt = null;
    try {
      localStorage.setItem('infostors_pwa_installed', 'true');
    } catch {
      // LocalStorage fallback
    }
    notifyListeners();
  });
}

export function usePwaInstall() {
  const [, setTick] = useState(0);

  useEffect(() => {
    const onChange = () => setTick(t => t + 1);
    listeners.add(onChange);
    return () => {
      listeners.delete(onChange);
    };
  }, []);

  const promptInstall = useCallback(async (): Promise<{ outcome: 'accepted' | 'dismissed' | 'unavailable' }> => {
    if (!globalDeferredPrompt) {
      return { outcome: 'unavailable' };
    }

    try {
      // Trigger the native browser install dialog
      globalDeferredPrompt.prompt();
      const choiceResult = await globalDeferredPrompt.userChoice;

      // Note: We only mark isInstalled when the browser actually fires 'appinstalled',
      // or if outcome was accepted, we clear the prompt.
      if (choiceResult && choiceResult.outcome === 'accepted') {
        globalDeferredPrompt = null;
        notifyListeners();
        return { outcome: 'accepted' };
      }

      return { outcome: 'dismissed' };
    } catch (err) {
      console.warn('Native PWA install prompt error:', err);
      return { outcome: 'unavailable' };
    }
  }, []);

  const resetInstallStatus = useCallback(() => {
    globalIsInstalled = false;
    try {
      localStorage.removeItem('infostors_pwa_installed');
    } catch {
      // LocalStorage fallback
    }
    notifyListeners();
  }, []);

  const isAndroid = typeof navigator !== 'undefined' && /Android/i.test(navigator.userAgent);
  const isIOS =
    typeof navigator !== 'undefined' &&
    (/iPhone|iPad|iPod/i.test(navigator.userAgent) ||
      (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1));
  const isDesktop = !isAndroid && !isIOS;

  return {
    canInstall: Boolean(globalDeferredPrompt) && !globalIsInstalled,
    isInstalled: globalIsInstalled || globalIsStandalone,
    isStandalone: globalIsStandalone,
    hasDeferredPrompt: Boolean(globalDeferredPrompt),
    isAndroid,
    isIOS,
    isDesktop,
    promptInstall,
    resetInstallStatus,
  };
}
