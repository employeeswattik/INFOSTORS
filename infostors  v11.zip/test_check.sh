npx tsc --noEmit
echo "TSC EXIT: $?"
