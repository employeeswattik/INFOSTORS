-- ============================================================================
-- INFOSTORS FINAL SUPABASE MASTER BUILD — MIGRATION 01: EXTENSIONS
-- Target Project ID: oewerfftzqklptdsdfrm
-- Project URL: https://oewerfftzqklptdsdfrm.supabase.co
-- Safety: Non-destructive, idempotent
-- ============================================================================

-- Enable UUID generation support
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Enable cryptographic hashing and random byte generators
CREATE EXTENSION IF NOT EXISTS "pgcrypto";
