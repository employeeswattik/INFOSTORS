-- ============================================================================
-- INFOSTORS FINAL SUPABASE MASTER BUILD — MIGRATION 03: BASE TABLES
-- Target Project ID: oewerfftzqklptdsdfrm
-- Source of Truth: INFOSTORS_FINAL_DATA_STRUCTURE_API_CONTRACT.md (v1.0.0)
-- Safety: Non-destructive, idempotent
-- ============================================================================

-- ----------------------------------------------------------------------------
-- 1. ROLE-BASED ACCESS CONTROL (RBAC) TABLES
-- ----------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS public.roles (
    id TEXT PRIMARY KEY, -- 'main_admin', 'admin', 'support'
    name TEXT NOT NULL,
    description TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

CREATE TABLE IF NOT EXISTS public.permissions (
    id TEXT PRIMARY KEY, -- 'products.read', 'orders.write', etc.
    name TEXT NOT NULL,
    module TEXT NOT NULL,
    description TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

CREATE TABLE IF NOT EXISTS public.role_permissions (
    role_id TEXT NOT NULL REFERENCES public.roles(id) ON DELETE CASCADE,
    permission_id TEXT NOT NULL REFERENCES public.permissions(id) ON DELETE CASCADE,
    PRIMARY KEY (role_id, permission_id)
);

CREATE TABLE IF NOT EXISTS public.admin_users (
    id TEXT PRIMARY KEY, -- 'admin_infostors24_main' or 'adm_<t36>_<r4>'
    auth_user_id UUID UNIQUE, -- Linked to Supabase auth.users(id)
    email TEXT NOT NULL UNIQUE,
    mobile TEXT NOT NULL,
    full_name TEXT NOT NULL,
    role TEXT NOT NULL REFERENCES public.roles(id) DEFAULT 'admin',
    status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'disabled')),
    created_by TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- ----------------------------------------------------------------------------
-- 2. CUSTOMER & SHIPPING ADDRESSES
-- ----------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS public.customers (
    id TEXT PRIMARY KEY, -- Format: CUS-<10_digit_mobile> or cust-<t36>-<r4>
    auth_user_id UUID UNIQUE, -- Linked to Supabase auth.users(id)
    full_name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    mobile TEXT NOT NULL UNIQUE CHECK (mobile ~ '^[6-9][0-9]{9}$'),
    address TEXT,
    city TEXT,
    state TEXT,
    pincode TEXT CHECK (pincode IS NULL OR pincode ~ '^[0-9]{6}$'),
    total_orders INTEGER NOT NULL DEFAULT 0 CHECK (total_orders >= 0),
    total_spent NUMERIC(12, 2) NOT NULL DEFAULT 0.00 CHECK (total_spent >= 0),
    status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'suspended')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

CREATE TABLE IF NOT EXISTS public.customer_addresses (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    customer_id TEXT NOT NULL REFERENCES public.customers(id) ON DELETE CASCADE,
    full_name TEXT NOT NULL,
    phone TEXT NOT NULL CHECK (phone ~ '^[6-9][0-9]{9}$'),
    address_line1 TEXT NOT NULL,
    address_line2 TEXT,
    city TEXT NOT NULL,
    state TEXT NOT NULL,
    pincode TEXT NOT NULL CHECK (pincode ~ '^[0-9]{6}$'),
    is_default BOOLEAN NOT NULL DEFAULT false,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- ----------------------------------------------------------------------------
-- 3. CATEGORIES & CATALOG PRODUCTS
-- ----------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS public.categories (
    id TEXT PRIMARY KEY, -- Slug string e.g. 'electronics', 'audio-sound'
    name TEXT NOT NULL,
    emoji TEXT NOT NULL DEFAULT '📦',
    description TEXT NOT NULL,
    icon_name TEXT,
    banner_image TEXT,
    display_order INTEGER NOT NULL DEFAULT 0,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

CREATE TABLE IF NOT EXISTS public.products (
    id TEXT PRIMARY KEY, -- SKU string e.g. 'inf-101'
    name TEXT NOT NULL,
    category_id TEXT NOT NULL REFERENCES public.categories(id) ON DELETE RESTRICT,
    brand TEXT NOT NULL DEFAULT 'INFOSTORS',
    price NUMERIC(10, 2) NOT NULL CHECK (price >= 0),
    original_price NUMERIC(10, 2) NOT NULL CHECK (original_price >= price),
    discount_percentage INTEGER GENERATED ALWAYS AS (
        CASE 
            WHEN original_price > 0 AND original_price > price 
            THEN ROUND(((original_price - price) / original_price) * 100)::INTEGER 
            ELSE 0 
        END
    ) STORED,
    image_url TEXT NOT NULL,
    gallery_images JSONB NOT NULL DEFAULT '[]'::jsonb,
    short_description TEXT NOT NULL,
    description TEXT NOT NULL,
    features JSONB NOT NULL DEFAULT '[]'::jsonb,
    stock INTEGER NOT NULL DEFAULT 0 CHECK (stock >= 0),
    rating NUMERIC(3, 2) NOT NULL DEFAULT 4.80 CHECK (rating >= 1.0 AND rating <= 5.0),
    reviews_count INTEGER NOT NULL DEFAULT 0 CHECK (reviews_count >= 0),
    is_trending BOOLEAN NOT NULL DEFAULT false,
    is_bestseller BOOLEAN NOT NULL DEFAULT false,
    is_new_arrival BOOLEAN NOT NULL DEFAULT false,
    is_deal BOOLEAN NOT NULL DEFAULT false,
    badge TEXT,
    warranty TEXT DEFAULT '1 Year Brand Replacement Warranty',
    is_active BOOLEAN NOT NULL DEFAULT true,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- ----------------------------------------------------------------------------
-- 4. INVENTORY LOGS (AUDITABLE STOCK MOVEMENTS)
-- ----------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS public.inventory_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    product_id TEXT NOT NULL REFERENCES public.products(id) ON DELETE CASCADE,
    change_amount INTEGER NOT NULL, -- negative for order, positive for restock
    previous_stock INTEGER NOT NULL CHECK (previous_stock >= 0),
    new_stock INTEGER NOT NULL CHECK (new_stock >= 0),
    reason TEXT NOT NULL CHECK (reason IN ('order_placed', 'order_cancelled', 'admin_adjustment', 'restock', 'damage_writeoff')),
    order_id TEXT,
    notes TEXT,
    created_by TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- ----------------------------------------------------------------------------
-- 5. ORDERS, LINE ITEMS & TRANSITION LOGS
-- ----------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS public.orders (
    id TEXT PRIMARY KEY, -- Monotonic format: INF-YYYYMMDD-XXXX
    customer_id TEXT REFERENCES public.customers(id) ON DELETE SET NULL,
    customer_name TEXT NOT NULL,
    customer_phone TEXT NOT NULL CHECK (customer_phone ~ '^[6-9][0-9]{9}$'),
    customer_email TEXT NOT NULL,
    shipping_address TEXT NOT NULL,
    city TEXT NOT NULL,
    state TEXT NOT NULL,
    pincode TEXT NOT NULL CHECK (pincode ~ '^[0-9]{6}$'),
    subtotal NUMERIC(10, 2) NOT NULL CHECK (subtotal >= 0),
    discount_amount NUMERIC(10, 2) NOT NULL DEFAULT 0.00 CHECK (discount_amount >= 0),
    shipping_fee NUMERIC(10, 2) NOT NULL DEFAULT 0.00 CHECK (shipping_fee >= 0),
    tax_amount NUMERIC(10, 2) NOT NULL DEFAULT 0.00 CHECK (tax_amount >= 0),
    grand_total NUMERIC(10, 2) NOT NULL CHECK (grand_total > 0),
    currency TEXT NOT NULL DEFAULT 'INR' CHECK (currency = 'INR'),
    payment_method TEXT NOT NULL CHECK (payment_method IN ('razorpay', 'upi', 'cod')),
    payment_status TEXT NOT NULL DEFAULT 'pending' CHECK (payment_status IN ('pending', 'authorized', 'paid', 'failed', 'refunded')),
    order_status TEXT NOT NULL DEFAULT 'pending' CHECK (order_status IN ('pending', 'confirmed', 'processing', 'shipped', 'delivered', 'cancelled')),
    package_status TEXT NOT NULL DEFAULT 'received' CHECK (package_status IN ('received', 'dispatched', 'delivered', 'cancelled')),
    razorpay_order_id TEXT,
    razorpay_payment_id TEXT,
    razorpay_signature TEXT,
    payment_failure_reason TEXT,
    courier_partner TEXT DEFAULT 'Delhivery Express',
    tracking_id TEXT,
    estimated_delivery_date TEXT,
    resolution TEXT,
    b2b_company_name TEXT,
    b2b_gstin TEXT,
    tax_breakdown JSONB NOT NULL DEFAULT '{}'::jsonb,
    paid_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

CREATE TABLE IF NOT EXISTS public.order_items (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    order_id TEXT NOT NULL REFERENCES public.orders(id) ON DELETE CASCADE,
    product_id TEXT NOT NULL REFERENCES public.products(id) ON DELETE RESTRICT,
    product_name TEXT NOT NULL,
    unit_price NUMERIC(10, 2) NOT NULL CHECK (unit_price >= 0),
    quantity INTEGER NOT NULL CHECK (quantity > 0),
    total_price NUMERIC(10, 2) NOT NULL CHECK (total_price >= 0),
    image_url TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

CREATE TABLE IF NOT EXISTS public.order_status_history (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    order_id TEXT NOT NULL REFERENCES public.orders(id) ON DELETE CASCADE,
    previous_status TEXT,
    new_status TEXT NOT NULL,
    changed_by TEXT NOT NULL,
    notes TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- ----------------------------------------------------------------------------
-- 6. STORE SETTINGS & PAYMENT GATEWAY CREDENTIALS
-- ----------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS public.store_settings (
    id TEXT PRIMARY KEY DEFAULT 'default' CHECK (id = 'default'),
    store_name TEXT NOT NULL DEFAULT 'INFOSTORS',
    tagline TEXT NOT NULL DEFAULT 'Smart Gadgets | Better Life',
    logo_url TEXT DEFAULT '',
    header_logo_height INTEGER DEFAULT 72,
    helpline TEXT NOT NULL DEFAULT '+91 94778 39200 (Toll Free / WhatsApp)',
    email TEXT NOT NULL DEFAULT 'contactinfostors@gmail.com',
    office_address TEXT NOT NULL DEFAULT 'INFOSTORS Headquarters, Garia station road, Kolkata 700084, India',
    standard_delivery_charge NUMERIC(8, 2) NOT NULL DEFAULT 49.00 CHECK (standard_delivery_charge >= 0),
    free_delivery_min NUMERIC(8, 2) NOT NULL DEFAULT 499.00 CHECK (free_delivery_min >= 0),
    enable_free_delivery_threshold BOOLEAN NOT NULL DEFAULT true,
    announcement TEXT NOT NULL DEFAULT 'Free Delivery on all orders above ₹499 across India',
    whatsapp_url TEXT NOT NULL DEFAULT 'https://wa.me/919477839200',
    instagram_url TEXT NOT NULL DEFAULT 'https://www.instagram.com/infostors',
    facebook_url TEXT NOT NULL DEFAULT 'https://www.facebook.com/Infostors',
    youtube_url TEXT NOT NULL DEFAULT 'https://www.youtube.com/@InfoStors',
    return_window TEXT DEFAULT '7 Days Replacement Guarantee',
    business_legal_name TEXT DEFAULT 'INFOSTORS ENTERPRISES PRIVATE LIMITED',
    trade_name TEXT DEFAULT 'INFOSTORS',
    owner_name TEXT DEFAULT 'InfoStors Management',
    pan TEXT DEFAULT 'AAACI1234F',
    gst_enabled BOOLEAN NOT NULL DEFAULT false,
    gstin TEXT DEFAULT '19AAACI1234F1Z8',
    gst_percentage NUMERIC(5, 2) NOT NULL DEFAULT 18.00 CHECK (gst_percentage >= 0 AND gst_percentage <= 100),
    gst_type TEXT NOT NULL DEFAULT 'inclusive' CHECK (gst_type IN ('inclusive', 'exclusive')),
    gst_state TEXT DEFAULT '19 - West Bengal',
    show_gstin_on_invoice BOOLEAN NOT NULL DEFAULT true,
    allow_customer_b2b_gst BOOLEAN NOT NULL DEFAULT true,
    pwa_settings JSONB NOT NULL DEFAULT '{}'::jsonb,
    whatsapp_notification_settings JSONB NOT NULL DEFAULT '{}'::jsonb,
    shipping_label_settings JSONB NOT NULL DEFAULT '{}'::jsonb,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_by TEXT
);

CREATE TABLE IF NOT EXISTS public.payment_settings (
    id TEXT PRIMARY KEY DEFAULT 'default' CHECK (id = 'default'),
    mode TEXT NOT NULL DEFAULT 'live' CHECK (mode IN ('test', 'live')),
    key_id TEXT NOT NULL DEFAULT '',
    key_secret_encrypted TEXT, -- AES-256-CBC ciphertext
    webhook_secret_encrypted TEXT, -- AES-256-CBC ciphertext
    is_active BOOLEAN NOT NULL DEFAULT true,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_by TEXT
);

-- ----------------------------------------------------------------------------
-- 7. TWO-MAN RULE DESTRUCTION GOVERNANCE
-- ----------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS public.delete_requests (
    id TEXT PRIMARY KEY, -- Format: del_req_<t36>_<r4>
    target_type TEXT NOT NULL CHECK (target_type IN ('order', 'customer')),
    target_id TEXT NOT NULL,
    target_summary TEXT NOT NULL,
    requested_by_email TEXT NOT NULL,
    requested_by_name TEXT,
    requested_by_role TEXT NOT NULL CHECK (requested_by_role IN ('main_admin', 'admin')),
    reason TEXT NOT NULL CHECK (length(reason) >= 5),
    status TEXT NOT NULL DEFAULT 'PENDING' CHECK (status IN ('PENDING', 'APPROVED', 'REJECTED', 'COMPLETED', 'FAILED')),
    reviewed_by_email TEXT,
    reviewed_by_name TEXT,
    reviewed_at TIMESTAMPTZ,
    rejection_reason TEXT,
    completed_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- ----------------------------------------------------------------------------
-- 8. IMMUTABLE SECURITY AUDIT LOGS
-- ----------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS public.audit_logs (
    id TEXT PRIMARY KEY, -- Format: log_<t36>_<r4>
    admin_email TEXT NOT NULL,
    admin_name TEXT,
    action TEXT NOT NULL,
    target_type TEXT NOT NULL,
    target_id TEXT NOT NULL,
    reason TEXT,
    result TEXT NOT NULL CHECK (result IN ('SUCCESS', 'FAILED', 'REJECTED')),
    details TEXT,
    metadata JSONB DEFAULT '{}'::jsonb,
    timestamp TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- ----------------------------------------------------------------------------
-- 9. TARGETED CUSTOMER MESSAGES & IN-APP NOTIFICATIONS
-- ----------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS public.customer_messages (
    id TEXT PRIMARY KEY, -- Format: msg_<t36>_<r4>
    customer_id TEXT NOT NULL REFERENCES public.customers(id) ON DELETE CASCADE,
    customer_email TEXT,
    customer_mobile TEXT,
    sender_type TEXT NOT NULL CHECK (sender_type IN ('admin', 'customer')),
    sender_name TEXT NOT NULL,
    subject TEXT NOT NULL,
    message TEXT NOT NULL,
    message_type TEXT NOT NULL CHECK (message_type IN ('offer', 'order_update', 'recommendation', 'support')),
    is_read BOOLEAN NOT NULL DEFAULT false,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

CREATE TABLE IF NOT EXISTS public.notifications (
    id TEXT PRIMARY KEY, -- Format: notif_<t36>_<r4>
    title TEXT NOT NULL,
    body TEXT NOT NULL,
    target_audience TEXT NOT NULL CHECK (target_audience IN ('all', 'segment', 'selected', 'individual')),
    target_customer_id TEXT REFERENCES public.customers(id) ON DELETE CASCADE,
    category TEXT NOT NULL CHECK (category IN ('special_offer', 'order_update', 'new_product', 'restock', 'promo')),
    status TEXT NOT NULL DEFAULT 'sent' CHECK (status IN ('sent', 'queued', 'not_configured')),
    sent_by TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- ----------------------------------------------------------------------------
-- 10. CUSTOMER CART & WISHLIST PERSISTENCE
-- ----------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS public.customer_carts (
    customer_id TEXT PRIMARY KEY REFERENCES public.customers(id) ON DELETE CASCADE,
    items JSONB NOT NULL DEFAULT '[]'::jsonb,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

CREATE TABLE IF NOT EXISTS public.customer_wishlists (
    customer_id TEXT NOT NULL REFERENCES public.customers(id) ON DELETE CASCADE,
    product_id TEXT NOT NULL REFERENCES public.products(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    PRIMARY KEY (customer_id, product_id)
);
