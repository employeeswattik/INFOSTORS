-- ============================================================================
-- INFOSTORS FINAL SUPABASE MASTER BUILD — MIGRATION 10: SEED DATA
-- Target Project ID: oewerfftzqklptdsdfrm
-- Source of Truth: INFOSTORS_FINAL_DATA_STRUCTURE_API_CONTRACT.md (v1.0.0)
-- Safety: Non-destructive, idempotent
-- ============================================================================

-- 1. SEED ROLES
INSERT INTO public.roles (id, name, description)
VALUES 
    ('main_admin', 'Primary Main Administrator', 'Complete unrestricted access including destructive operations, financial secrets and user management'),
    ('admin', 'Store Operations Administrator', 'Catalog management, inventory adjustments, order processing and tracking'),
    ('support', 'Customer Support Specialist', 'Read-only access to customer profiles and orders for customer assistance')
ON CONFLICT (id) DO NOTHING;

-- 2. SEED PERMISSIONS
INSERT INTO public.permissions (id, name, module, description)
VALUES 
    ('products.read', 'View Products', 'catalog', 'Read product details, prices, and catalog status'),
    ('products.write', 'Manage Products', 'catalog', 'Create, update, and toggle active status of products'),
    ('orders.read', 'View Orders', 'orders', 'View order list, financial breakdowns, and customer notes'),
    ('orders.write', 'Fulfill Orders', 'orders', 'Update order statuses, assign courier partners, and tracking IDs'),
    ('customers.read', 'View Customers', 'customers', 'Access customer directory and order history'),
    ('customers.write', 'Manage Customers', 'customers', 'Update customer profile status and notes'),
    ('inventory.read', 'View Inventory', 'inventory', 'View warehouse stock counts and low stock warnings'),
    ('inventory.write', 'Adjust Inventory', 'inventory', 'Perform stock adjustments and audit stock movements'),
    ('payments.read', 'View Payments', 'payments', 'View payment gateway status, mode, and masked credentials'),
    ('payments.write', 'Manage Payments', 'payments', 'Update payment gateway credentials and webhook secrets'),
    ('shipping.write', 'Manage Shipping', 'shipping', 'Assign logistics partners and generate thermal shipping labels'),
    ('reports.read', 'View Reports', 'reports', 'Generate business analytics, GST reports, and export sales CSV'),
    ('settings.write', 'Manage Settings', 'settings', 'Configure store branding, delivery charges, and GST policy'),
    ('users.write', 'Manage Admin Users', 'admin', 'Add, modify, and disable secondary administrator accounts'),
    ('backup.manage', 'Backup & Restore', 'system', 'Export database snapshots and perform store restoration'),
    ('activity.read', 'View Audit Logs', 'security', 'View security audit trail and system access logs')
ON CONFLICT (id) DO NOTHING;

-- 3. MAP PERMISSIONS TO ROLES
-- Main Admin: All permissions
INSERT INTO public.role_permissions (role_id, permission_id)
SELECT 'main_admin', id FROM public.permissions
ON CONFLICT DO NOTHING;

-- Admin: Operational permissions
INSERT INTO public.role_permissions (role_id, permission_id)
VALUES
    ('admin', 'products.read'),
    ('admin', 'products.write'),
    ('admin', 'orders.read'),
    ('admin', 'orders.write'),
    ('admin', 'customers.read'),
    ('admin', 'inventory.read'),
    ('admin', 'inventory.write'),
    ('admin', 'payments.read'),
    ('admin', 'shipping.write'),
    ('admin', 'reports.read'),
    ('admin', 'settings.write'),
    ('admin', 'activity.read')
ON CONFLICT DO NOTHING;

-- 4. SEED PRIMARY MAIN ADMINISTRATOR
INSERT INTO public.admin_users (id, email, mobile, full_name, role, status)
VALUES (
    'admin_infostors24_main',
    'infostors24@gmail.com',
    '8695222581',
    'INFOSTORS Main Administrator',
    'main_admin',
    'active'
) ON CONFLICT (email) DO UPDATE SET
    role = 'main_admin',
    status = 'active';

-- 5. SEED STORE SETTINGS
INSERT INTO public.store_settings (
    id,
    store_name,
    tagline,
    logo_url,
    header_logo_height,
    helpline,
    email,
    office_address,
    standard_delivery_charge,
    free_delivery_min,
    enable_free_delivery_threshold,
    announcement,
    whatsapp_url,
    instagram_url,
    facebook_url,
    youtube_url,
    return_window,
    business_legal_name,
    trade_name,
    owner_name,
    pan,
    gst_enabled,
    gstin,
    gst_percentage,
    gst_type,
    gst_state,
    show_gstin_on_invoice,
    allow_customer_b2b_gst
) VALUES (
    'default',
    'INFOSTORS',
    'Smart Gadgets | Better Life',
    '',
    72,
    '+91 94778 39200 (Toll Free / WhatsApp)',
    'contactinfostors@gmail.com',
    'INFOSTORS Headquarters, Garia station road, Kolkata 700084, India',
    49.00,
    499.00,
    true,
    'Free Delivery on all orders above ₹499 across India',
    'https://wa.me/919477839200',
    'https://www.instagram.com/infostors',
    'https://www.facebook.com/Infostors',
    'https://www.youtube.com/@InfoStors',
    '7 Days Replacement Guarantee',
    'INFOSTORS ENTERPRISES PRIVATE LIMITED',
    'INFOSTORS',
    'InfoStors Management',
    'AAACI1234F',
    false,
    '19AAACI1234F1Z8',
    18.00,
    'inclusive',
    '19 - West Bengal',
    true,
    true
) ON CONFLICT (id) DO NOTHING;

-- 6. SEED OFFICIAL CATEGORIES
INSERT INTO public.categories (id, name, emoji, description, display_order)
VALUES 
    ('all', 'All Categories', '🛍️', 'Explore our entire curated selection of smart products', 0),
    ('electronics', 'Electronics', '⚡', 'Smart electronics, power hubs, and digital lifestyle essentials', 1),
    ('smart-home', 'Smart Home', '🏠', 'Automate your living spaces with sensors, smart sockets, and monitors', 2),
    ('mobile-accessories', 'Mobile Accessories', '📱', 'Fast chargers, magnetic power banks, car mounts & tough cables', 3),
    ('audio-sound', 'Audio & Sound', '🔊', 'True wireless earbuds, soundbars and portable party speakers', 4),
    ('home-kitchen', 'Home & Kitchen', '🍳', 'Modern cookware, precision blenders, and smart kitchen helpers', 5),
    ('massagers', 'Massagers', '💆', 'Deep tissue massage guns, neck massagers, and relaxation devices', 6),
    ('rgb-lights', 'RGB Lights', '🌈', 'Smart ambient light bars, neon strips, and sound-reactive lamps', 7)
ON CONFLICT (id) DO NOTHING;

-- 7. SEED CORE CATALOG PRODUCTS
INSERT INTO public.products (
    id, name, category_id, brand, price, original_price, image_url, gallery_images, 
    short_description, description, features, stock, rating, reviews_count, 
    is_trending, is_bestseller, is_new_arrival, is_deal, badge
) VALUES 
    (
        'inf-101',
        'AeroBeat Pro ANC Wireless Earbuds with 40h Playtime',
        'audio-sound',
        'INFOSTORS SoundLab',
        1899.00,
        4499.00,
        'https://images.unsplash.com/photo-1590658268037-6bf12165a8df?w=800&auto=format&fit=crop&q=80',
        '["https://images.unsplash.com/photo-1590658268037-6bf12165a8df?w=800&auto=format&fit=crop&q=80","https://images.unsplash.com/photo-1572536147248-ac59a8abfa4b?w=800&auto=format&fit=crop&q=80"]'::jsonb,
        'Active Noise Cancellation (ANC), 10mm titanium bass drivers, fast Type-C charging.',
        'Immerse in studio-grade audio with our flagship wireless earbuds. Features hybrid Active Noise Cancellation up to 32dB, quad-microphone crystal clear calling, IPX5 sweat resistance, and instant Bluetooth 5.3 auto-pairing.',
        '["32dB Hybrid Active Noise Cancellation with Transparency Mode","Quad-Mic AI ENC for crystal clear phone and video calls","Up to 40 Hours combined playtime","10-minute ASAP charge delivers 120 minutes of music","IPX5 water and sweat resistant rating"]'::jsonb,
        42,
        4.80,
        1420,
        true,
        true,
        false,
        true,
        'BESTSELLER'
    ),
    (
        'inf-102',
        'VoltCharge 65W GaN Dual Type-C Ultra-Compact Fast Charger',
        'mobile-accessories',
        'INFOSTORS Power',
        1499.00,
        2999.00,
        'https://images.unsplash.com/photo-1583863788434-e58a36330cf0?w=800&auto=format&fit=crop&q=80',
        '["https://images.unsplash.com/photo-1583863788434-e58a36330cf0?w=800&auto=format&fit=crop&q=80"]'::jsonb,
        'Next-gen Gallium Nitride (GaN III) technology for laptops, iPhones, and Android devices.',
        'Powers your laptops, smartphones, and tablets simultaneously. Built with aerospace-grade GaN technology for maximum efficiency, cool operation, and multi-protocol fast charging support (PD 3.0, QC 4.0, PPS).',
        '["65W Max Output power charges MacBooks, laptops and fast charge phones","Dual USB Type-C + 1 USB-A smart triple port output","GaN III semiconductor ensures 45% smaller form factor","Intelligent multi-layer protection against short-circuit and over-voltage"]'::jsonb,
        55,
        4.90,
        960,
        true,
        false,
        true,
        false,
        'TOP TECH'
    ),
    (
        'inf-103',
        'LumiSync Flow RGB Smart Light Bar with Music Reactive Mode',
        'rgb-lights',
        'INFOSTORS Living',
        1299.00,
        2499.00,
        'https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=800&auto=format&fit=crop&q=80',
        '["https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=800&auto=format&fit=crop&q=80"]'::jsonb,
        'Immersive ambient lighting for gaming setups, desk setups, and TV backdrops.',
        'Elevate your desk setup or home theater. Equipped with high-sensitivity sound sensors that pulse dynamically to music beats, gaming sound effects, or movie dialogue. Controlled via companion mobile app or physical touch base.',
        '["16 Million RGB Colors with 32 vibrant dynamic preset lighting effects","Built-in ultra-sensitive acoustic microphone for sound rhythm syncing","Horizontal or vertical dual orientation with included aluminum stand","Universal 5V USB powered for computer desks, consoles or TV ports"]'::jsonb,
        34,
        4.70,
        710,
        false,
        false,
        true,
        true,
        'TRENDING'
    )
ON CONFLICT (id) DO NOTHING;
