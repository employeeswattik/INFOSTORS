-- ============================================================================
-- INFOSTORS FINAL SUPABASE MASTER BUILD — MIGRATION 04: CONSTRAINTS & CHECKS
-- Target Project ID: oewerfftzqklptdsdfrm
-- Safety: Non-destructive, idempotent
-- ============================================================================

DO $$ BEGIN
    -- Verify customer mobile check
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'chk_customers_mobile_in') THEN
        ALTER TABLE public.customers 
            ADD CONSTRAINT chk_customers_mobile_in CHECK (mobile ~ '^[6-9][0-9]{9}$');
    END IF;
EXCEPTION WHEN OTHERS THEN NULL;
END $$;

DO $$ BEGIN
    -- Verify order phone check
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'chk_orders_customer_phone') THEN
        ALTER TABLE public.orders 
            ADD CONSTRAINT chk_orders_customer_phone CHECK (customer_phone ~ '^[6-9][0-9]{9}$');
    END IF;
EXCEPTION WHEN OTHERS THEN NULL;
END $$;

DO $$ BEGIN
    -- Verify order pincode check
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'chk_orders_pincode_in') THEN
        ALTER TABLE public.orders 
            ADD CONSTRAINT chk_orders_pincode_in CHECK (pincode ~ '^[0-9]{6}$');
    END IF;
EXCEPTION WHEN OTHERS THEN NULL;
END $$;

DO $$ BEGIN
    -- Verify products price non-negative
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'chk_products_price_positive') THEN
        ALTER TABLE public.products 
            ADD CONSTRAINT chk_products_price_positive CHECK (price >= 0);
    END IF;
EXCEPTION WHEN OTHERS THEN NULL;
END $$;

DO $$ BEGIN
    -- Verify products stock non-negative
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'chk_products_stock_nonnegative') THEN
        ALTER TABLE public.products 
            ADD CONSTRAINT chk_products_stock_nonnegative CHECK (stock >= 0);
    END IF;
EXCEPTION WHEN OTHERS THEN NULL;
END $$;

DO $$ BEGIN
    -- Verify inventory logs stock non-negative
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'chk_inventory_logs_new_stock') THEN
        ALTER TABLE public.inventory_logs 
            ADD CONSTRAINT chk_inventory_logs_new_stock CHECK (new_stock >= 0);
    END IF;
EXCEPTION WHEN OTHERS THEN NULL;
END $$;
